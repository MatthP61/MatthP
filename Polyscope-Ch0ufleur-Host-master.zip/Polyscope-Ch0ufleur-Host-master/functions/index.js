const functions = require("firebase-functions");
const sgMail = require("@sendgrid/mail");
const {BetaAnalyticsDataClient} = require("@google-analytics/data");

const API_KEY = functions.config().sendgrid.key;
const TEMPLATE_ID = functions.config().sendgrid.template;
const PROPERTY_ID = functions.config().analytics.propertyid;

sgMail.setApiKey(API_KEY);

// lazy global variable to improve performance on cold starts
let gaClient;

exports.genericEmail = functions
    .runWith({
      allowInvalidAppCheckToken: false,
    })
    .https.onCall(async (data) => {
      const msg = {
        to: "article@polyscope.qc.ca",
        from: "article@polyscope.qc.ca",
        templateId: TEMPLATE_ID,
        dynamic_template_data: {
          subject: data.subject,
          object: data.object,
          description: data?.description || "",
          text: data.text,
          comment: data?.comment || "",
          name: data.name,
          email: data.email,
        },
      };

      await sgMail.send(msg);

      return {success: true};
    });

exports.runReport = functions
    .runWith({
      allowInvalidAppCheckToken: false,
    })
    .https.onCall(async (request) => {
    // instantiate only if not already done
      gaClient = gaClient || new BetaAnalyticsDataClient();

      // add property id
      request.property = `properties/${PROPERTY_ID}`;

      console.log("requesting", request);
      const [response] = await gaClient.runReport(request);

      return response.rows || [];
    });
