import { Suspense, lazy } from 'react';
import { Navigate, useRoutes, useLocation } from 'react-router-dom';
// layouts
import MainLayout from '../layouts/main';
import DashboardLayout from '../layouts/dashboard';
import LogoOnlyLayout from '../layouts/LogoOnlyLayout';
// guards
import { GuestGuard, AuthGuard, RoleBasedGuard, BlogGuard } from '../guards';
// config
import { PATH_AFTER_LOGIN } from '../config';
// components
import LoadingScreen from '../components/atoms/LoadingScreen';

// ----------------------------------------------------------------------
const FALSE = false;

const Loadable = (Component) => (props) => {
  // eslint-disable-next-line react-hooks/rules-of-hooks
  const { pathname } = useLocation();

  return (
    <Suspense fallback={<LoadingScreen isDashboard={pathname.includes('/dashboard')} />}>
      <Component {...props} />
    </Suspense>
  );
};

export default function Router() {
  return useRoutes([
    {
      path: 'auth',
      children: [
        {
          path: 'login',
          element: (
            <GuestGuard>
              <Login />
            </GuestGuard>
          ),
        },
        {
          path: 'register',
          element: (
            <GuestGuard>
              <Register />
            </GuestGuard>
          ),
        },
        { path: 'login-unprotected', element: <Login /> },
        { path: 'register-unprotected', element: <Register /> },
        { path: 'reset-password', element: <ResetPassword /> },
      ],
    },

    // Dashboard Routes
    {
      path: 'dashboard',
      element: (
        <AuthGuard>
          <DashboardLayout />
        </AuthGuard>
      ),
      children: [
        { element: <Navigate to={PATH_AFTER_LOGIN} replace />, index: true },
        {
          path: 'app',
          element: (
            <RoleBasedGuard>
              <GeneralApp />
            </RoleBasedGuard>
          ),
        },
        {
          path: 'user',
          children: [
            { element: <Navigate to="/dashboard/user/list" replace />, index: true },
            {
              path: 'list',
              element: (
                <RoleBasedGuard>
                  <UserList />
                </RoleBasedGuard>
              ),
            },
            {
              path: ':name/edit',
              element: (
                <RoleBasedGuard>
                  <UserCreate />
                </RoleBasedGuard>
              ),
            },
            { path: 'account', element: <UserAccount /> },
          ],
        },
        {
          path: 'edition',
          children: [
            { element: <Navigate to="/dashboard/edition/list" replace />, index: true },
            {
              path: 'list',
              element: (
                <RoleBasedGuard>
                  <EditionCards />
                </RoleBasedGuard>
              ),
            },
            {
              path: 'new-edition',
              element: (
                <RoleBasedGuard>
                  <EditionCreate />
                </RoleBasedGuard>
              ),
            },
          ],
        },
        {
          path: 'blog',
          children: [
            { element: <Navigate to="/dashboard/blog/posts" replace />, index: true },
            {
              path: 'posts',
              element: (
                <BlogGuard isBlog={FALSE}>
                  <BlogPosts />
                </BlogGuard>
              ),
            },
            {
              path: 'post/:title',
              element: (
                <BlogGuard isBlog={!FALSE}>
                  <BlogPost />
                </BlogGuard>
              ),
            },
            { path: 'new-post', element: <BlogNewPost /> },
            {
              path: ':title/edit',
              element: (
                <BlogGuard isBlog={!FALSE}>
                  <BlogNewPost />
                </BlogGuard>
              ),
            },
          ],
        },
        {
          path: 'category',
          children: [
            { element: <Navigate to="/dashboard/category/list" replace />, index: true },
            {
              path: 'list',
              element: (
                <RoleBasedGuard>
                  <CategoryList />
                </RoleBasedGuard>
              ),
            },
            {
              path: 'new-category',
              element: (
                <RoleBasedGuard>
                  <NewCategory />{' '}
                </RoleBasedGuard>
              ),
            },
            {
              path: ':uid/edit',
              element: (
                <RoleBasedGuard>
                  <NewCategory />
                </RoleBasedGuard>
              ),
            },
          ],
        },
        {
          path: 'ads',
          children: [
            { element: <Navigate to="/dashboard/ads/list" replace />, index: true },
            {
              path: 'list',
              element: (
                <RoleBasedGuard>
                  <AdList />{' '}
                </RoleBasedGuard>
              ),
            },
            {
              path: 'new-ad',
              element: (
                <RoleBasedGuard>
                  <AdNewAd />
                </RoleBasedGuard>
              ),
            },
            {
              path: ':uid/edit',
              element: (
                <RoleBasedGuard>
                  <AdNewAd />
                </RoleBasedGuard>
              ),
            },
          ],
        },
        {
          path: 'settings',
          children: [
            { element: <Navigate to="/dashboard/settings/general" replace />, index: true },
            {
              path: 'general',
              element: (
                <RoleBasedGuard>
                  <Settings />{' '}
                </RoleBasedGuard>
              ),
            },
            {
              path: 'about',
              element: (
                <RoleBasedGuard>
                  <SettingsAbout />{' '}
                </RoleBasedGuard>
              ),
            },
            {
              path: 'team',
              element: (
                <RoleBasedGuard>
                  <SettingsTeam />{' '}
                </RoleBasedGuard>
              ),
            },
            {
              path: 'team/new-member',
              element: (
                <RoleBasedGuard>
                  <NewTeamMember />{' '}
                </RoleBasedGuard>
              ),
            },
            {
              path: 'team/:uid/edit',
              element: (
                <RoleBasedGuard>
                  <NewTeamMember />{' '}
                </RoleBasedGuard>
              ),
            },
          ],
        },
        {
          path: 'calendar',
          element: (
            <RoleBasedGuard>
              <Calendar />
            </RoleBasedGuard>
          ),
        },
      ],
    },

    // Main Routes
    {
      path: '*',
      element: <LogoOnlyLayout />,
      children: [
        { path: 'coming-soon', element: <ComingSoon /> },
        { path: 'maintenance', element: <Maintenance /> },
        { path: '500', element: <Page500 /> },
        { path: '404', element: <NotFound /> },
        { path: 'banned', element: <UserBanned /> },
        { path: '*', element: <Navigate to="/404" replace /> },
      ],
    },
    {
      path: '/',
      element: <MainLayout />,
      children: [
        { element: <HomePage />, index: true },
        { path: 'about-us', element: <About /> },
        { path: 'team', element: <Team /> },
        { path: 'blogs', element: <Blogs /> },
        { path: 'blogs/category/:category', element: <BlogsCategory /> },
        { path: 'blog/post/:title', element: <SingleBlog /> },
        { path: 'journalist/:UID', element: <Journalist /> },
        { path: 'contact-us', element: <Contact /> },
        { path: 'editions', element: <Editions /> },
        { path: 'send-blog', element: <SendText /> },
        { path: 'terms-conditions', element: <TermCondition /> },
      ],
    },
    { path: '*', element: <Navigate to="/404" replace /> },
  ]);
}

// IMPORT COMPONENTS

// Authentication
const Login = Loadable(lazy(() => import('../pages/auth/Login')));
const Register = Loadable(lazy(() => import('../pages/auth/Register')));
const ResetPassword = Loadable(lazy(() => import('../pages/auth/ResetPassword')));
// Dashboard
const GeneralApp = Loadable(lazy(() => import('../pages/dashboard/GeneralApp')));
const BlogPosts = Loadable(lazy(() => import('../pages/dashboard/BlogPosts')));
const BlogPost = Loadable(lazy(() => import('../pages/dashboard/BlogPost')));
const BlogNewPost = Loadable(lazy(() => import('../pages/dashboard/BlogNewPost')));
const EditionCards = Loadable(lazy(() => import('../pages/dashboard/EditionCards')));
const EditionCreate = Loadable(lazy(() => import('../pages/dashboard/EditionCreate')));
const UserList = Loadable(lazy(() => import('../pages/dashboard/UserList')));
const UserAccount = Loadable(lazy(() => import('../pages/dashboard/UserAccount')));
const UserCreate = Loadable(lazy(() => import('../pages/dashboard/UserCreate')));
const AdList = Loadable(lazy(() => import('../pages/dashboard/AdList')));
const CategoryList = Loadable(lazy(() => import('../pages/dashboard/CategoryList')));
const AdNewAd = Loadable(lazy(() => import('../pages/dashboard/AdNewAd')));
const NewCategory = Loadable(lazy(() => import('../pages/dashboard/NewCategory')));
const Settings = Loadable(lazy(() => import('../pages/dashboard/Settings')));
const SettingsAbout = Loadable(lazy(() => import('../pages/dashboard/SettingsAbout')));
const SettingsTeam = Loadable(lazy(() => import('../pages/dashboard/SettingsTeam')));
const NewTeamMember = Loadable(lazy(() => import('../pages/dashboard/NewTeamMember')));
const Calendar = Loadable(lazy(() => import('../pages/dashboard/Calendar')));

// Main
const HomePage = Loadable(lazy(() => import('../pages/Home')));
const About = Loadable(lazy(() => import('../pages/About')));
const Team = Loadable(lazy(() => import('../pages/Team')));
const Contact = Loadable(lazy(() => import('../pages/Contact')));
const SendText = Loadable(lazy(() => import('../pages/SendText')));
const ComingSoon = Loadable(lazy(() => import('../pages/ComingSoon')));
const Maintenance = Loadable(lazy(() => import('../pages/Maintenance')));
const Page500 = Loadable(lazy(() => import('../pages/Page500')));
const NotFound = Loadable(lazy(() => import('../pages/Page404')));
const UserBanned = Loadable(lazy(() => import('../pages/UserBanned')));
const SingleBlog = Loadable(lazy(() => import('../pages/BlogPost')));
const Blogs = Loadable(lazy(() => import('../pages/BlogPosts')));
const BlogsCategory = Loadable(lazy(() => import('../pages/BlogPostsCategory')));
const Journalist = Loadable(lazy(() => import('../pages/Journalist')));
const Editions = Loadable(lazy(() => import('../pages/Editions')));
const TermCondition = Loadable(lazy(() => import('../pages/TermCondition')));
