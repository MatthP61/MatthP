import PropTypes from 'prop-types';
import { Paper, Typography } from '@mui/material';
import i18n from '../../locales/i18n';

// ----------------------------------------------------------------------

SearchNotFound.propTypes = {
  searchQuery: PropTypes.string,
};

export default function SearchNotFound({ searchQuery = '', ...other }) {
  return searchQuery ? (
    <Paper {...other}>
      <Typography gutterBottom align="center" variant="subtitle1">
        {i18n.t('blog.notFound')}
      </Typography>
      <Typography variant="body2" align="center">
        {i18n.t('blog.noResult')} &nbsp;
        <strong>&quot;{searchQuery}&quot;</strong>. {i18n.t('blog.tryCheck')}
      </Typography>
    </Paper>
  ) : (
    <Typography variant="body2"> {i18n.t('blog.enterKeywords')} </Typography>
  );
}
