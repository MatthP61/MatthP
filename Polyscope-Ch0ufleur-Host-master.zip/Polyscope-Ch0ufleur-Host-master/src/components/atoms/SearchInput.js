import PropTypes from 'prop-types';
// @mui
import { InputAdornment, FilledInput } from '@mui/material';
//
import Iconify from './Iconify';
import i18n from '../../locales/i18n';

// ----------------------------------------------------------------------

SearchInput.propTypes = {
  sx: PropTypes.object,
};

export default function SearchInput({ sx, ...other }) {
  return (
    <FilledInput
      fullWidth
      startAdornment={
        <InputAdornment position="start">
          <Iconify icon={'akar-icons:search'} sx={{ width: 24, height: 24, color: 'text.disabled' }} />
        </InputAdornment>
      }
      placeholder={i18n.t('search')}
      sx={{
        '& .MuiFilledInput-input': { py: '18px' },
        ...sx,
      }}
      {...other}
    />
  );
}
