import PropTypes from 'prop-types';
// @mui
import { styled } from '@mui/material/styles';
//
import { useLottie } from 'lottie-react';
import ProgressBar from './ProgressBar';

import lottieLoading2 from '../../assets/lottieLoading2.json';

// ----------------------------------------------------------------------
const style = {
  height: 150,
};
const RootStyle = styled('div')(({ theme }) => ({
  right: 0,
  bottom: 0,
  zIndex: 99999,
  width: '100%',
  height: '100%',
  position: 'relative',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  backgroundColor: theme.palette.background.default,
}));
// ----------------------------------------------------------------------

LottieScreen.propTypes = {
  isDashboard: PropTypes.bool,
};

export default function LottieScreen({ ...other }) {
  const options = {
    animationData: lottieLoading2,
    loop: true,
    autoplay: true,
  };

  const { View } = useLottie(options, style);
  return (
    <>
      <ProgressBar />
      <RootStyle {...other}>{View}</RootStyle>
    </>
  );
}
