import * as React from 'react';
import { Link as RouterLink } from 'react-router-dom';
import PropTypes from 'prop-types';
// @mui
import { Box, Link, Stack, Avatar, Typography, Card } from '@mui/material';
// routes
import { PATH_PAGE } from '../../../routes/paths';
// hooks
import useResponsive from '../../../hooks/useResponsive';
// utils
import { fDate } from '../../../utils/formatTime';
// components
import Image from '../../atoms/Image';
import TextMaxLine from '../../atoms/TextMaxLine';

PopularCard.propTypes = {
  blog: PropTypes.object,
};

export default function PopularCard({ blog }) {
  const isDesktop = useResponsive('up', 'md');
  const { cover, title, description, createdAt, UID, author } = blog;
  const linkTo = `${PATH_PAGE.blog}/post/${UID}`;

  return (
    <Card sx={{ borderRadius: 2, display: 'flex', flexDirection: 'row' }} to={'/dashboard/events/heloooooo/details'}>
      <Box sx={{ p: 1, position: 'relative', width: '40%', height: '30%' }}>
        <Image src={cover} ratio={isDesktop ? '3/3' : '4/6'} sx={{ borderRadius: 1.5 }} />
      </Box>
      <Stack spacing={2} sx={{ width: '60%', p: 1.5 }}>
        <Stack direction="row" alignItems="center" spacing={1} textAlign="left">
          <Link to={linkTo} color="inherit" component={RouterLink} textAlign="left">
            <TextMaxLine variant={'h5'} line={1} persistent>
              {title}
            </TextMaxLine>
          </Link>
        </Stack>
        <Stack direction="row" alignItems="center" justifyContent="space-between" spacing={3}>
          <TextMaxLine variant="body1" line={3} persistent textAlign="left">
            {description}
          </TextMaxLine>
        </Stack>
        <Stack
          direction="row"
          alignItems="center"
          justifyContent="space-between"
          spacing={1}
          sx={{ color: 'text.secondary', position: 'relative', bottom: 0 }}
        >
          <Avatar
            alt={author?.displayName || 'Test'}
            src={author?.photoURL || 'Test'}
            sx={{
              zIndex: 9,
              width: 32,
              height: 32,
            }}
          />
          {createdAt && (
            <Typography
              gutterBottom
              variant="caption"
              component="div"
              sx={{
                color: 'text.disabled',
              }}
            >
              {fDate(createdAt)}
            </Typography>
          )}
        </Stack>
      </Stack>
    </Card>
  );
}
