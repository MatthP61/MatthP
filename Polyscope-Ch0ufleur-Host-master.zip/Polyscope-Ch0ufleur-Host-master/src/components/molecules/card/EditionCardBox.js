import ReactGA from 'react-ga4';
import PropTypes from 'prop-types';
import * as React from 'react';
// @mui
import { Box, Link, Card, Typography, CardContent } from '@mui/material';
// hooks
import useResponsive from '../../../hooks/useResponsive';
// utils
import { fDate } from '../../../utils/formatTime';
// components
import Image from '../../atoms/Image';
import TextMaxLine from '../../atoms/TextMaxLine';
import i18n from '../../../locales/i18n';

EditionCardBox.propTypes = {
  edition: PropTypes.object,
};

export default function EditionCardBox({ edition }) {
  const isDesktop = useResponsive('up', 'md');
  const { volume, UID, number, description, pdf, publishDate, cover, parutionKapote, kapote } = edition;

  const openPDF = () => {
    ReactGA.send({ hitType: 'pageview', page: `/edition/${UID}` });
    window.open(`${pdf}`);
  };

  return (
    <Card>
      <Box sx={{ position: 'relative' }}>
        <Image alt="cover" src={cover} ratio="4/3" />
      </Box>
      <CardContent
        sx={{
          pt: 4.5,
          width: 1,
        }}
      >
        <Typography
          gutterBottom
          variant="caption"
          component="div"
          sx={{
            color: 'text.disabled',
          }}
        >
          {fDate(publishDate)}
        </Typography>
        <Link sx={{ cursor: 'pointer' }} color="inherit" textAlign="left" onClick={openPDF}>
          <TextMaxLine variant={isDesktop ? 'h6' : 'subtitle2'} line={2} persistent textAlign={'center'}>
            {kapote
              ? `${i18n.t('editions.volume')} ${volume} ${i18n.t('editions.number')} ${number}* ${parutionKapote}`
              : `${i18n.t('editions.volume')} ${volume} ${i18n.t('editions.number')} ${number}`}
          </TextMaxLine>
        </Link>
        <TextMaxLine variant="body2" line={5} persistent textAlign="left">
          {description}
        </TextMaxLine>
      </CardContent>
    </Card>
  );
}
