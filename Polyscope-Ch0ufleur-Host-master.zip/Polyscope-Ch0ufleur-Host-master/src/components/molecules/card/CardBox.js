import PropTypes from 'prop-types';
import * as React from 'react';
import { Link as RouterLink } from 'react-router-dom';
// @mui
import { Box, Link, Card, Avatar, Typography, CardContent } from '@mui/material';
// routes
import { PATH_PAGE } from '../../../routes/paths';
// hooks
import useResponsive from '../../../hooks/useResponsive';
// utils
import { fDate } from '../../../utils/formatTime';
// components
import Image from '../../atoms/Image';
import TextMaxLine from '../../atoms/TextMaxLine';
import SvgIconStyle from '../../atoms/SvgIconStyle';

CardBox.propTypes = {
  blog: PropTypes.object,
};

export default function CardBox({ blog }) {
  const isDesktop = useResponsive('up', 'md');
  const { cover, title, author, description, createdAt, UID } = blog;
  const linkTo = `${PATH_PAGE.blog}/post/${UID}`;

  return (
    <Card>
      <Link to={linkTo} color="inherit" component={RouterLink} textAlign="left">
        <Box sx={{ position: 'relative' }}>
          <SvgIconStyle
            src="https://minimal-assets-api.vercel.app/assets/icons/shape-avatar.svg"
            sx={{
              width: 80,
              height: 36,
              zIndex: 9,
              bottom: -15,
              position: 'absolute',
              color: 'background.paper',
            }}
          />
          <Avatar
            alt={author?.displayName || 'Test'}
            src={author?.photoURL || 'Test'}
            sx={{
              left: 24,
              zIndex: 9,
              width: 32,
              height: 32,
              bottom: -16,
              position: 'absolute',
            }}
          />
          <Image alt="cover" src={cover} ratio="4/3" />
        </Box>
        <CardContent
          sx={{
            pt: 4.5,
            width: 1,
          }}
        >
          {createdAt && (
            <Typography
              gutterBottom
              variant="caption"
              component="div"
              sx={{
                color: 'text.disabled',
              }}
            >
              {fDate(createdAt)}
            </Typography>
          )}
          <TextMaxLine variant={isDesktop ? 'h5' : 'subtitle2'} line={2} persistent>
            {title}
          </TextMaxLine>
          <TextMaxLine variant="body1" line={2} persistent textAlign="left">
            {description}
          </TextMaxLine>
        </CardContent>
      </Link>
    </Card>
  );
}
