import PropTypes from 'prop-types';
import * as React from 'react';
// @mui
import { Box, Stack, Card, Typography } from '@mui/material';
// hooks
import useResponsive from '../../../hooks/useResponsive';
// utils
import { fDate } from '../../../utils/formatTime';
// components
import Image from '../../atoms/Image';
import TextMaxLine from '../../atoms/TextMaxLine';
import i18n from '../../../locales/i18n';

FutureEditionCardBox.propTypes = {
  edition: PropTypes.object,
};

export default function FutureEditionCardBox({ edition }) {
  const isDesktop = useResponsive('up', 'md');
  const { volume, number, publishDate, cover, parutionKapote, kapote } = edition;

  return (
    <Card sx={{ borderRadius: 2, display: 'flex', flexDirection: 'row' }}>
      <Box sx={{ p: 1, position: 'relative', width: '40%', height: '30%', alignContent: 'center' }}>
        <Image src={cover} ratio={isDesktop ? '3/3' : '3/3'} sx={{ borderRadius: 1.5 }} />
      </Box>
      <Box sx={{ position: 'relative', height: '100%', width: '60%', alignContent: 'center', alignSelf: 'center' }}>
        <Stack spacing={2}>
          <Stack alignItems="center" spacing={1} textAlign="left">
            <TextMaxLine variant={isDesktop ? 'body2' : 'subtitle2'} line={1} persistent>
              {kapote
                ? `${i18n.t('editions.volume')} ${volume} ${i18n.t('editions.number')} ${number}*`
                : `${i18n.t('editions.volume')} ${volume} ${i18n.t('editions.number')} ${number}`}
            </TextMaxLine>
            {kapote && (
              <TextMaxLine variant={isDesktop ? 'body2' : 'subtitle2'} line={1} persistent>
                {parutionKapote}
              </TextMaxLine>
            )}
          </Stack>
          <Stack
            direction="row"
            alignItems="center"
            justifyContent="space-between"
            spacing={1}
            sx={{ color: 'text.secondary', position: 'relative', bottom: 0 }}
          >
            <Typography
              gutterBottom
              variant="caption"
              component="div"
              sx={{
                color: 'text.disabled',
              }}
            >
              {fDate(publishDate)}
            </Typography>
          </Stack>
        </Stack>
      </Box>
    </Card>
  );
}
