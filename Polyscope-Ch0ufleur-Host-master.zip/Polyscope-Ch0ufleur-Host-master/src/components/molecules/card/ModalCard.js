import React from 'react';
import PropTypes from 'prop-types';
// @mui
import { Dialog, DialogTitle, DialogContent, DialogActions, Button, Grid } from '@mui/material';
import i18n from '../../../locales/i18n';

ModalCard.propTypes = {
  isOpen: PropTypes.bool,
  handleClose: PropTypes.func,
  UID: PropTypes.string,
  deleteElement: PropTypes.func,
};

export default function ModalCard({ isOpen, handleClose, UID, deleteElement }) {
  return (
    <Dialog open={isOpen} onClose={handleClose} key={UID}>
      <DialogTitle> {i18n.t('deleteModalCard.title')} </DialogTitle>
      <DialogContent sx={{ textAlign: 'center' }}>{i18n.t('deleteModalCard.noUndo')}</DialogContent>
      <DialogActions>
        <Grid container>
          {' '}
          <Grid item xs={9} md={9}>
            <Button variant="outlined" onClick={handleClose}>
              {i18n.t('deleteModalCard.return')}
            </Button>
          </Grid>
          <Grid item xs={3} md={3}>
            <Button variant="contained" onClick={deleteElement}>
              {i18n.t('deleteModalCard.delete')}{' '}
            </Button>
          </Grid>
        </Grid>
      </DialogActions>
    </Dialog>
  );
}
