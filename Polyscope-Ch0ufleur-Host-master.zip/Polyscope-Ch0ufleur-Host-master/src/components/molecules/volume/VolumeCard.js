import ReactGA from 'react-ga4';
import React, { useCallback, useContext, useEffect, useState } from 'react';
import { useSnackbar } from 'notistack';
import { styled } from '@mui/material/styles';
import { Grid, Container, SpeedDial, Typography, SpeedDialAction, Link } from '@mui/material';
import { FacebookShareButton, LinkedinShareButton, TwitterShareButton } from 'react-share';
import { MotionInView, varFade } from '../animate';

import i18n from '../../../locales/i18n';

import { EditionContext } from '../../../contexts/EditionContext';
import { fDate } from '../../../utils/formatTime';

// atoms
import Image from '../../atoms/Image';
import Iconify from '../../atoms/Iconify';

const RootStyle = styled('div')(({ theme }) => ({
  paddingTop: theme.spacing(5),
  [theme.breakpoints.up('md')]: {
    paddingBottom: theme.spacing(1),
  },
}));

const VolumeCard = () => {
  const { lastEdition, getLastVolume } = useContext(EditionContext);
  const [edition, setEdition] = useState({});
  const { enqueueSnackbar } = useSnackbar();

  const getLastEdition = useCallback(async () => {
    try {
      await getLastVolume();
    } catch (err) {
      console.log(err);
    }
  }, []);

  useEffect(() => {
    getLastEdition();
  }, [getLastEdition]);

  useEffect(() => {
    setEdition(lastEdition);
  }, [lastEdition]);

  const openPDF = () => {
    ReactGA.send({ hitType: 'pageview', page: `/edition/${edition.UID}` });
    window.open(`${edition.pdf}`);
  };

  const copy = () => {
    navigator.clipboard.writeText(edition?.pdf);
    enqueueSnackbar(i18n.t('copySuccess'));
  };

  const polyscopeLink = 'https://polyscope.step.polymtl.ca/';
  const SOCIALS = [
    {
      name: 'Facebook',
      action: (
        <FacebookShareButton
          url={edition?.pdf}
          quote={`${i18n.t('editions.volume')} ${edition?.volume} ${i18n.t('editions.number')} ${edition?.number}`}
        >
          <Iconify icon="eva:facebook-fill" width={20} height={20} color="#1877F2" />
        </FacebookShareButton>
      ),
    },
    {
      name: 'Linkedin',
      action: (
        <LinkedinShareButton
          url={edition?.pdf}
          quote={`${i18n.t('editions.volume')} ${edition?.volume} ${i18n.t('editions.number')} ${edition?.number}`}
          source={polyscopeLink}
        >
          <Iconify icon="eva:linkedin-fill" width={20} height={20} color="#006097" />
        </LinkedinShareButton>
      ),
    },
    {
      name: 'Twitter',
      action: (
        <TwitterShareButton
          url={edition?.pdf}
          title={`${i18n.t('editions.volume')} ${edition?.volume} ${i18n.t('editions.number')} ${edition?.number}`}
        >
          <Iconify icon="eva:twitter-fill" width={20} height={20} color="#1C9CEA" />
        </TwitterShareButton>
      ),
    },
  ];

  return (
    <RootStyle>
      <Container>
        {edition?.volume && (
          <Grid
            container
            spacing={2}
            direction="row"
            justifyContent="center"
            alignItems="center"
            sx={{
              height: { md: '25rem' },
            }}
          >
            <Grid
              item
              xs={12}
              md={4}
              sx={{
                alignItems: { xs: 'center' },
                mb: { xs: 3 },
                p: 10,
                height: { md: '100%' },
              }}
            >
              <Link color="inherit" onClick={openPDF} sx={{ cursor: 'pointer' }}>
                <Image src={edition?.cover} alt={edition?.cover} ratio="3/4" sx={{ borderRadius: 3 }} />
              </Link>
            </Grid>
            <Grid item xs={12} md={8}>
              <Grid
                item
                xs={12}
                md={12}
                sx={{
                  textAlign: 'left',
                }}
              >
                <MotionInView variants={varFade().inDown}>
                  <Link color="inherit" onClick={openPDF} sx={{ cursor: 'pointer' }}>
                    <Typography variant="h5">{i18n.t('home.recentEdition')}</Typography>
                    <Typography variant="h3">{`${i18n.t('editions.volume')} ${edition?.volume} ${i18n.t(
                      'editions.number'
                    )} ${edition?.number}`}</Typography>
                  </Link>
                </MotionInView>
              </Grid>
              {edition?.publishDate && (
                <Grid
                  item
                  xs={12}
                  md={12}
                  sx={{
                    textAlign: 'left',
                  }}
                >
                  <MotionInView variants={varFade().inDown}>
                    <Typography variant="overline">{`${i18n.t('editions.publishedThe')} ${fDate(
                      edition?.publishDate
                    )}`}</Typography>
                  </MotionInView>
                </Grid>
              )}
              <br />
              <Grid
                item
                xs={12}
                md={12}
                sx={{
                  textAlign: 'left',
                }}
              >
                <MotionInView variants={varFade().inDown}>
                  <Typography variant="body1">{edition?.description}</Typography>
                </MotionInView>
              </Grid>
              <br />
              <Grid
                item
                xs={12}
                md={12}
                sx={{
                  textAlign: 'left',
                }}
              >
                <SpeedDial
                  direction={'right'}
                  ariaLabel="Share post"
                  icon={<Iconify icon="eva:share-fill" sx={{ width: 20, height: 20 }} />}
                  sx={{ '& .MuiSpeedDial-fab': { width: 48, height: 48 } }}
                >
                  {SOCIALS.map((action) => (
                    <SpeedDialAction
                      key={action.name}
                      icon={action.action}
                      tooltipTitle={action.name}
                      tooltipPlacement="top"
                      FabProps={{ color: 'default' }}
                    />
                  ))}
                  <SpeedDialAction
                    key={i18n.t('copy')}
                    icon={<Iconify icon="eva:copy-outline" width={20} height={20} color="error.main" />}
                    tooltipTitle={i18n.t('copy')}
                    tooltipPlacement="top"
                    FabProps={{ color: 'default' }}
                    onClick={copy}
                  />
                </SpeedDial>
              </Grid>
            </Grid>
          </Grid>
        )}
      </Container>
    </RootStyle>
  );
};

export default React.memo(VolumeCard);
