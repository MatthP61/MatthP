import PropTypes from 'prop-types';
import { useTheme } from '@mui/material/styles';
// @mui
import { Stack, Card, Typography } from '@mui/material';

// components
import Image from '../../atoms/Image';
import SocialsButton from '../../atoms/SocialsButton';

MemberCard.propTypes = {
  member: PropTypes.shape({
    picture: PropTypes.string,
    name: PropTypes.string,
    role: PropTypes.string,
    facebook: PropTypes.string,
    instagram: PropTypes.string,
    linkedin: PropTypes.string,
    twitter: PropTypes.string,
  }),
};

export default function MemberCard({ member }) {
  const { name, role, picture, facebook, instagram, linkedin, twitter } = member;
  const theme = useTheme();
  return (
    <Card style={{ backgroundColor: theme.palette.card.background }} key={name} sx={{ p: 1 }}>
      <Typography align="center" variant="subtitle1" sx={{ mt: 2, mb: 0.5 }}>
        {name}
      </Typography>
      <Typography align="center" variant="body2" sx={{ mb: 2, color: 'text.secondary' }}>
        {role}
      </Typography>
      <Image src={picture} ratio="1/1" sx={{ borderRadius: 1.5 }} />
      <Stack alignItems="center" sx={{ mt: 2, mb: 1 }}>
        <SocialsButton sx={{ color: 'action.active' }} links={{ facebook, instagram, linkedin, twitter }} />
      </Stack>
    </Card>
  );
}
