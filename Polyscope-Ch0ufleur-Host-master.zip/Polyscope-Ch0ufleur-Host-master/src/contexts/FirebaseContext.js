import PropTypes from 'prop-types';
import { createContext, useEffect, useReducer, useState } from 'react';
import {
  getAuth,
  signOut,
  updatePassword,
  updateEmail,
  onAuthStateChanged,
  sendPasswordResetEmail,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
} from 'firebase/auth';
import { getFirestore, collection, doc, getDoc, setDoc, updateDoc } from 'firebase/firestore';
import { useFirebaseApp } from 'reactfire';

// ---------------------------------------------------------------------

const ACTION = {
  INITIALISE: 'INITIALISE',
  UPDATEUSER: 'UPDATEUSER',
};

const initialState = {
  isAuthenticated: false,
  isInitialized: false,
  user: null,
  isAdmin: false,
};

const reducer = (state, action) => {
  const { isAuthenticated, user, isAdmin, newinfo } = action.payload;
  switch (action.type) {
    case ACTION.INITIALISE:
      return {
        ...state,
        isAuthenticated,
        isInitialized: true,
        user,
        isAdmin,
      };
    case ACTION.UPDATEUSER:
      return {
        ...state,
        user: newinfo,
      };
    default:
      return state;
  }
};

const AuthContext = createContext({
  ...initialState,
  method: 'firebase',
  login: () => Promise.resolve(),
  register: () => Promise.resolve(),
  logout: () => Promise.resolve(),
  forgotPassword: () => Promise.resolve(),
  changePassword: () => Promise.resolve(),
});

// ----------------------------------------------------------------------

AuthProvider.propTypes = {
  children: PropTypes.node,
};

function AuthProvider({ children }) {
  const firebaseApp = useFirebaseApp();
  const AUTH = getAuth(firebaseApp);
  const DB = getFirestore(firebaseApp);
  const [state, dispatch] = useReducer(reducer, initialState);
  const [profile, setProfile] = useState(null);

  useEffect(
    () =>
      onAuthStateChanged(AUTH, async (user) => {
        if (user) {
          const userRef = doc(DB, 'users', user.uid);
          const docSnap = await getDoc(userRef);
          let newprofile = null;
          if (docSnap.exists()) {
            newprofile = docSnap.data();
            setProfile(newprofile);
          } else {
            const userRef = doc(collection(DB, 'users'), user.uid);
            const data = {
              UID: user.uid,
              name: user.email,
              displayName: user.email,
              email: user.email,
              phoneNumber: '',
              photoURL: '',
              isActif: false,
              isAdmin: false,
            };
            await setDoc(userRef, data).catch((error) => {
              console.log(error);
            });
          }
          dispatch({
            type: ACTION.INITIALISE,
            payload: { isAuthenticated: true, user: newprofile, isAdmin: newprofile?.isAdmin },
          });
        } else {
          dispatch({
            type: ACTION.INITIALISE,
            payload: { isAuthenticated: false, user: null, isAdmin: false },
          });
        }
      }),
    [dispatch]
  );

  const login = (email, password) => signInWithEmailAndPassword(AUTH, email, password);

  const forgotPassword = (email) =>
    sendPasswordResetEmail(AUTH, email)
      .then(() => {
        console.log('email sent');
      })
      .catch((error) => {
        console.log(error);
      });

  const changeEmail = (newEmail) =>
    updateEmail(AUTH.currentUser, newEmail)
      .then(() => {
        console.log('changed succesfully');
      })
      .catch(() => 'error');

  const register = (email, password, firstName, lastName, phoneNumber) =>
    createUserWithEmailAndPassword(AUTH, email, password).then(async (res) => {
      const userRef = doc(collection(DB, 'users'), res.user?.uid);
      const data = {
        UID: res.user?.uid,
        name: `${firstName} ${lastName}`,
        displayName: `${firstName} ${lastName}`,
        email,
        phoneNumber,
        photoURL: '',
        isActif: false,
        isAdmin: false,
      };
      await setDoc(userRef, data).catch((error) => {
        console.log(error);
      });
    });

  const updateUser = async (data, isSocialMediaLinkUpdate) => {
    const userRef = doc(collection(DB, 'users'), profile?.UID);
    let isDenied = false;
    if (data?.email !== profile?.email) {
      await changeEmail(data.email).then((value) => {
        if (value === 'error') {
          isDenied = true;
        }
      });
    }
    if (!isDenied) {
      await updateDoc(userRef, data)
        .then(() => {
          const newUser = getNewUserInfo(data, isSocialMediaLinkUpdate);
          dispatch({
            type: ACTION.UPDATEUSER,
            payload: { newinfo: newUser },
          });
        })
        .catch(() => 'error');
    } else {
      return 'log';
    }
  };

  const getNewUserInfo = (newinfo, isSocialMediaLinkUpdate) => {
    if (!isSocialMediaLinkUpdate) {
      return {
        ...state.user,
        name: newinfo.name,
        displayName: newinfo.displayName,
        email: newinfo.email,
        phoneNumber: newinfo.phoneNumber,
        about: newinfo.about,
        photoURL: newinfo.photoURL,
      };
    }

    return {
      ...state.user,
      facebook: newinfo.facebook,
      instagram: newinfo.instagram,
      linkedin: newinfo.linkedin,
      twitter: newinfo.twitter,
    };
  };

  const logout = () => signOut(AUTH).then(() => setProfile(null));

  const changePassword = (newPassword) =>
    updatePassword(AUTH.currentUser, newPassword)
      .then(() => {
        console.log('changed succesfully');
      })
      .catch(() => 'error');

  return (
    <AuthContext.Provider
      value={{
        ...state,
        method: 'firebase',
        user: {
          UID: state?.user?.UID,
          name: state?.user?.name || '',
          displayName: state?.user?.displayName || profile?.displayName || '',
          email: state?.user?.email,
          phoneNumber: state?.user?.phoneNumber || profile?.phoneNumber || '',
          photoURL: state?.user?.photoURL || profile?.photoURL || null,
          isAdmin: state?.user?.isAdmin || profile?.isAdmin || false,
          isActif: state?.user?.isActif || profile?.isActif || false,
          facebook: state?.user?.facebook || profile?.facebook || '',
          instagram: state?.user?.instagram || profile?.instagram || '',
          linkedin: state?.user?.linkedin || profile?.linkedin || '',
          twitter: state?.user?.twitter || profile?.twitter || '',
          about: state?.user?.about || profile?.about || '',
        },
        login,
        register,
        updateUser,
        logout,
        forgotPassword,
        changePassword,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export { AuthContext, AuthProvider };
