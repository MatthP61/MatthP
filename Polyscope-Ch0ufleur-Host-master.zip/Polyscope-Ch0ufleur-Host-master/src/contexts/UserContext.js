import PropTypes from 'prop-types';
import { createContext, useEffect, useReducer } from 'react';
import { getFirestore, collection, query, where, getDocs, getDoc, doc, deleteDoc, setDoc } from 'firebase/firestore';
import { useFirebaseApp } from 'reactfire';
import { deleteDocument } from '../components/atoms/FirebaseFunctions';

const ACTION = {
  LIST: 'userList',
  USER: 'user',
};

const initialState = {
  userList: [],
  currentUser: null,
};

const reducer = (state, action) => {
  const { Users, User } = action.payload;
  switch (action.type) {
    case ACTION.LIST:
      return {
        ...state,
        userList: Users,
        currentUser: null,
      };
    case ACTION.USER:
      return {
        ...state,
        currentUser: User,
      };
    default:
      return state;
  }
};

const UserContext = createContext(initialState);

// ----------------------------------------------------------------------
UserProvider.propTypes = {
  children: PropTypes.node,
};

function UserProvider({ children }) {
  const firebaseApp = useFirebaseApp();
  const DB = getFirestore(firebaseApp);

  useEffect(() => {
    getAllUser();
  }, []);

  const [state, dispatch] = useReducer(reducer, initialState);

  const getAllUser = async () => {
    const q = query(collection(DB, 'users'), where('UID', '!=', null));
    const users = [];
    const querySnapshot = await getDocs(q);
    querySnapshot.forEach((doc) => {
      const user = doc.data();
      users.push(user);
    });
    dispatch({
      type: ACTION.LIST,
      payload: {
        Users: users,
      },
    });
  };

  const editUser = async (data) => {
    await setDoc(doc(DB, 'users', state.currentUser.UID), data);
    const indexUser = state.userList.indexOf(state.userList.find((user) => user.UID === state.currentUser.UID));
    const newList = [...state.userList];
    newList[indexUser] = data;
    dispatch({
      type: ACTION.LIST,
      payload: {
        Users: newList,
      },
    });
    resetCurrentUser();
  };

  const deleteUser = async (user, profilePic, newList) => {
    deleteDocument(profilePic);
    await deleteDoc(doc(DB, 'users', user));
    dispatch({
      type: ACTION.LIST,
      payload: {
        Users: newList,
      },
    });
  };

  const deleteOneUser = async (user) => {
    const docRef = doc(DB, 'users', user);
    const docSnap = await getDoc(docRef);

    if (docSnap.exists()) {
      deleteDocument(docSnap.data().photoURL);
      await deleteDoc(doc(DB, 'users', user));
    }
  };

  const deleteMultiUsers = async (users, newList) => {
    users.forEach((user) => {
      deleteOneUser(user);
    });
    dispatch({
      type: ACTION.LIST,
      payload: {
        Users: newList,
      },
    });
  };

  const getUser = async (id) => {
    const docRef = doc(DB, 'users', id);
    const docSnap = await getDoc(docRef);
    if (docSnap.exists()) {
      dispatch({
        type: ACTION.USER,
        payload: {
          User: docSnap.data(),
        },
      });
    } else {
      console.log('No such document!');
    }
  };

  const resetCurrentUser = () => {
    dispatch({
      type: ACTION.USER,
      payload: {
        User: null,
      },
    });
  };

  return (
    <UserContext.Provider
      value={{
        ...state,
        method: 'firebase',
        getAllUser,
        deleteUser,
        getUser,
        editUser,
        deleteMultiUsers,
        resetCurrentUser,
      }}
    >
      {children}
    </UserContext.Provider>
  );
}

export { UserContext, UserProvider };
