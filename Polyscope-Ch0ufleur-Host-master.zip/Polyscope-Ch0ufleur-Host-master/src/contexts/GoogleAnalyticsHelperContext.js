import { createContext, useCallback } from 'react';
import { PropTypes } from 'prop-types';
import { useFirebaseApp } from 'reactfire';
import { getFunctions, httpsCallable } from 'firebase/functions';
import { format, startOfMonth, startOfWeek, startOfYear } from 'date-fns';

const GoogleAnalyticsHelperContext = createContext({});

GoogleAnalyticsHelperProvider.propTypes = {
  children: PropTypes.node,
};
function GoogleAnalyticsHelperProvider({ children }) {
  const firebaseApp = useFirebaseApp();

  const getGoogleAnalyticsQueryConfig = (range) => {
    const now = new Date();
    const formatString = 'yyyy-MM-dd';

    let startDate;
    const endDate = 'today';

    switch (range) {
      case 'week':
        startDate = format(startOfWeek(now), formatString);
        break;
      case 'month':
        startDate = format(startOfMonth(now), formatString);
        break;
      case 'year':
        startDate = format(startOfYear(now), formatString);
        break;
      case 'all':
      default:
        startDate = format(new Date(0), formatString);
    }

    return {
      startDate,
      endDate,
    };
  };

  const getGoogleAnalyticsReport = useCallback(
    async (reportRequest) => {
      try {
        const functions = getFunctions(firebaseApp);

        const runReport = httpsCallable(functions, 'runReport');

        const { data } = await runReport(reportRequest);

        return data;
      } catch (e) {
        console.error(e);
        return null;
      }
    },
    [firebaseApp]
  );

  return (
    <GoogleAnalyticsHelperContext.Provider
      value={{
        getGoogleAnalyticsQueryConfig,
        getGoogleAnalyticsReport,
      }}
    >
      {children}
    </GoogleAnalyticsHelperContext.Provider>
  );
}

export { GoogleAnalyticsHelperContext, GoogleAnalyticsHelperProvider };
