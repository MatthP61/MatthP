/* eslint-disable no-multi-assign */
import {
  getFirestore,
  collection,
  query,
  where,
  addDoc,
  deleteDoc,
  getDocs,
  updateDoc,
  doc,
  limit,
  orderBy,
} from 'firebase/firestore';
import PropTypes from 'prop-types';
import { createContext, useReducer, useEffect, useContext } from 'react';
import { useFirebaseApp } from 'reactfire';
import { CalendarContext } from './CalendarContext';
import { deleteDocument } from '../components/atoms/FirebaseFunctions';
import { fTimestamp } from '../utils/formatTime';

const ACTION = {
  VOLUME_LIST: 'volumeList',
  ADD_VOLUME: 'addVolume',
  ADD_EDITION: 'addEdition',
  EDITION_LIST: 'listEditionsVolume',
  DELETE_EDITION: 'deleteEdition',
  DELETE_VOLUME: 'deleteVolume',
  FUTURE_EDITION: 'no_publish',
  CURRENT_EDITION: 'current',
  ADD_KAPOTE: 'addKapote',
};

const initialState = {
  VolumeList: [],
  EditionByVolumeList: [],
  saveEditions: new Map(),
  futureEditions: [],
  lastEdition: {},
  currentVolume: '',
};

const KAPOTE = 'kapote';

const reducer = (state, action) => {
  const { Volume, VolumeList, Edition, EditionVolume, KapoteList, currentList, currentVolume } = action.payload;
  let tmpList = [];
  switch (action.type) {
    case ACTION.VOLUME_LIST:
      return {
        ...state,
        VolumeList,
        currentVolume,
      };
    case ACTION.ADD_VOLUME:
      return {
        ...state,
        VolumeList: [...state.VolumeList, Volume].sort((a, b) => (a.number < b.number ? 1 : -1)),
        currentVolume: Volume.name,
      };
    case ACTION.ADD_EDITION:
      tmpList = state.saveEditions;
      tmpList.set(Volume, [...tmpList.get(Volume), Edition]);
      if (tmpList.has(KAPOTE) && Edition.kapote) {
        tmpList.set(KAPOTE, [...tmpList.get(KAPOTE), Edition]);
      }
      return {
        ...state,
        EditionByVolumeList: tmpList.get(Volume),
        saveEditions: tmpList,
        currentVolume,
      };
    case ACTION.ADD_KAPOTE:
      tmpList = state.saveEditions;
      if (tmpList.has(KAPOTE) && Edition.kapote) {
        tmpList.set(KAPOTE, [...tmpList.get(KAPOTE), Edition]);
      }
      return {
        ...state,
        saveEditions: tmpList,
      };
    case ACTION.EDITION_LIST:
      tmpList = state.saveEditions;
      tmpList.set(Volume, EditionVolume);
      return {
        ...state,
        EditionByVolumeList: EditionVolume,
        saveEditions: tmpList,
        currentVolume,
      };
    case ACTION.DELETE_EDITION:
      tmpList = state.saveEditions;
      tmpList.set(Volume, EditionVolume);
      if (KapoteList !== undefined) {
        tmpList.set(KAPOTE, KapoteList);
      }
      return {
        ...state,
        EditionByVolumeList: currentList,
        saveEditions: tmpList,
      };
    case ACTION.DELETE_VOLUME:
      return {
        ...state,
        VolumeList,
        currentVolume: VolumeList[0].name,
      };
    case ACTION.FUTURE_EDITION:
      return {
        ...state,
        futureEditions: EditionVolume,
      };
    case ACTION.CURRENT_EDITION:
      return {
        ...state,
        lastEdition: Edition,
      };
    default:
      return state;
  }
};

const EditionContext = createContext(initialState);

// ----------------------------------------------------------------------

EditionProvider.propTypes = {
  children: PropTypes.node,
};

function EditionProvider({ children }) {
  const firebaseApp = useFirebaseApp();
  const DB = getFirestore(firebaseApp);
  const editionRef = collection(DB, 'editions');
  const volumeRef = collection(DB, 'volumes');
  const { createEvent } = useContext(CalendarContext);

  const [state, dispatch] = useReducer(reducer, initialState);

  // -------------------------------------

  useEffect(() => {
    getVolumes();
    getFutureEdition();
  }, []);

  const getLastVolume = async () => {
    const todayDate = fTimestamp(Date.now());
    const q = query(
      editionRef,
      where('publishDate', '<=', todayDate),
      orderBy('publishDate', 'desc'),
      orderBy('volume', 'desc'),
      orderBy('number', 'desc'),
      limit(1)
    );

    const querySnapshot = await getDocs(q);
    if (querySnapshot.docs.length > 0) {
      const Edition = querySnapshot.docs[0].data();

      dispatch({
        type: ACTION.CURRENT_EDITION,
        payload: {
          Edition,
        },
      });
    }
  };

  const getVolumes = async () => {
    const q = query(volumeRef);
    const volumes = [];
    const querySnapshot = await getDocs(q);

    if (!querySnapshot.empty) {
      querySnapshot.forEach((doc) => {
        volumes.push(doc.data());
      });

      const VolumeList = volumes.sort((a, b) => (a.number < b.number ? 1 : -1));

      dispatch({
        type: ACTION.VOLUME_LIST,
        payload: {
          VolumeList,
          currentVolume: VolumeList[0].name,
        },
      });
    } else {
      console.log('no volumes in the list!');
    }
  };

  const getEditionsVK = async (Volume) => {
    if (Volume.length === 0) {
      return;
    }

    if (Volume === 'Kapoté') {
      getKapote();
    } else {
      getEditionsByVolume(Volume.slice(7));
    }
  };

  const getEditionsByVolume = async (Volume) => {
    let EditionVolume = [];
    if (state.saveEditions.has(Volume)) {
      EditionVolume = state.saveEditions.get(Volume);
    } else {
      const q = query(editionRef, where('volume', '==', parseInt(Volume, 10)), orderBy('number'));
      const querySnapshot = await getDocs(q);

      querySnapshot.forEach((doc) => {
        EditionVolume.push(doc.data());
      });
    }

    dispatch({
      type: ACTION.EDITION_LIST,
      payload: {
        EditionVolume,
        Volume,
        currentVolume: `Volume ${Volume}`,
      },
    });
  };

  const getFutureEdition = async () => {
    const EditionVolume = [];
    if (state.futureEditions.length === 0) {
      const q = query(editionRef, where('publishDate', '>', fTimestamp(Date.now())));
      const querySnapshot = await getDocs(q);

      querySnapshot.forEach((doc) => {
        EditionVolume.push(doc.data());
      });
      dispatch({
        type: ACTION.FUTURE_EDITION,
        payload: {
          EditionVolume,
        },
      });
    }
  };

  const getKapote = async () => {
    let EditionVolume = [];

    if (state.saveEditions.has(KAPOTE)) {
      EditionVolume = state.saveEditions.get(KAPOTE);
    } else {
      const q = query(editionRef, where(KAPOTE, '==', true), orderBy('volume', 'desc'), orderBy('number', 'desc'));
      const querySnapshot = await getDocs(q);
      querySnapshot.forEach((doc) => {
        EditionVolume.push(doc.data());
      });
    }

    dispatch({
      type: ACTION.EDITION_LIST,
      payload: {
        EditionVolume,
        Volume: KAPOTE,
      },
    });
  };

  const uploadEdition = async (edition) => {
    if (!edition.publishNow) {
      const eventDate = new Date(edition.publishDate);
      await createEvent({
        title: `Volume ${edition.volume} Numéro ${edition.number}`,
        description: `Volume ${edition.volume} Numéro ${edition.number}`,
        textColor: '#7A0C2E',
        allDay: true,
        start: eventDate,
        end: eventDate,
      }).then((value) => {
        edition.eventID = value;
      });
    }

    await addDoc(editionRef, edition).then(async (docRef) => {
      await updateDoc(docRef, { UID: docRef?.id });
      edition.UID = docRef?.id;
    });

    const volumeName = `Volume ${edition.volume}`;
    if (!state.saveEditions.has(edition.volume.toString())) {
      await getEditionsByVolume(edition.volume.toString());
      dispatch({
        type: ACTION.ADD_KAPOTE,
        payload: {
          Edition: edition,
        },
      });
    } else {
      dispatch({
        type: ACTION.ADD_EDITION,
        payload: {
          Edition: edition,
          Volume: edition.volume.toString(),
          currentVolume: volumeName,
        },
      });
    }

    if (state.VolumeList.filter((v) => v.name === volumeName).length === 0) {
      const volumeObject = { name: volumeName, number: edition.volume };
      await addDoc(volumeRef, volumeObject).then(async (volRef) => {
        await updateDoc(volRef, { UID: volRef?.id });
        volumeObject.UID = volRef?.id;
      });

      dispatch({
        type: ACTION.ADD_VOLUME,
        payload: {
          Volume: volumeObject,
        },
      });
    }
  };

  const deleteEdition = async (UID, cover, pdf, newList, currentVolume, isKapote, Volume, eventID) => {
    deleteDocument(cover);
    deleteDocument(pdf);
    if (eventID) {
      await deleteDoc(doc(DB, 'calendrier', eventID));
    }
    await deleteDoc(doc(DB, 'editions', UID));

    let EditionVolume = [];
    let KapoteList = [];
    let currentList = [];

    if (isKapote && currentVolume === 'Kapoté' && state.saveEditions.has(Volume)) {
      EditionVolume = state.saveEditions.get(Volume).filter((v) => v.UID !== UID);
      KapoteList = currentList = newList;
    } else if (isKapote && state.saveEditions.has(KAPOTE)) {
      EditionVolume = currentList = newList;
      KapoteList = state.saveEditions.get(KAPOTE).filter((v) => v.UID !== UID);
    } else {
      EditionVolume = currentList = newList;
      KapoteList = state.saveEditions.get(KAPOTE);
    }

    dispatch({
      type: ACTION.DELETE_EDITION,
      payload: {
        EditionVolume,
        KapoteList,
        Volume,
        currentList,
      },
    });

    if (EditionVolume.length === 0) {
      deleteVolume(`Volume ${Volume}`);
    }
  };

  const deleteVolume = async (currentVolume) => {
    const VolumeList = state.VolumeList.filter((vol) => vol.name !== currentVolume);
    const q = query(volumeRef, where('name', '==', currentVolume));
    const querySnapshot = await getDocs(q);
    let volumeUID = '';
    querySnapshot.forEach((doc) => {
      volumeUID = doc.data().UID;
    });

    if (!querySnapshot.empty) {
      await deleteDoc(doc(DB, 'volumes', volumeUID));

      dispatch({
        type: ACTION.DELETE_VOLUME,
        payload: {
          VolumeList,
        },
      });
    }
  };

  return (
    <EditionContext.Provider
      value={{
        ...state,
        method: 'firebase',
        getVolumes,
        uploadEdition,
        deleteEdition,
        getLastVolume,
        deleteVolume,
        getEditionsVK,
      }}
    >
      {children}
    </EditionContext.Provider>
  );
}

export { EditionContext, EditionProvider };
