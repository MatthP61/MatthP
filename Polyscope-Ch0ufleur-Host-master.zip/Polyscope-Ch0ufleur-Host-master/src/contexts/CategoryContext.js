import PropTypes from 'prop-types';
import { createContext, useEffect, useReducer } from 'react';
import {
  getFirestore,
  collection,
  query,
  where,
  addDoc,
  getDocs,
  getDoc,
  updateDoc,
  doc,
  deleteDoc,
  setDoc,
} from 'firebase/firestore';
import { useFirebaseApp } from 'reactfire';
import { deleteDocument } from '../components/atoms/FirebaseFunctions';
import useAlgolia from '../hooks/useAlgolia';

const ACTION = {
  LIST: 'categoryList',
  CATEGORY: 'category',
  ADD: 'addCategory',
  ACTIVE: 'active',
};

const initialState = {
  CategoryList: [],
  categoryActiveList: [],
  currentCategory: null,
};

const reducer = (state, action) => {
  const { Categories, Category } = action.payload;
  let newList = [];
  switch (action.type) {
    case ACTION.LIST:
      return {
        ...state,
        CategoryList: Categories,
        currentCategory: null,
      };
    case ACTION.ADD:
      newList = [...state.CategoryList, Category];
      newList.sort((category1, category2) => category1.priority - category2.priority);
      return {
        ...state,
        CategoryList: newList,
      };
    case ACTION.CATEGORY:
      return {
        ...state,
        currentCategory: Category,
      };
    case ACTION.ACTIVE:
      return {
        ...state,
        categoryActiveList: Categories,
      };
    default:
      return state;
  }
};

const CategoryContext = createContext(initialState);

// ----------------------------------------------------------------------
CategoryProvider.propTypes = {
  children: PropTypes.node,
};

function CategoryProvider({ children }) {
  const firebaseApp = useFirebaseApp();
  const DB = getFirestore(firebaseApp);
  const categoryRef = collection(DB, 'categories');
  const agoliaIndex = useAlgolia();
  useEffect(() => {
    getAllCategory();
  }, []);

  const [state, dispatch] = useReducer(reducer, initialState);

  const getAllCategory = async () => {
    const q = query(collection(DB, 'categories'), where('UID', '!=', null));
    const categories = [];
    const querySnapshot = await getDocs(q);
    querySnapshot.forEach((doc) => {
      const category = doc.data();
      categories.push(category);
    });
    categories.sort((category1, category2) => category1.priority - category2.priority);
    dispatch({
      type: ACTION.LIST,
      payload: {
        Categories: categories,
      },
    });

    await getActiveCategory(categories);
  };

  const uploadCategory = async (data) => {
    await addDoc(categoryRef, data).then(async (docRef) => {
      await updateDoc(docRef, { UID: docRef?.id });
      data.UID = docRef?.id;
    });
    dispatch({
      type: ACTION.ADD,
      payload: {
        Category: data,
      },
    });
  };

  const editCategory = async (data) => {
    await setDoc(doc(DB, 'categories', state.currentCategory.UID), data);
    const indexCategory = state.CategoryList.indexOf(
      state.CategoryList.find((category) => category.UID === state.currentCategory.UID)
    );
    const newList = [...state.CategoryList];
    newList[indexCategory] = data;
    dispatch({
      type: ACTION.LIST,
      payload: {
        Categories: newList,
      },
    });
  };

  const deleteCategory = async (category, cover, newList) => {
    deleteDocument(cover);
    await deleteDoc(doc(DB, 'categories', category));
    dispatch({
      type: ACTION.LIST,
      payload: {
        Categories: newList,
      },
    });
  };

  const deleteOneCategory = async (category) => {
    const docRef = doc(DB, 'categories', category);
    const docSnap = await getDoc(docRef);

    if (docSnap.exists()) {
      deleteDocument(docSnap.data().cover);
      await deleteDoc(doc(DB, 'categories', category));
    }
  };

  const deleteMultiCategories = async (categories, newList) => {
    categories.forEach((category) => {
      deleteOneCategory(category);
    });
    dispatch({
      type: ACTION.LIST,
      payload: {
        Categories: newList,
      },
    });
  };

  const getCategory = async (id) => {
    const docRef = doc(DB, 'categories', id);
    const docSnap = await getDoc(docRef);

    if (docSnap.exists()) {
      dispatch({
        type: ACTION.CATEGORY,
        payload: {
          Category: docSnap.data(),
        },
      });
    } else {
      console.log('No such document!');
    }
  };

  const getActiveCategory = async (categories) => {
    const filteredCategories = categories.filter((category) => category.publish);
    filteredCategories.map((topic) =>
      agoliaIndex.search(topic.title).then(({ nbHits }) => {
        topic.total = nbHits;
      })
    );
    dispatch({
      type: ACTION.ACTIVE,
      payload: {
        Categories: filteredCategories,
      },
    });
  };

  const resetCurrentCategory = () => {
    dispatch({
      type: ACTION.CATEGORY,
      payload: {
        Category: null,
      },
    });
  };

  return (
    <CategoryContext.Provider
      value={{
        ...state,
        method: 'firebase',
        uploadCategory,
        getAllCategory,
        deleteCategory,
        getCategory,
        editCategory,
        deleteMultiCategories,
        resetCurrentCategory,
      }}
    >
      {children}
    </CategoryContext.Provider>
  );
}

export { CategoryContext, CategoryProvider };
