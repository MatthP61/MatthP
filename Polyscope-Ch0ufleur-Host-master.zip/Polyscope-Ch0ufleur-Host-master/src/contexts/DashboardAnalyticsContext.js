import { collection, getDocs, getFirestore, limit, orderBy, query } from 'firebase/firestore';
import PropTypes from 'prop-types';
import { createContext, useCallback, useContext, useState } from 'react';
import { useFirebaseApp } from 'reactfire';
import ReportBuilder from '../utils/ReportBuilder';
import { GoogleAnalyticsHelperContext } from './GoogleAnalyticsHelperContext';
import VisitsReportParser from '../utils/VisitsReportParser';
import i18n from '../locales/i18n';

const DashboardAnalyticsContext = createContext({});

DashboardAnalyticsProvider.propTypes = {
  children: PropTypes.node,
};
function DashboardAnalyticsProvider({ children }) {
  const { getGoogleAnalyticsQueryConfig, getGoogleAnalyticsReport } = useContext(GoogleAnalyticsHelperContext);

  const firebaseApp = useFirebaseApp();
  const DB = getFirestore(firebaseApp);
  const blogCollectionRef = collection(DB, 'blogs');

  const [allViewsTableData, setAllViewsTableData] = useState([]);

  const [allVisitsChartData, setAllVisitsChartData] = useState({
    series: [],
    categories: [],
  });

  const [userPlatformChartData, setUserPlatformChartData] = useState({
    data: [],
    categories: [],
  });

  const getVisitsForUIDs = useCallback(
    async (UIDs) => {
      const { startDate, endDate } = getGoogleAnalyticsQueryConfig('all');

      const reportRequest = new ReportBuilder()
        .addDateRange(startDate, endDate)
        .addMetric('screenPageViews')
        .addDimension('pagePath')
        .dimensionEndsWithAny('pagePath', UIDs)
        .build();

      const queryData = await getGoogleAnalyticsReport(reportRequest);

      // convert array to object
      const pageViews = UIDs.reduce((obj, UID) => ({ ...obj, [UID]: 0 }), {});

      queryData.forEach(({ dimensionValues, metricValues }) => {
        const [pagePath] = dimensionValues;

        const [count] = metricValues;

        const [UID] = pagePath.value.split('/').slice(-1);

        pageViews[UID] = +count.value;
      });

      return pageViews;
    },
    [getGoogleAnalyticsReport]
  );

  const getBlogViews = useCallback(async () => {
    const q = query(blogCollectionRef, orderBy('createdAt', 'desc'), limit(10));

    const querySnapshot = await getDocs(q);

    let blogData = {};

    // note: querySnapshot is not an array, despite having a forEach method
    querySnapshot.forEach((doc) => {
      if (!doc.exists()) return;

      const UID = doc.id;

      const title = doc.get('title') ?? '';

      const category = doc.get('category');

      const createdAtTimestamp = doc.get('createdAt');
      const createdAt = new Date(createdAtTimestamp);

      blogData = {
        ...blogData,
        [UID]: {
          title,
          category,
          createdAt,
          views: 0,
        },
      };
    });

    const UIDs = Object.keys(blogData);
    const blogViews = await getVisitsForUIDs(UIDs);

    Object.entries(blogViews).forEach(([UID, views]) => {
      blogData[UID].views = views;
    });

    setAllViewsTableData(blogData);
  }, [getVisitsForUIDs]);

  const getSiteVisits = useCallback(
    async (range) => {
      const { startDate, endDate } = getGoogleAnalyticsQueryConfig(range);

      const newSerie = {
        name: i18n.t('dashboard.charts.visits.serieName'),
        data: [],
      };
      const newCategoryData = [];

      const addData = (category, visitCount) => {
        newCategoryData.push(category);
        newSerie.data.push(visitCount);
      };

      const reportRequest = new ReportBuilder()
        .addDateRange(startDate, endDate)
        .addMetric('sessions')
        .addDimension('date')
        .build();

      const queryData = await getGoogleAnalyticsReport(reportRequest);

      if (queryData) {
        const reportParser = new VisitsReportParser(range);
        reportParser.parseData(queryData, addData);
      }

      setAllVisitsChartData({
        series: [newSerie],
        categories: newCategoryData,
      });
    },
    [getGoogleAnalyticsReport]
  );

  const getUserPlatforms = useCallback(
    async (range) => {
      const { startDate, endDate } = getGoogleAnalyticsQueryConfig(range);

      const newSerie = {
        data: [],
        categories: [],
      };

      const addData = (label, count) => {
        newSerie.categories.push(label);
        newSerie.data.push(count);
      };

      const reportRequest = new ReportBuilder()
        .addDateRange(startDate, endDate)
        .addMetric('sessions')
        .addDimension('deviceCategory')
        .build();

      const queryData = await getGoogleAnalyticsReport(reportRequest);

      if (queryData) {
        queryData.forEach(({ dimensionValues, metricValues }) => {
          const platform = dimensionValues[0].value;
          const sessionCount = metricValues[0].value;

          addData(platform, +sessionCount);
        });
      }

      setUserPlatformChartData(newSerie);
    },
    [getGoogleAnalyticsReport]
  );

  return (
    <DashboardAnalyticsContext.Provider
      value={{
        getSiteVisits,
        getUserPlatforms,
        getBlogViews,
        getVisitsForUIDs,
        allViewsTableData,
        allVisitsChartData,
        userPlatformChartData,
      }}
    >
      {children}
    </DashboardAnalyticsContext.Provider>
  );
}

export { DashboardAnalyticsContext, DashboardAnalyticsProvider };
