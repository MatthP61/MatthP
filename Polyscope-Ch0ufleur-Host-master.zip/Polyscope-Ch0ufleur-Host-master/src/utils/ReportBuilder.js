/* eslint-disable max-classes-per-file */
class StringFilter {
  constructor(matchType, value) {
    this.matchType = matchType;
    this.value = value;
  }
}

class OrFilterBuilder {
  #name;

  constructor(name) {
    this.#name = name;
  }

  addValues(matchType, values) {
    this.orGroup.expressions = values.map((value) => {
      const stringFilter = new StringFilter(matchType, value);

      return {
        filter: {
          fieldName: this.#name,
          stringFilter: { ...stringFilter },
        },
      };
    });

    return this;
  }

  build() {
    return { ...this };
  }

  orGroup = {
    expressions: [],
  };
}

export default class ReportBuilder {
  dateRanges = [];

  metrics = [];

  dimensions = [];

  addDateRange(startDate, endDate) {
    this.dateRanges.push({
      startDate,
      endDate,
    });

    return this;
  }

  addDimension(dimensionName) {
    this.dimensions.push({ name: dimensionName });

    return this;
  }

  addMetric(metricName) {
    this.metrics.push({ name: metricName });

    return this;
  }

  dimensionEndsWithAny(dimension, strings) {
    this.dimensionFilter = new OrFilterBuilder(dimension).addValues('ENDS_WITH', strings).build();

    return this;
  }

  build() {
    return { ...this };
  }
}
