import { addDays, addMonths, isSameDay, isSameMonth, parse } from 'date-fns';
import DateHelper from './DateHelper';

export default class VisitsReportParser {
  startDate;

  endDate = new Date();

  currentDate;

  range;

  queryData;

  dataToAdd = {};

  constructor(range) {
    this.range = range;

    const { startDate, endDate } = DateHelper.getDateRangeBounds(range);
    this.startDate = startDate;
    this.endDate = endDate;
  }

  #hasMissingData(expectedLabel) {
    return this.dataToAdd[expectedLabel] === undefined;
  }

  parseData(queryData, addDataCallback) {
    this.#prepareData();

    // aggregate
    queryData.forEach(({ dimensionValues, metricValues }) => {
      const [yyyyMMdd] = dimensionValues;
      const date = parse(yyyyMMdd.value, 'yyyyMMdd', new Date());

      const [count] = metricValues;
      const label = DateHelper.getLabelFromRange(this.range, date);

      let currentCount = this.dataToAdd[label] ?? 0;
      currentCount += +count.value;
      this.dataToAdd[label] = currentCount;
    });

    this.#addAllData(addDataCallback);
  }

  #addAllData(addDataCallback) {
    Object.entries(this.dataToAdd).forEach(([key, value]) => {
      addDataCallback(key, value);
    });
  }

  #prepareData() {
    this.dataToAdd = {};

    this.currentDate = new Date(this.startDate);
    let label = DateHelper.getLabelFromRange(this.range, this.startDate);

    while (this.#hasMissingData(label) && !this.#hasReachedEndDate()) {
      this.dataToAdd[label] = 0;

      this.#getNextDate();
      label = DateHelper.getLabelFromRange(this.range, this.currentDate);
    }
  }

  #getNextDate() {
    switch (this.range) {
      case 'week':
      case 'month':
        this.currentDate = addDays(this.currentDate, 1);
        break;
      case 'year':
        this.currentDate = addMonths(this.currentDate, 1);
        break;
      case 'all':
      default:
        this.currentDate = addDays(this.currentDate, 1);
    }
  }

  #hasReachedEndDate() {
    switch (this.range) {
      case 'week':
      case 'month':
        return isSameDay(this.currentDate, this.endDate);
      case 'year':
        return isSameMonth(this.currentDate, this.endDate);
      default:
        return true;
    }
  }
}
