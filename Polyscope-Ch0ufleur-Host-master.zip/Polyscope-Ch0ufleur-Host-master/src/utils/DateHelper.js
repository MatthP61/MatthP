import { format, startOfMonth, startOfWeek, startOfYear } from 'date-fns';
import * as dateFnsLocales from 'date-fns/locale';
import i18n from '../locales/i18n';

export default class DateHelper {
  static getDateRangeBounds(range) {
    const now = new Date();

    let startDate;
    const endDate = now;

    switch (range) {
      case 'week':
        startDate = startOfWeek(now);
        break;
      case 'month':
        startDate = startOfMonth(now);
        break;
      case 'year':
        startDate = startOfYear(now);
        break;
      default:
        startDate = new Date(0);
    }

    return {
      startDate,
      endDate,
    };
  }

  static getLabelFromRange(range, date) {
    if (range === 'week') return this.formatLocale(date, 'eee');
    if (range === 'month') return `${this.formatLocale(date, 'dd MMM')}`;
    if (range === 'year') return this.formatLocale(date, 'MMM');

    return format(date, 'P');
  }

  static formatLocale(date, formatStr) {
    const localeCode = i18n.t('locale') || 'enUS';
    const locale = dateFnsLocales[localeCode];

    return format(date, formatStr, { locale });
  }
}
