export default class StringHelper {
  static Capitalize(str) {
    return str.replace(/^\w/);
  }
}
