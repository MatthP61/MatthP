import React, { useContext } from 'react';

import PropTypes from 'prop-types';
import { Navigate } from 'react-router-dom';
// hooks
import useAuth from '../hooks/useAuth';
import { BlogContext } from '../contexts/BlogContext';
// ----------------------------------------------------------------------

BlogGuard.propTypes = {
  children: PropTypes.node,
  isBlog: PropTypes.bool,
};

export default function BlogGuard({ children, isBlog }) {
  const { isAuthenticated, user, isAdmin } = useAuth();
  const { currentBlog } = useContext(BlogContext);
  if (!isAuthenticated) {
    return <Navigate to="/404" replace />;
  }

  if (isBlog && !isAdmin && currentBlog && currentBlog.author.UID !== user.UID) {
    return <Navigate to="/404" replace />;
  }

  return <>{children}</>;
}
