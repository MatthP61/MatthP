// @mui
import { Grid, Container } from '@mui/material';
// components
import Page from '../components/atoms/Page';
import TextForm from '../sections/sendBlog/TextForm';
import i18n from '../locales/i18n';
import { RootStyle } from '../utils/GeneralStyle';
import { AboutHero } from '../sections/about';

// ----------------------------------------------------------------------

export default function Contact() {
  return (
    <Page title={i18n.t('sendText.titlePage')}>
      <RootStyle>
        <AboutHero
          titlePart1={i18n.t('sendText.title1')}
          titlePart2={i18n.t('sendText.title2')}
          titlePart3={i18n.t('sendText.title3')}
        />
        <Container sx={{ my: 10 }}>
          <Grid container spacing={10}>
            <Grid item xs={12} md={12}>
              <TextForm />
            </Grid>
          </Grid>
        </Container>
      </RootStyle>
    </Page>
  );
}
