// @mui
import { styled } from '@mui/material/styles';
import { Grid } from '@mui/material';
// components
import Page from '../components/atoms/Page';
// sections
import { AppFeaturedBlog } from '../sections/@dashboard/general/app';
import { HomeMinimal, HomePopulaire, HomeRecent } from '../sections/home';
import i18n from '../locales/i18n';
// ----------------------------------------------------------------------

const RootStyle = styled('div')(() => ({
  height: '100%',
}));

const ContentStyle = styled('div')(({ theme }) => ({
  overflow: 'hidden',
  position: 'relative',
  backgroundColor: theme.palette.background.default,
}));

// ----------------------------------------------------------------------

export default function HomePage() {
  return (
    <Page title={i18n.t('polyscope')}>
      <RootStyle>
        <ContentStyle>
          <Grid
            item
            sx={{
              mt: { md: 11, xs: 8 },
            }}
            xs={12}
            md={12}
          >
            <AppFeaturedBlog />
          </Grid>
          <HomeMinimal />
          <HomeRecent />
          <HomePopulaire />
        </ContentStyle>
      </RootStyle>
    </Page>
  );
}
