import React, { useContext } from 'react';

// @mui
import { Divider } from '@mui/material';
// components
import Page from '../components/atoms/Page';
import { AboutHero, AboutTeam, AboutVision } from '../sections/about';
import i18n from '../locales/i18n';
import { AboutContext } from '../contexts/AboutContext';
import { TeamContext } from '../contexts/TeamContext';
import { RootStyle } from '../utils/GeneralStyle';

// ----------------------------------------------------------------------

export default function About() {
  const { slogan, text, vision } = useContext(AboutContext);
  const { title, subtitle, memberList } = useContext(TeamContext);

  return (
    <Page title={i18n.t('aboutus.title')}>
      <RootStyle>
        <AboutHero
          slogan={slogan}
          titlePart1={i18n.t('aboutus.titlePart1')}
          titlePart2={i18n.t('aboutus.titlePart2')}
          titlePart3={i18n.t('aboutus.titlePart3')}
        />

        <AboutVision text={text} vision={vision} />

        <Divider orientation="vertical" sx={{ my: 10, mx: 'auto', width: 2, height: 40 }} />

        <AboutTeam title={title} subtitle={subtitle} members={memberList} />
      </RootStyle>
    </Page>
  );
}
