import { useContext } from 'react';
// @mui
import { Box, Card, Container } from '@mui/material';
// hooks
import useSettings from '../hooks/useSettings';
// components
import Page from '../components/atoms/Page';
import Markdown from '../components/atoms/Markdown';
import HeaderBreadcrumbs from '../components/atoms/HeaderBreadcrumbs';
// sections
import { GeneralSettingsContext } from '../contexts/GeneralSettingsContext';
import i18n from '../locales/i18n';

// ----------------------------------------------------------------------

export default function TermCondition() {
  const { themeStretch } = useSettings();
  const { termCondition } = useContext(GeneralSettingsContext);

  return (
    <Page title={i18n.t('termCondition.politic')}>
      <Container
        sx={{
          pt: { md: 9, xs: 9 },
        }}
        maxWidth={themeStretch ? false : 'lg'}
      >
        <HeaderBreadcrumbs
          heading={i18n.t('termCondition.politic')}
          links={[
            { name: i18n.t('home.home'), href: '/' },
            { name: i18n.t('termCondition.politic'), href: '/terms-conditions' },
          ]}
        />
        <Card>
          <Box sx={{ p: { xs: 3, md: 5 } }}>
            <Markdown children={termCondition} />
          </Box>
        </Card>
        <br />
      </Container>
    </Page>
  );
}
