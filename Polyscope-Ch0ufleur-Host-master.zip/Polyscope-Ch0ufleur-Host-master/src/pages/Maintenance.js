import { Link as RouterLink } from 'react-router-dom';
// @mui
import { styled } from '@mui/material/styles';
import { Button, Typography, Container } from '@mui/material';
// components
import Page from '../components/atoms/Page';
//
import { MaintenanceIllustration } from '../assets';
import i18n from '../locales/i18n';
// ----------------------------------------------------------------------

const RootStyle = styled('div')(({ theme }) => ({
  height: '100%',
  display: 'flex',
  alignItems: 'center',
  paddingTop: theme.spacing(15),
  paddingBottom: theme.spacing(10),
}));

// ----------------------------------------------------------------------

export default function Maintenance() {
  return (
    <Page title={i18n.t('maintenance.title')} sx={{ height: 1 }}>
      <RootStyle>
        <Container sx={{ textAlign: 'center' }}>
          <Typography variant="h3" paragraph>
            {i18n.t('maintenance.msg')}
          </Typography>
          <Typography sx={{ color: 'text.secondary' }}> {i18n.t('maintenance.text')}</Typography>

          <MaintenanceIllustration sx={{ my: 10, height: 240 }} />

          <Button sx={{ textTransform: 'none' }} to="/" size="large" variant="contained" component={RouterLink}>
            {i18n.t('page404.goHome')}
          </Button>
        </Container>
      </RootStyle>
    </Page>
  );
}
