import React, { useContext, useCallback, useEffect, useState } from 'react';
// @mui
import { styled } from '@mui/material/styles';
import { Grid, Container, Box, Typography } from '@mui/material';
import { useParams } from 'react-router-dom';
import { HEADER } from '../config';
// hooks
import useIsMountedRef from '../hooks/useIsMountedRef';
import useAlgolia from '../hooks/useAlgolia';
// components
import Page from '../components/atoms/Page';
import { BlogSidebar, BlogPostListCategory, BlogPostsSearch } from '../sections/@dashboard/blog';
// contexts
import { BlogContext } from '../contexts/BlogContext';
import { AdContext } from '../contexts/AdContext';
import i18n from '../locales/i18n';

// ----------------------------------------------------------------------

const RootStyle = styled('div')(({ theme }) => ({
  paddingTop: HEADER.MOBILE_HEIGHT,
  [theme.breakpoints.up('md')]: {
    paddingTop: HEADER.HEADER_DESKTOP_HEIGHT,
  },
}));

// ----------------------------------------------------------------------

export default function BlogPostsCategory() {
  const { BlogList } = useContext(BlogContext);
  const { category } = useParams();
  const isMountedRef = useIsMountedRef();
  const [currentPage, setCurrentPage] = useState(0);
  const [totalPage, setTotalPage] = useState(0);
  const index = useAlgolia();

  const [posts, setPost] = useState([]);

  const [error, setError] = useState(null);
  const { adActiveList } = useContext(AdContext);

  const [ad, setAd] = useState({});

  const handleChangePage = (event, value) => {
    setCurrentPage(value - 1);
  };

  useEffect(() => {
    if (adActiveList) {
      const newAd = adActiveList[Math.floor(Math.random() * adActiveList?.length)];
      setAd({
        title: newAd?.title,
        description: newAd?.description,
        imageUrl: newAd?.image,
        path: newAd?.link,
      });
    }
  }, [adActiveList]);

  const getPosts = useCallback(async () => {
    try {
      if (isMountedRef.current) {
        index
          .search(category, {
            page: currentPage,
            hitsPerPage: 5,
          })
          .then(({ hits, nbPages }) => {
            setTotalPage(nbPages);
            setPost(hits);
          });
      }
    } catch (error) {
      console.error(error);
      setError(error.message);
    }
  }, [isMountedRef, category, currentPage]);

  useEffect(() => {
    getPosts();
  }, [getPosts]);

  return (
    <Page title={`${i18n.t('blogs')} : ${category}`}>
      <RootStyle>
        <Box
          spacing={2}
          sx={{
            mx: 2.5,
            display: { xs: 'flex', md: 'none' },
            my: 3,
          }}
          direction="row"
          alignItems="center"
          justifyContent="center"
        >
          <BlogPostsSearch />
        </Box>
        <Container sx={{ mt: { xs: 4, md: 10 } }}>
          <Grid container spacing={{ md: 8 }}>
            <Grid item xs={12} md={8}>
              {posts.length > 0 && (
                <BlogPostListCategory
                  posts={posts}
                  total={totalPage}
                  page={currentPage}
                  handleChange={handleChangePage}
                />
              )}
            </Grid>

            <Grid item xs={12} md={4}>
              {BlogList.length > 0 && (
                <BlogSidebar
                  recentPosts={{
                    list: BlogList?.slice(-4),
                    path: '/blog/post',
                  }}
                  advertisement={ad}
                />
              )}
            </Grid>
          </Grid>
        </Container>
        {error && <Typography variant="h6">404 {error}!</Typography>}
      </RootStyle>
    </Page>
  );
}
