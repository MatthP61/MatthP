import { useEffect, useState, useCallback, useContext } from 'react';
import { useParams } from 'react-router-dom';
// @mui
import { Box, Card, Divider, Container, Typography } from '@mui/material';
// hooks
import useIsMountedRef from '../hooks/useIsMountedRef';
// utils
import { fDate } from '../utils/formatTime';
// components
import Page from '../components/atoms/Page';
import Markdown from '../components/atoms/Markdown';
import HeaderBreadcrumbs from '../components/atoms/HeaderBreadcrumbs';
import { SkeletonPost } from '../components/organismes/skeleton';
// sections
import { BlogPostHero, BlogPostTags, BlogRelatedList } from '../sections/@dashboard/blog';
import { BlogContext } from '../contexts/BlogContext';
import i18n from '../locales/i18n';
import useAlgolia from '../hooks/useAlgolia';

// ----------------------------------------------------------------------

export default function BlogPost() {
  const isMountedRef = useIsMountedRef();
  const { title } = useParams();
  const { currentBlog, getOneBlog } = useContext(BlogContext);
  const index = useAlgolia();
  const [post, setPost] = useState(null);
  const [relatedPosts, setRelatedPosts] = useState([]);
  const [error, setError] = useState(null);
  const getPost = useCallback(async () => {
    try {
      if (isMountedRef.current) {
        await getOneBlog(title).then((result) => {
          index.search(result?.tags).then(({ hits }) => {
            const filteredList = hits.filter((blog) => blog.objectID !== result?.UID);
            setRelatedPosts(filteredList);
          });
        });
      }
    } catch (error) {
      setError(error.message);
    }
  }, [isMountedRef, title]);

  const getRecentPosts = useCallback(async () => {}, [isMountedRef, title]);

  useEffect(() => {
    getPost();
    getRecentPosts();
  }, [getRecentPosts, getPost]);

  useEffect(() => {
    setPost(currentBlog);
  }, [currentBlog]);

  return (
    <Page title={post?.title} meta={post?.metaDescription} cover={post?.cover} id={post?.UID}>
      <Container
        sx={{
          pt: { md: 15, xs: 12 },
        }}
      >
        <HeaderBreadcrumbs
          heading={currentBlog?.title || ' '}
          links={[
            { name: i18n.t('home.home'), href: '/' },
            { name: i18n.t('blogs'), href: '/blogs' },
            { name: currentBlog?.title || ' ' },
          ]}
        />

        {post && (
          <Card>
            <BlogPostHero post={post} />

            <Box sx={{ p: { xs: 3, md: 5 } }}>
              <Typography variant="h6" sx={{ mb: 5 }}>
                {post?.description}
              </Typography>

              <Markdown children={post?.body} />

              <Box sx={{ my: 5 }}>
                <Divider />
                <BlogPostTags post={post} />
                <Divider />
                {post?.editDates?.length > 0 && (
                  <Typography variant="caption" sx={{ mb: 5 }}>
                    {i18n.t('blog.editDates')} {fDate(post.editDates[post.editDates.length - 1])}
                  </Typography>
                )}
              </Box>
            </Box>
          </Card>
        )}
        <br />

        {!post && !error && <SkeletonPost />}

        {error && <Typography variant="h6">404 {error}!</Typography>}
        {relatedPosts.length > 0 && <BlogRelatedList posts={relatedPosts.slice(0, 4)} />}
      </Container>
    </Page>
  );
}
