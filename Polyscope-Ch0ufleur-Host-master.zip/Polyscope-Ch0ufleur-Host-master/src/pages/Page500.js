import { Link as RouterLink } from 'react-router-dom';
import { styled } from '@mui/material/styles';
// @mui
import { Box, Button, Typography, Container } from '@mui/material';
// components
import Page from '../components/atoms/Page';
import { SeverErrorIllustration } from '../assets';
import i18n from '../locales/i18n';

// ----------------------------------------------------------------------

const RootStyle = styled('div')(({ theme }) => ({
  display: 'flex',
  height: '100%',
  alignItems: 'center',
  paddingTop: theme.spacing(15),
  paddingBottom: theme.spacing(10),
}));

// ----------------------------------------------------------------------

export default function Page500() {
  return (
    <Page title={i18n.t('page500.500')} sx={{ height: 1 }}>
      <RootStyle>
        <Container>
          <Box sx={{ maxWidth: 480, margin: 'auto', textAlign: 'center' }}>
            <Typography variant="h3" paragraph>
              {i18n.t('page500.500')}
            </Typography>
            <Typography sx={{ color: 'text.secondary' }}>{i18n.t('page500.error')}</Typography>

            <SeverErrorIllustration sx={{ height: 260, my: { xs: 5, sm: 10 } }} />

            <Button sx={{ textTransform: 'none' }} to="/" size="large" variant="contained" component={RouterLink}>
              {i18n.t('page404.goHome')}
            </Button>
          </Box>
        </Container>
      </RootStyle>
    </Page>
  );
}
