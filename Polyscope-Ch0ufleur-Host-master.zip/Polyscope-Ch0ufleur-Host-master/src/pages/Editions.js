import React from 'react';
// @mui
import { styled, useTheme } from '@mui/material/styles';
import { Card, Grid, Container, Typography } from '@mui/material';

// components
import { MotionInView, varFade } from '../components/molecules/animate';

// Page
import Page from '../components/atoms/Page';
import ListEditions from '../sections/editions/ListEditions';
import EditionsCalendar from '../sections/editions/EditionsCalendar';

// Context
import i18n from '../locales/i18n';

// ----------------------------------------------------------------------

const RootStyle = styled('div')(({ theme }) => ({
  paddingTop: theme.spacing(8),
  [theme.breakpoints.up('md')]: {
    paddingTop: theme.spacing(11),
  },
}));

// ----------------------------------------------------------------------

export default function Editions() {
  const theme = useTheme();

  return (
    <Page title={i18n.t('editions.editions')}>
      <RootStyle>
        <Container maxWidth={'xl'}>
          <Grid
            container
            sx={{
              mb: { xs: 8, md: 8 },
            }}
            spacing={2}
          >
            <Grid
              sx={{
                textAlign: 'center',
                alignItems: 'center',
              }}
              container
              direction="column"
              display="flex"
              justify="center"
            >
              <MotionInView variants={varFade().inDown}>
                <Typography variant="h2">{i18n.t('editions.editions')}</Typography>
              </MotionInView>
            </Grid>

            <Grid item xs={12} md={8} lg={8}>
              <Card sx={{ p: 3 }} style={{ backgroundColor: theme.palette.card.background }}>
                <ListEditions />
              </Card>
            </Grid>

            <Grid item xs={12} md={4} lg={4}>
              <Card sx={{ p: 3 }} style={{ backgroundColor: theme.palette.card.background }}>
                <EditionsCalendar />
              </Card>
            </Grid>
          </Grid>
        </Container>
      </RootStyle>
    </Page>
  );
}
