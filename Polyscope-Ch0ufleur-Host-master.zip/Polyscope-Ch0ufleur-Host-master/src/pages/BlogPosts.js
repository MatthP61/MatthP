import React, { useContext, useCallback, useEffect, useState } from 'react';
// @mui
import { styled } from '@mui/material/styles';
import { Grid, Container, Box, Typography } from '@mui/material';
// config
import { HEADER } from '../config';
// components
import Page from '../components/atoms/Page';
// sections
import {
  BlogSidebar,
  BlogFeaturedPosts,
  BlogPostList,
  BlogTrendingTopics,
  BlogPostsSearch,
} from '../sections/@dashboard/blog';
import useAlgolia from '../hooks/useAlgolia';
import useIsMountedRef from '../hooks/useIsMountedRef';

// context
import { BlogContext } from '../contexts/BlogContext';
import { AdContext } from '../contexts/AdContext';
import i18n from '../locales/i18n';

// ----------------------------------------------------------------------

const RootStyle = styled('div')(({ theme }) => ({
  paddingTop: HEADER.MOBILE_HEIGHT,
  [theme.breakpoints.up('md')]: {
    paddingTop: HEADER.HEADER_DESKTOP_HEIGHT,
  },
}));

// ----------------------------------------------------------------------

export default function BlogPosts() {
  const { BlogList } = useContext(BlogContext);
  const { adActiveList } = useContext(AdContext);
  const isMountedRef = useIsMountedRef();
  const [currentPage, setCurrentPage] = useState(0);
  const [totalPage, setTotalPage] = useState(0);
  const index = useAlgolia();
  const [posts, setPost] = useState([]);
  const [ad, setAd] = useState({});
  const [error, setError] = useState(null);

  const handleChangePage = (event, value) => {
    setCurrentPage(value - 1);
  };

  useEffect(() => {
    if (adActiveList) {
      const newAd = adActiveList[Math.floor(Math.random() * adActiveList?.length)];
      setAd({
        title: newAd?.title,
        description: newAd?.description,
        imageUrl: newAd?.image,
        path: newAd?.link,
      });
    }
  }, [adActiveList]);
  const getPosts = useCallback(async () => {
    try {
      if (isMountedRef.current) {
        index
          .search('', {
            page: currentPage,
            hitsPerPage: 8,
          })
          .then(({ hits, nbPages }) => {
            setTotalPage(nbPages);
            setPost(hits);
          });
      }
    } catch (error) {
      console.error(error);
      setError(error.message);
    }
  }, [isMountedRef, currentPage]);

  useEffect(() => {
    getPosts();
  }, [getPosts]);

  return (
    <Page title={i18n.t('blogs')}>
      <RootStyle>
        <Box
          spacing={2}
          sx={{
            mx: 2.5,
            display: { xs: 'flex', md: 'none' },
            my: 3,
          }}
          direction="row"
          alignItems="center"
          justifyContent="center"
        >
          <BlogPostsSearch />
        </Box>

        {BlogList.length > 0 && <BlogFeaturedPosts posts={BlogList?.slice(-5)} />}
        <BlogTrendingTopics />

        <Container sx={{ mt: { xs: 4, md: 10 } }}>
          <Grid container spacing={{ md: 8 }}>
            <Grid item xs={12} md={8}>
              {BlogList.length > 0 && (
                <BlogPostList posts={posts} total={totalPage} page={currentPage} handleChange={handleChangePage} />
              )}
            </Grid>

            <Grid item xs={12} md={4}>
              {BlogList.length > 0 && (
                <BlogSidebar
                  recentPosts={{
                    list: BlogList?.slice(-4),
                    path: '/blog',
                  }}
                  advertisement={ad}
                />
              )}
            </Grid>
          </Grid>
        </Container>
        {error && <Typography variant="h6">404 {error}!</Typography>}
      </RootStyle>
    </Page>
  );
}
