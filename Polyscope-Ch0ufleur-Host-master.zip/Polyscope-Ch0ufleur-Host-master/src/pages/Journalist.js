import React, { useContext, useEffect, useState, useCallback } from 'react';
import { useParams } from 'react-router';
// @mui
import { styled } from '@mui/material/styles';
import { Avatar, Box, Stack, Grid, Container, Typography, Button } from '@mui/material';

// components
import { MotionInView, varFade } from '../components/molecules/animate';
import CardBox from '../components/molecules/card/CardBox';
import SocialsButton from '../components/atoms/SocialsButton';

// Page
import Page from '../components/atoms/Page';

// Context
import i18n from '../locales/i18n';
import { JournalistContext } from '../contexts/JournalistContext';

// ----------------------------------------------------------------------

const RootStyle = styled('div')(({ theme }) => ({
  paddingTop: theme.spacing(8),
  [theme.breakpoints.up('md')]: {
    paddingTop: theme.spacing(11),
  },
}));

// ----------------------------------------------------------------------

export default function Journalist() {
  const { UID } = useParams();
  const [author, setAuthor] = useState({});
  const [blogs, setBlogs] = useState([]);
  const [socialMediaLinks, setSocialMediaLinks] = useState({});
  const { getBlogs, getMoreBlogs, BlogListJournalist, disableMoreButton, getJournalist, journalist } =
    useContext(JournalistContext);

  const getBlogsList = useCallback(async () => {
    try {
      await getBlogs(UID, 4);
    } catch {
      console.log('error');
    }
  }, [UID]);

  const getJournalistInfo = useCallback(async () => {
    try {
      await getJournalist(UID);
    } catch {
      console.log('error');
    }
  }, [UID]);

  useEffect(() => {
    getBlogsList();
  }, [getBlogsList]);

  useEffect(() => {
    setBlogs(BlogListJournalist);
  }, [BlogListJournalist]);

  useEffect(() => {
    getJournalistInfo();
  }, [getJournalistInfo]);

  useEffect(() => {
    setAuthor(journalist);
    setSocialMediaLinks({
      facebook: journalist.facebook,
      instagram: journalist.instagram,
      twitter: journalist.twitter,
      linkedin: journalist.linkedin,
    });
  }, [journalist]);

  const getMore = async () => {
    await getMoreBlogs(UID, 4);
  };

  return (
    <Page title={author?.displayName || i18n.t('journalist.journalist')}>
      <RootStyle>
        <Container maxWidth={'xl'}>
          <Grid
            container
            sx={{
              mb: { xs: 8, md: 8 },
            }}
            spacing={2}
          >
            <Grid
              sx={{
                textAlign: 'justify',
                alignItems: 'center',
              }}
              container
              direction="column"
              display="flex"
              justify="center"
            >
              <MotionInView variants={varFade().inDown}>
                <Avatar alt={author?.displayName} src={author?.photoURL} sx={{ width: 150, height: 150 }} />
              </MotionInView>
              <br />
              <MotionInView variants={varFade().inDown}>
                <Typography variant="h3">{author?.displayName}</Typography>
              </MotionInView>
              <Stack alignItems="center" sx={{ mt: 2, mb: 1 }}>
                <SocialsButton sx={{ color: 'action.active' }} links={socialMediaLinks} />
              </Stack>
              <MotionInView variants={varFade().inDown} sx={{ p: 2 }}>
                <Typography variant="body1">{author?.about}</Typography>
              </MotionInView>
            </Grid>
            <Grid
              item
              sx={{
                textAlign: 'left',
              }}
              xs={9}
            >
              <MotionInView variants={varFade().inDown}>
                <Typography variant="h5">{i18n.t('journalist.blogs')}</Typography>
              </MotionInView>
            </Grid>
            {blogs?.length > 0 && (
              <Grid
                item
                sx={{
                  textAlign: 'right',
                  alignSelf: 'center',
                }}
                xs={12}
              >
                <Box
                  sx={{
                    display: 'grid',
                    gap: { xs: 5, md: 3, lg: 5 },
                    alignItems: 'center',
                    gridTemplateColumns: { xs: 'repeat(1, 1fr)', md: 'repeat(4, 1fr)', lg: 'repeat(4, 1fr)' },
                  }}
                >
                  {blogs?.map((card, index) => (
                    <MotionInView key={card.UID} variants={varFade().inUp} sx={{ alignItems: 'center' }}>
                      <CardBox key={card.UID} blog={card} index={index} />
                    </MotionInView>
                  ))}
                </Box>
              </Grid>
            )}
            <Grid
              sx={{
                textAlign: 'center',
                alignSelf: 'center',
              }}
              container
              direction="column"
              display="flex"
              justify="center"
            >
              <Grid item>
                <Button variant="text" onClick={getMore} disabled={disableMoreButton}>
                  {i18n.t('home.more')}
                </Button>
              </Grid>
            </Grid>
          </Grid>
        </Container>
      </RootStyle>
    </Page>
  );
}
