import { useContext, useState, useEffect } from 'react';
// @mui
import { useTheme } from '@mui/material/styles';
import {
  Card,
  Table,
  Avatar,
  Checkbox,
  TableRow,
  TableBody,
  TableCell,
  Container,
  Typography,
  TableContainer,
  TablePagination,
} from '@mui/material';

import { useSnackbar } from 'notistack';

// routes
import { PATH_DASHBOARD } from '../../routes/paths';
// hooks
import useSettings from '../../hooks/useSettings';
import i18n from '../../locales/i18n';
// components
import Page from '../../components/atoms/Page';
import Label from '../../components/atoms/Label';
import Scrollbar from '../../components/atoms/Scrollbar';
import SearchNotFound from '../../components/atoms/SearchNotFound';
import HeaderBreadcrumbs from '../../components/atoms/HeaderBreadcrumbs';
import ModalCard from '../../components/molecules/card/ModalCard';

// sections
import { ListHead, ListToolbar, ListMoreMenu } from '../../sections/@dashboard/user/list';
import { UserContext } from '../../contexts/UserContext';

// ----------------------------------------------------------------------
const UID_ADMIN = 'An5ulNPSOWgyPM7ke6Fww6CYZq22';

const TABLE_HEAD = [
  { id: 'name', label: i18n.t('user.name'), alignRight: false },
  { id: 'isActif', label: i18n.t('dashboard.users.status'), alignRight: false },
  { id: 'isAdmin', label: i18n.t('dashboard.users.admin'), alignRight: false },
  { id: '' },
];

const IS_EDIT = true;
// ----------------------------------------------------------------------

export default function UserList() {
  const theme = useTheme();
  const { enqueueSnackbar } = useSnackbar();

  const { themeStretch } = useSettings();
  const { userList, deleteUser, deleteMultiUsers, resetCurrentUser } = useContext(UserContext);
  const [users, setUsers] = useState([]);
  const [page, setPage] = useState(0);
  const [order, setOrder] = useState('desc');
  const [selected, setSelected] = useState([]);
  const [orderBy, setOrderBy] = useState('isActif');
  const [filterName, setFilterName] = useState('');
  const [rowsPerPage, setRowsPerPage] = useState(5);

  const [openModal, setOpenModal] = useState(false);
  const [elementToDelete, setElementToDelete] = useState({});
  const [elementsToDelete, setElementsToDelete] = useState([]);

  const handleOpenModal = (UID, picture, isMulti) => {
    if (isMulti) {
      setElementsToDelete(UID);
    } else {
      setElementToDelete({
        UID,
        picture,
      });
    }
    setOpenModal(true);
  };
  const handleCloseModal = () => {
    setOpenModal(false);
    setElementsToDelete([]);
    setElementToDelete({});
  };

  useEffect(() => {
    setUsers(userList);
  }, [userList]);

  useEffect(() => {
    setUsers(userList);
    resetCurrentUser();
  }, []);

  const handleRequestSort = (event, property) => {
    const isAsc = orderBy === property && order === 'asc';
    setOrder(isAsc ? 'desc' : 'asc');
    setOrderBy(property);
  };

  const handleSelectAllClick = (checked) => {
    if (checked) {
      if (selected.length === users.length) {
        setSelected([]);
      } else {
        const newSelecteds = users.map((n) => n.UID);
        setSelected(newSelecteds);
      }
      return;
    }
    setSelected([]);
  };

  const handleClick = (UID) => {
    const selectedIndex = selected.indexOf(UID);
    let newSelected = [];
    if (selectedIndex === -1) {
      newSelected = newSelected.concat(selected, UID);
    } else if (selectedIndex === 0) {
      newSelected = newSelected.concat(selected.slice(1));
    } else if (selectedIndex === selected.length - 1) {
      newSelected = newSelected.concat(selected.slice(0, -1));
    } else if (selectedIndex > 0) {
      newSelected = newSelected.concat(selected.slice(0, selectedIndex), selected.slice(selectedIndex + 1));
    }
    setSelected(newSelected);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const handleFilterByName = (filterName) => {
    setFilterName(filterName);
    setPage(0);
  };

  const handleDeleteUser = () => {
    if (elementToDelete.UID === UID_ADMIN) {
      enqueueSnackbar(i18n.t('dashboard.users.noDeleteAdmin'), { variant: 'error' });
    } else {
      const deleteUserList = users.filter((user) => user.UID !== elementToDelete.UID);
      deleteUser(elementToDelete.UID, elementToDelete.picture, deleteUserList);
      setSelected([]);
      setUsers(deleteUserList);
    }
    handleCloseModal();
  };

  const removePolyscopeAdminDelete = (selected) => {
    if (selected.includes(UID_ADMIN)) {
      enqueueSnackbar(i18n.t('dashboard.users.noDeleteAdmin'), { variant: 'error' });
      return selected.filter((user) => user !== UID_ADMIN);
    }
    return selected;
  };

  const handleDeleteMultiUser = () => {
    let elements = elementsToDelete;
    elements = removePolyscopeAdminDelete(elements);
    if (elements.length > 0) {
      const deleteUsers = users.filter((user) => !elements.includes(user.UID));
      deleteMultiUsers(elements, deleteUsers);
      setSelected([]);
      setUsers(deleteUsers);
      enqueueSnackbar(i18n.t('form.deleteSuccess'));
    }
    handleCloseModal();
  };

  const handleDeleteModal = async () => {
    if (elementsToDelete.length > 0) {
      handleDeleteMultiUser();
    } else {
      handleDeleteUser();
    }
  };

  const emptyRows = page > 0 ? Math.max(0, (1 + page) * rowsPerPage - users.length) : 0;

  const filteredUsers = applySortFilter(users, getComparator(order, orderBy), filterName);

  const isNotFound = !filteredUsers.length && Boolean(filterName);

  return (
    <Page title={i18n.t('dashboard.users.users')}>
      <Container maxWidth={themeStretch ? false : 'lg'}>
        <HeaderBreadcrumbs
          heading={i18n.t('dashboard.users.userList')}
          links={[
            { name: i18n.t('dashboard.dashboard'), href: PATH_DASHBOARD.root },
            { name: i18n.t('dashboard.users.users'), href: PATH_DASHBOARD.user.root },
            { name: i18n.t('dashboard.users.list') },
          ]}
        />

        <Card>
          <ListToolbar
            numSelected={selected.length}
            filterName={filterName}
            onFilterName={handleFilterByName}
            onDeleteUsers={() => handleOpenModal(selected, '', true)}
          />

          <Scrollbar>
            <TableContainer sx={{ minWidth: 800 }}>
              <Table>
                <ListHead
                  order={order}
                  orderBy={orderBy}
                  headLabel={TABLE_HEAD}
                  rowCount={users.length}
                  numSelected={selected.length}
                  onRequestSort={handleRequestSort}
                  onSelectAllClick={handleSelectAllClick}
                />
                <TableBody>
                  {filteredUsers.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((row) => {
                    const { UID, name, isActif, isAdmin, photoURL } = row;
                    const isItemSelected = selected.indexOf(UID) !== -1;

                    return (
                      <TableRow
                        hover
                        key={UID}
                        tabIndex={-1}
                        role="checkbox"
                        selected={isItemSelected}
                        aria-checked={isItemSelected}
                      >
                        <TableCell padding="checkbox">
                          <Checkbox checked={isItemSelected} onClick={() => handleClick(UID)} />
                        </TableCell>
                        <TableCell sx={{ display: 'flex', alignItems: 'center' }}>
                          <Avatar alt={name} src={photoURL} sx={{ mr: 2 }} />
                          <Typography variant="subtitle2" noWrap>
                            {name}
                          </Typography>
                        </TableCell>
                        <TableCell align="left">
                          <Label
                            variant={theme.palette.mode === 'light' ? 'ghost' : 'filled'}
                            color={(isActif === false && 'error') || 'success'}
                          >
                            {isActif ? i18n.t('user.active') : i18n.t('user.banned')}
                          </Label>
                        </TableCell>
                        <TableCell align="left">
                          <Label
                            variant={theme.palette.mode === 'light' ? 'ghost' : 'filled'}
                            color={(isAdmin === false && 'error') || 'success'}
                          >
                            {isAdmin ? i18n.t('userList.yes') : i18n.t('userList.no')}
                          </Label>
                        </TableCell>

                        <TableCell align="right">
                          <ListMoreMenu
                            onDelete={() => handleOpenModal(UID, photoURL, false)}
                            editPath={`${PATH_DASHBOARD.user.root}/${UID}/edit`}
                            isEdit={IS_EDIT}
                          />
                        </TableCell>
                      </TableRow>
                    );
                  })}
                  {emptyRows > 0 && (
                    <TableRow style={{ height: 53 * emptyRows }}>
                      <TableCell colSpan={6} />
                    </TableRow>
                  )}
                </TableBody>
                {isNotFound && (
                  <TableBody>
                    <TableRow>
                      <TableCell align="center" colSpan={6} sx={{ py: 3 }}>
                        <SearchNotFound searchQuery={filterName} />
                      </TableCell>
                    </TableRow>
                  </TableBody>
                )}
              </Table>
            </TableContainer>
          </Scrollbar>

          <TablePagination
            rowsPerPageOptions={[5, 10, 25]}
            component="div"
            count={users.length}
            rowsPerPage={rowsPerPage}
            page={page}
            onPageChange={(e, page) => setPage(page)}
            onRowsPerPageChange={handleChangeRowsPerPage}
          />
          {openModal && (
            <ModalCard
              isOpen={openModal}
              handleClose={handleCloseModal}
              UID={'UID'}
              deleteElement={handleDeleteModal}
            />
          )}
        </Card>
      </Container>
    </Page>
  );
}

// ----------------------------------------------------------------------

function descendingComparator(a, b, orderBy) {
  if (b[orderBy] < a[orderBy]) {
    return -1;
  }
  if (b[orderBy] > a[orderBy]) {
    return 1;
  }
  return 0;
}

function getComparator(order, orderBy) {
  return order === 'desc'
    ? (a, b) => descendingComparator(a, b, orderBy)
    : (a, b) => -descendingComparator(a, b, orderBy);
}

function applySortFilter(array, comparator, query) {
  const stabilizedThis = array.map((el, index) => [el, index]);
  stabilizedThis.sort((a, b) => {
    const order = comparator(a[0], b[0]);
    if (order !== 0) return order;
    return a[1] - b[1];
  });
  if (query) {
    return array.filter((_user) => _user.name.toLowerCase().indexOf(query.toLowerCase()) !== -1);
  }
  return stabilizedThis.map((el) => el[0]);
}
