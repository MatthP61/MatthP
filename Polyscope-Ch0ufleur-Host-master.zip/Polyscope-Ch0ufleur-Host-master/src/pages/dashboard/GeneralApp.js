// @mui
import { Container, Grid } from '@mui/material';
// hooks
import { PATH_DASHBOARD } from '../../routes/paths';
import HeaderBreadcrumbs from '../../components/atoms/HeaderBreadcrumbs';
import useSettings from '../../hooks/useSettings';
// components
import Page from '../../components/atoms/Page';
import i18n from '../../locales/i18n';
// sections
import { AppArticleClicks, AppSiteVisits, AppUserPlatforms } from '../../sections/@dashboard/general/app';

// ----------------------------------------------------------------------

export default function GeneralApp() {
  const { themeStretch } = useSettings();

  return (
    <Page title={i18n.t('dashboard.dashboard')}>
      <Container maxWidth={themeStretch ? false : 'xl'}>
        <HeaderBreadcrumbs heading={i18n.t('dashboard.dashboard')} links={[{ name: '', href: PATH_DASHBOARD.root }]} />
        <Grid container spacing={3}>
          <Grid item xs={12} md={12} lg={12}>
            <AppSiteVisits />
          </Grid>

          <Grid item xs={12} md={12} lg={8}>
            <AppArticleClicks />
          </Grid>
          <Grid item xs={12} md={6} lg={4}>
            <AppUserPlatforms />
          </Grid>
        </Grid>
      </Container>
    </Page>
  );
}
