import React, { useEffect, useContext } from 'react';
import { capitalCase } from 'change-case';
import { useParams, useLocation } from 'react-router-dom';

// @mui
import { Container } from '@mui/material';

// routes
import { PATH_DASHBOARD } from '../../routes/paths';

// hooks
import useSettings from '../../hooks/useSettings';

// components
import Page from '../../components/atoms/Page';
import HeaderBreadcrumbs from '../../components/atoms/HeaderBreadcrumbs';

import { CategoryContext } from '../../contexts/CategoryContext';

// sections
import { AdNewCategoryForm } from '../../sections/@dashboard/category';
import i18n from '../../locales/i18n';

export default function AdNewAd() {
  const { themeStretch } = useSettings();
  const { getCategory, currentCategory, resetCurrentCategory } = useContext(CategoryContext);

  const { pathname } = useLocation();
  const { uid = '' } = useParams();
  const isEdit = pathname.includes('edit');

  useEffect(() => {
    if (isEdit) {
      getCategory(uid);
    } else {
      resetCurrentCategory();
    }
  }, [uid]);

  return (
    <Page title={i18n.t('dashboard.category.title')}>
      <Container maxWidth={themeStretch ? false : 'lg'}>
        <HeaderBreadcrumbs
          heading={!isEdit ? i18n.t('dashboard.category.newCategory') : capitalCase(currentCategory?.title || '')}
          links={[
            { name: i18n.t('dashboard.dashboard'), href: PATH_DASHBOARD.root },
            { name: i18n.t('dashboard.category.title'), href: PATH_DASHBOARD.category.root },
            { name: !isEdit ? i18n.t('dashboard.category.newCategory') : capitalCase(currentCategory?.title || '') },
          ]}
        />
        <AdNewCategoryForm isEdit={isEdit} currentCategory={currentCategory} />
      </Container>
    </Page>
  );
}
