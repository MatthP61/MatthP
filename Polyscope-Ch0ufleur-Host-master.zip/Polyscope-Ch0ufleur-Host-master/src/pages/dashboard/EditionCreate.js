// @mui
import { Container } from '@mui/material';
// routes
import { PATH_DASHBOARD } from '../../routes/paths';
// hooks
import useSettings from '../../hooks/useSettings';
// components
import Page from '../../components/atoms/Page';
import HeaderBreadcrumbs from '../../components/atoms/HeaderBreadcrumbs';
// sections
import { EditionNewForm } from '../../sections/@dashboard/edition';
import i18n from '../../locales/i18n';

// ----------------------------------------------------------------------

export default function EditionCreate() {
  const { themeStretch } = useSettings();

  return (
    <Page title={i18n.t('dashboard.edition.pageTitleNew')}>
      <Container maxWidth={themeStretch ? false : 'lg'}>
        <HeaderBreadcrumbs
          heading={i18n.t('dashboard.edition.addEdition')}
          links={[
            { name: i18n.t('dashboard.dashboard'), href: PATH_DASHBOARD.root },
            { name: i18n.t('dashboard.edition.editions'), href: PATH_DASHBOARD.edition.root },
            { name: i18n.t('dashboard.edition.newEdition') },
          ]}
        />
        <EditionNewForm />
      </Container>
    </Page>
  );
}
