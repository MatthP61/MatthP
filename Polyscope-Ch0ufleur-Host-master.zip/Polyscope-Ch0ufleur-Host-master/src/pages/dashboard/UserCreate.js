import { useContext, useEffect } from 'react';
import { useParams, useLocation } from 'react-router-dom';
// @mui
import { Container } from '@mui/material';
// routes
import { PATH_DASHBOARD } from '../../routes/paths';
// hooks
import useSettings from '../../hooks/useSettings';
// components
import Page from '../../components/atoms/Page';
import HeaderBreadcrumbs from '../../components/atoms/HeaderBreadcrumbs';
// sections
import UserNewForm from '../../sections/@dashboard/user/UserNewForm';
import { UserContext } from '../../contexts/UserContext';
import i18n from '../../locales/i18n';

// ----------------------------------------------------------------------

export default function UserCreate() {
  const { themeStretch } = useSettings();
  const { getUser, currentUser, resetCurrentUser } = useContext(UserContext);
  const { pathname } = useLocation();
  const { name = '' } = useParams();
  const isEdit = pathname.includes('edit');

  useEffect(() => {
    if (isEdit) {
      getUser(name);
    } else {
      resetCurrentUser();
    }
  }, [name]);

  return (
    <Page title={i18n.t('dashboard.users.user')}>
      <Container maxWidth={themeStretch ? false : 'lg'}>
        <HeaderBreadcrumbs
          heading={!isEdit ? i18n.t('dashboard.users.createUser') : i18n.t('dashboard.users.modifyUser')}
          links={[
            { name: i18n.t('dashboard.dashboard'), href: PATH_DASHBOARD.root },
            { name: i18n.t('dashboard.users.users'), href: PATH_DASHBOARD.user.list },
            { name: !isEdit ? i18n.t('dashboard.users.newUser') : i18n.t('dashboard.users.editUser') },
          ]}
        />

        <UserNewForm isEdit={isEdit} currentUser={currentUser} />
      </Container>
    </Page>
  );
}
