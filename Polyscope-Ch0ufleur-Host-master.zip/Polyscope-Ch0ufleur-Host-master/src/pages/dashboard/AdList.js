import React, { useContext, useEffect, useState } from 'react';
import { Link as RouterLink } from 'react-router-dom';
import { useSnackbar } from 'notistack';

// @mui
import { useTheme } from '@mui/material/styles';
import {
  Avatar,
  Card,
  Table,
  Button,
  Checkbox,
  TableRow,
  TableBody,
  TableCell,
  Container,
  TableContainer,
  TablePagination,
} from '@mui/material';

// components
import { AdContext } from '../../contexts/AdContext';
import Page from '../../components/atoms/Page';
import Label from '../../components/atoms/Label';
import Iconify from '../../components/atoms/Iconify';
import Scrollbar from '../../components/atoms/Scrollbar';
import SearchNotFound from '../../components/atoms/SearchNotFound';
import HeaderBreadcrumbs from '../../components/atoms/HeaderBreadcrumbs';
import ModalCard from '../../components/molecules/card/ModalCard';
import i18n from '../../locales/i18n';

// sections
import { ListHead, ListToolbar, ListMoreMenu } from '../../sections/@dashboard/user/list';

// hooks
import useSettings from '../../hooks/useSettings';

// routes
import { PATH_DASHBOARD } from '../../routes/paths';

// ----------------------------------------------------------------------
const TABLE_HEAD = [
  { id: 'title', label: i18n.t('dashboard.ad.title'), alignRight: false },
  { id: 'description', label: i18n.t('dashboard.ad.description'), alignRight: false },
  { id: 'link', label: i18n.t('dashboard.ad.link'), alignRight: false },
  { id: 'cover', label: i18n.t('dashboard.ad.cover'), alignRight: false },
  { id: 'publish', label: i18n.t('dashboard.ad.status'), alignRight: false },
  { id: '' },
];

const IS_EDIT = true;
// ----------------------------------------------------------------------

export default function AdList() {
  const theme = useTheme();
  const { themeStretch } = useSettings();
  const { AdList, deleteAd, deleteMultiAds, resetCurrentAd } = useContext(AdContext);

  const [adList, setAdList] = useState([]);
  const [page, setPage] = useState(0);
  const [order, setOrder] = useState('asc');
  const [selected, setSelected] = useState([]);
  const [orderBy, setOrderBy] = useState('title');
  const [filterName, setFilterName] = useState('');
  const [rowsPerPage, setRowsPerPage] = useState(5);

  const [openModal, setOpenModal] = useState(false);
  const [elementToDelete, setElementToDelete] = useState({});
  const [elementsToDelete, setElementsToDelete] = useState([]);

  const { enqueueSnackbar } = useSnackbar();

  const handleOpenModal = (UID, cover, isMulti) => {
    if (isMulti) {
      setElementsToDelete(UID);
    } else {
      setElementToDelete({
        UID,
        cover,
      });
    }
    setOpenModal(true);
  };

  const handleCloseModal = () => {
    setOpenModal(false);
    setElementsToDelete([]);
    setElementToDelete({});
  };

  const handleRequestSort = (event, property) => {
    const isAsc = orderBy === property && order === 'asc';
    setOrder(isAsc ? 'desc' : 'asc');
    setOrderBy(property);
  };

  const handleSelectAllClick = (checked) => {
    if (checked) {
      if (selected.length === adList.length) {
        setSelected([]);
      } else {
        const newSelecteds = adList.map((n) => n.UID);
        setSelected(newSelecteds);
      }
      return;
    }
    setSelected([]);
  };

  const handleClick = (UID) => {
    const selectedIndex = selected.indexOf(UID);
    let newSelected = [];
    if (selectedIndex === -1) {
      newSelected = newSelected.concat(selected, UID);
    } else if (selectedIndex === 0) {
      newSelected = newSelected.concat(selected.slice(1));
    } else if (selectedIndex === selected.length - 1) {
      newSelected = newSelected.concat(selected.slice(0, -1));
    } else if (selectedIndex > 0) {
      newSelected = newSelected.concat(selected.slice(0, selectedIndex), selected.slice(selectedIndex + 1));
    }
    setSelected(newSelected);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const handleFilterByName = (filterName) => {
    setFilterName(filterName);
    setPage(0);
  };

  const handleDeleteAd = () => {
    const deleteAdList = adList.filter((ad) => ad.UID !== elementToDelete.UID);
    deleteAd(elementToDelete.UID, elementToDelete.cover, deleteAdList);
    setSelected([]);
    setAdList(deleteAdList);
    handleCloseModal();
    enqueueSnackbar(i18n.t('form.deleteSuccess'));
  };

  const handleDeleteMultiAd = async () => {
    const deleteAds = adList.filter((ad) => !elementsToDelete.includes(ad.UID));
    deleteMultiAds(elementsToDelete, deleteAds);
    setSelected([]);
    setAdList(deleteAds);
    handleCloseModal();
    enqueueSnackbar(i18n.t('form.deleteSuccess'));
  };

  const handleDeleteModal = async () => {
    if (elementsToDelete.length > 0) {
      handleDeleteMultiAd();
    } else {
      handleDeleteAd();
    }
  };

  const emptyRows = page > 0 ? Math.max(0, (1 + page) * rowsPerPage - adList.length) : 0;

  const filteredAds = applySortFilter(adList, getComparator(order, orderBy), filterName);

  const isNotFound = !filteredAds.length && Boolean(filterName);

  useEffect(() => {
    setAdList(AdList);
  }, [AdList]);

  useEffect(() => {
    setAdList(AdList);
    resetCurrentAd();
  }, []);

  return (
    <Page title={i18n.t('dashboard.ad.pageTitle')}>
      <Container maxWidth={themeStretch ? false : 'lg'}>
        <HeaderBreadcrumbs
          heading={i18n.t('dashboard.ad.pageTitle')}
          links={[
            { name: i18n.t('dashboard.dashboard'), href: PATH_DASHBOARD.root },
            { name: i18n.t('dashboard.ad.pageTitle'), href: PATH_DASHBOARD.ads.root },
          ]}
          action={
            <Button
              variant="contained"
              sx={{ textTransform: 'none' }}
              component={RouterLink}
              to={PATH_DASHBOARD.ads.newAds}
              startIcon={<Iconify icon={'eva:plus-fill'} />}
            >
              {i18n.t('dashboard.ad.newElement')}
            </Button>
          }
        />

        <Card>
          <ListToolbar
            numSelected={selected.length}
            filterName={filterName}
            onFilterName={handleFilterByName}
            onDeleteUsers={() => handleOpenModal(selected, '', true)}
          />
          <Scrollbar>
            <TableContainer sx={{ minWidth: 800 }}>
              <Table>
                <ListHead
                  order={order}
                  orderBy={orderBy}
                  headLabel={TABLE_HEAD}
                  rowCount={adList.length}
                  numSelected={selected.length}
                  onRequestSort={handleRequestSort}
                  onSelectAllClick={handleSelectAllClick}
                />
                <TableBody>
                  {filteredAds.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((row) => {
                    const { UID, title, description, link, cover, publish } = row;
                    const isItemSelected = selected.indexOf(UID) !== -1;

                    return (
                      <TableRow
                        hover
                        key={UID}
                        tabIndex={-1}
                        role="checkbox"
                        selected={isItemSelected}
                        aria-checked={isItemSelected}
                      >
                        <TableCell padding="checkbox">
                          <Checkbox checked={isItemSelected} onClick={() => handleClick(UID)} />
                        </TableCell>
                        <TableCell align="left">{title}</TableCell>
                        <TableCell align="left">{description}</TableCell>
                        <TableCell align="left">
                          <a href={link} rel="noopener noreferrer" target="_blank">
                            {link}
                          </a>
                        </TableCell>
                        <TableCell sx={{ display: 'flex', alignItems: 'center' }}>
                          <Avatar alt={cover} src={cover} sx={{ mr: 2 }} />
                        </TableCell>

                        <TableCell align="left">
                          <Label
                            variant={theme.palette.mode === 'light' ? 'ghost' : 'filled'}
                            color={(publish === false && 'error') || 'success'}
                          >
                            {(publish === false && 'Inactif') || 'Actif'}
                          </Label>
                        </TableCell>
                        <TableCell align="right">
                          <ListMoreMenu
                            onDelete={() => handleOpenModal(UID, cover, false)}
                            editPath={`${PATH_DASHBOARD.ads.root}/${UID}/edit`}
                            isEdit={IS_EDIT}
                          />
                        </TableCell>
                      </TableRow>
                    );
                  })}
                  {emptyRows > 0 && (
                    <TableRow style={{ height: 53 * emptyRows }}>
                      <TableCell colSpan={6} />
                    </TableRow>
                  )}
                </TableBody>
                {isNotFound && (
                  <TableBody>
                    <TableRow>
                      <TableCell align="center" colSpan={6} sx={{ py: 3 }}>
                        <SearchNotFound searchQuery={filterName} />
                      </TableCell>
                    </TableRow>
                  </TableBody>
                )}
              </Table>
            </TableContainer>
          </Scrollbar>

          <TablePagination
            rowsPerPageOptions={[5, 10, 25]}
            component="div"
            count={adList.length}
            rowsPerPage={rowsPerPage}
            page={page}
            onPageChange={(e, page) => setPage(page)}
            onRowsPerPageChange={handleChangeRowsPerPage}
          />
          {openModal && (
            <ModalCard
              isOpen={openModal}
              handleClose={handleCloseModal}
              UID={'UID'}
              deleteElement={handleDeleteModal}
            />
          )}
        </Card>
      </Container>
    </Page>
  );
}

// --------------------------------------------------------------------------------------------------------------
function descendingComparator(a, b, orderBy) {
  if (b[orderBy] < a[orderBy]) {
    return -1;
  }
  if (b[orderBy] > a[orderBy]) {
    return 1;
  }
  return 0;
}

function getComparator(order, orderBy) {
  return order === 'desc'
    ? (a, b) => descendingComparator(a, b, orderBy)
    : (a, b) => -descendingComparator(a, b, orderBy);
}

function applySortFilter(array, comparator, query) {
  const stabilizedThis = array.map((el, index) => [el, index]);
  stabilizedThis.sort((a, b) => {
    const order = comparator(a[0], b[0]);
    if (order !== 0) return order;
    return a[1] - b[1];
  });
  if (query) {
    return array.filter((ad) => ad.title.toLowerCase().indexOf(query.toLowerCase()) !== -1);
  }
  return stabilizedThis.map((el) => el[0]);
}
