import React, { useEffect, useContext } from 'react';
import { useParams, useLocation } from 'react-router-dom';

// @mui
import { Container } from '@mui/material';

// routes
import { PATH_DASHBOARD } from '../../routes/paths';

// hooks
import useSettings from '../../hooks/useSettings';

// components
import Page from '../../components/atoms/Page';
import HeaderBreadcrumbs from '../../components/atoms/HeaderBreadcrumbs';
import { TeamContext } from '../../contexts/TeamContext';

// sections
import NewMemberTeamForm from '../../sections/@dashboard/settings/NewMemberTeamForm';
import i18n from '../../locales/i18n';

export default function NewTeamMember() {
  const { themeStretch } = useSettings();
  const { getMember, currentMember, resetCurrentMember } = useContext(TeamContext);

  const { pathname } = useLocation();
  const { uid = '' } = useParams();
  const isEdit = pathname.includes('edit');

  useEffect(() => {
    if (isEdit) {
      getMember(uid);
    } else {
      resetCurrentMember();
    }
  }, [uid]);

  return (
    <Page title={i18n.t('dashboard.team.newMemberTitle')}>
      <Container maxWidth={themeStretch ? false : 'lg'}>
        <HeaderBreadcrumbs
          heading={i18n.t('dashboard.team.newMemberTitle')}
          links={[
            { name: i18n.t('dashboard.dashboard'), href: PATH_DASHBOARD.root },
            { name: i18n.t('dashboard.settings.settings'), href: PATH_DASHBOARD.settings.root },
            { name: i18n.t('dashboard.settings.team'), href: PATH_DASHBOARD.settings.team },
            { name: !isEdit ? i18n.t('dashboard.team.newMember') : currentMember?.name || '' },
          ]}
        />
        <NewMemberTeamForm isEdit={isEdit} currentMember={currentMember} />
      </Container>
    </Page>
  );
}
