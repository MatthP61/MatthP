import React, { useContext, useEffect, useState, useCallback } from 'react';
// @mui
import { Container, Box, Button, Stack, Typography } from '@mui/material';
import { Link as RouterLink } from 'react-router-dom';
// routes
import { isNil } from 'lodash';
import { PATH_DASHBOARD } from '../../routes/paths';
// hooks
import useSettings from '../../hooks/useSettings';
// components
import Page from '../../components/atoms/Page';
import Iconify from '../../components/atoms/Iconify';
import HeaderBreadcrumbs from '../../components/atoms/HeaderBreadcrumbs';
import i18n from '../../locales/i18n';
// sections
import { EditionCard, EditionMenu } from '../../sections/@dashboard/edition';
import { EditionContext } from '../../contexts/EditionContext';
import { DashboardAnalyticsContext } from '../../contexts/DashboardAnalyticsContext';
// ----------------------------------------------------------------------

const EditionCards = () => {
  const { themeStretch } = useSettings();
  const { VolumeList, getVolumes, deleteEdition, EditionByVolumeList, getEditionsVK, currentVolume } =
    useContext(EditionContext);

  const [listOfEdition, setListOfEdition] = useState([]);
  const [volumeList, setVolumeList] = useState([' ']);
  const [volume, setVolume] = useState('');

  const deleteEditionList = async (UID, cover, pdf, isKapote, volume, eventID) => {
    const deleteEditionList = listOfEdition.filter((edition) => edition.UID !== UID);
    await deleteEdition(UID, cover, pdf, deleteEditionList, volume, isKapote, volume, eventID);
  };

  const getEditions = useCallback(async () => {
    try {
      await getEditionsVK(volume);
    } catch (e) {
      console.log('ERROR: ', e);
    }
  }, [volume]);

  const getVolumesList = useCallback(async () => {
    try {
      await getVolumes();
    } catch (e) {
      console.log('ERROR: ', e);
    }
  }, []);

  useEffect(() => {
    getVolumesList();
  }, [getVolumesList]);

  const pluck = (arr, key) => arr.map((i) => i[key]);

  useEffect(() => {
    setVolumeList(pluck(VolumeList, 'name'));
  }, [VolumeList]);

  useEffect(() => {
    if (currentVolume !== undefined) {
      setVolume(currentVolume);
    }
  }, [currentVolume]);

  useEffect(() => {
    if (volume) getEditions();
  }, [getEditions]);

  useEffect(() => {
    setListOfEdition(EditionByVolumeList);
  }, [EditionByVolumeList]);

  const volumeMenu = () => {
    const volumes = [];
    volumeList.forEach((item) => {
      volumes.push({ value: item, label: item });
    });
    return volumes;
  };

  const { getVisitsForUIDs } = useContext(DashboardAnalyticsContext);

  const [viewsForAllUIDs, setViewsForAllUIDs] = useState({});
  const [newUIDs, setNewUIDs] = useState([]);

  useEffect(() => {
    const missingValues = {};
    const newUIDs = [];

    listOfEdition.forEach(({ UID }) => {
      if (isNil(viewsForAllUIDs[UID])) {
        missingValues[UID] = 0;
        newUIDs.push(UID);
      }
    });

    setViewsForAllUIDs({
      ...viewsForAllUIDs,
      ...missingValues,
    });
    setNewUIDs(newUIDs);
  }, [listOfEdition]);

  useEffect(() => {
    if (newUIDs < 1) return;

    getVisitsForUIDs(newUIDs).then((viewsForNewUIDs) => {
      setViewsForAllUIDs({
        ...viewsForAllUIDs,
        ...viewsForNewUIDs,
      });
      setNewUIDs([]);
    });
  }, [newUIDs, getVisitsForUIDs]);

  const renderEditions = useCallback(
    () => (
      <>
        {listOfEdition.map((edition) => (
          <EditionCard
            key={edition.UID}
            edition={edition}
            viewCount={viewsForAllUIDs[edition.UID]}
            currentVolume={volume}
            handleDeletePDF={deleteEditionList}
          />
        ))}
      </>
    ),
    [listOfEdition, viewsForAllUIDs]
  );

  return (
    <Page title={i18n.t('dashboard.edition.editions')}>
      <Container maxWidth={themeStretch ? false : 'lg'}>
        <HeaderBreadcrumbs
          heading={i18n.t('dashboard.edition.editions')}
          links={[
            { name: i18n.t('dashboard.dashboard'), href: PATH_DASHBOARD.root },
            { name: i18n.t('dashboard.edition.editions'), href: PATH_DASHBOARD.edition.root },
          ]}
          action={
            <Button
              variant="contained"
              sx={{ textTransform: 'none' }}
              component={RouterLink}
              to={PATH_DASHBOARD.edition.newEdition}
              startIcon={<Iconify icon={'eva:plus-fill'} />}
            >
              {i18n.t('dashboard.edition.newEdition')}
            </Button>
          }
        />

        <Stack mb={5} direction="row" alignItems="center" justifyContent="space-between">
          <Typography variant="h3" style={{ justifyContent: 'center', padding: '20px', display: 'flex' }}>
            {volume}
          </Typography>

          <EditionMenu currentVolume={volume} setCurrentVolume={setVolume} sortedVolumesList={volumeMenu()} />
        </Stack>
        <Box
          sx={{
            display: 'grid',
            gap: 3,
            gridTemplateColumns: {
              xs: 'repeat(1, 1fr)',
              sm: 'repeat(3, 1fr)',
              md: 'repeat(4, 1fr)',
            },
          }}
        >
          {renderEditions()}
        </Box>
      </Container>
    </Page>
  );
};

export default React.memo(EditionCards);
