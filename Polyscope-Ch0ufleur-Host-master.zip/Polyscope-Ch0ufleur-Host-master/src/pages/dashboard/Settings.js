import React from 'react';

// @mui
import { Container } from '@mui/material';

// routes
import { PATH_DASHBOARD } from '../../routes/paths';

// hooks
import useSettings from '../../hooks/useSettings';

// components
import Page from '../../components/atoms/Page';
import HeaderBreadcrumbs from '../../components/atoms/HeaderBreadcrumbs';
import VerifyCodeUserForm from '../../sections/@dashboard/settings/VerifyCodeUserForm';

import i18n from '../../locales/i18n';

export default function Settings() {
  const { themeStretch } = useSettings();

  return (
    <Page title={`${i18n.t('dashboard.settings.settings')}: ${i18n.t('dashboard.settings.general')}`}>
      <Container maxWidth={themeStretch ? false : 'lg'}>
        <HeaderBreadcrumbs
          heading={`${i18n.t('dashboard.settings.settings')} ${i18n.t('dashboard.settings.general')}`}
          links={[
            { name: i18n.t('dashboard.dashboard'), href: PATH_DASHBOARD.root },
            { name: i18n.t('dashboard.settings.settings'), href: PATH_DASHBOARD.settings.root },
            { name: i18n.t('dashboard.settings.general') },
          ]}
        />
        <VerifyCodeUserForm />
      </Container>
    </Page>
  );
}
