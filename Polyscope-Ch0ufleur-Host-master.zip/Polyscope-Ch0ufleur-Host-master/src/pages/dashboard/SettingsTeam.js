import React from 'react';
import { Link as RouterLink } from 'react-router-dom';

// @mui
import { Container, Button, Typography, Stack, Box } from '@mui/material';

// routes
import { PATH_DASHBOARD } from '../../routes/paths';

// hooks
import useSettings from '../../hooks/useSettings';

// components
import Page from '../../components/atoms/Page';
import Iconify from '../../components/atoms/Iconify';
import HeaderBreadcrumbs from '../../components/atoms/HeaderBreadcrumbs';

// sections
import TeamForm from '../../sections/@dashboard/settings/TeamForm';
import MembersList from '../../sections/@dashboard/settings/MembersList';

import i18n from '../../locales/i18n';

export default function SettingsTeam() {
  const { themeStretch } = useSettings();

  return (
    <Page title={`${i18n.t('dashboard.settings.settings')}: ${i18n.t('dashboard.settings.team')}`}>
      <Container maxWidth={themeStretch ? false : 'lg'}>
        <HeaderBreadcrumbs
          heading={i18n.t('dashboard.settings.settingsTeam')}
          links={[
            { name: i18n.t('dashboard.dashboard'), href: PATH_DASHBOARD.root },
            { name: i18n.t('dashboard.settings.settings'), href: PATH_DASHBOARD.settings.root },
            { name: i18n.t('dashboard.settings.team') },
          ]}
        />
        <Stack spacing={3}>
          <Typography>{i18n.t('dashboard.team.generalInfo')}</Typography>
          <TeamForm />
          <Box sx={{ mb: 5 }}>
            <Box sx={{ display: 'flex', alignItems: 'center' }}>
              <Box sx={{ flexGrow: 1 }}>
                <Typography>{i18n.t('dashboard.team.theMembers')}</Typography>
              </Box>

              <Button
                variant="contained"
                sx={{ textTransform: 'none' }}
                component={RouterLink}
                to={PATH_DASHBOARD.settings.newMember}
                startIcon={<Iconify icon={'eva:plus-fill'} />}
              >
                {i18n.t('dashboard.team.newMember')}
              </Button>
            </Box>
          </Box>
          <MembersList />
        </Stack>
      </Container>
    </Page>
  );
}
