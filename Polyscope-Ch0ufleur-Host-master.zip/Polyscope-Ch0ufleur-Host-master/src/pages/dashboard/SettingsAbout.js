// @mui
import { Container } from '@mui/material';

// routes
import { PATH_DASHBOARD } from '../../routes/paths';

// hooks
import useSettings from '../../hooks/useSettings';

// components
import Page from '../../components/atoms/Page';
import HeaderBreadcrumbs from '../../components/atoms/HeaderBreadcrumbs';
import i18n from '../../locales/i18n';

import AboutForm from '../../sections/@dashboard/settings/AboutForm';

// ----------------------------------------------------------------------

export default function SettingsAbout() {
  const { themeStretch } = useSettings();

  return (
    <Page title={`${i18n.t('dashboard.settings.settings')}: ${i18n.t('dashboard.settings.about')}`}>
      <Container maxWidth={themeStretch ? false : 'lg'}>
        <HeaderBreadcrumbs
          heading={`${i18n.t('dashboard.settings.settings')} ${i18n.t('dashboard.settings.about')}`}
          links={[
            { name: i18n.t('dashboard.dashboard'), href: PATH_DASHBOARD.root },
            { name: i18n.t('dashboard.settings.settings'), href: PATH_DASHBOARD.settings.root },
            { name: i18n.t('dashboard.settings.about') },
          ]}
        />
        <AboutForm />
      </Container>
    </Page>
  );
}
