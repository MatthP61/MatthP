import { useEffect, useState, useCallback, useContext } from 'react';
import { useParams } from 'react-router-dom';
// @mui
import { Box, Card, Divider, Container, Typography } from '@mui/material';
// routes
import { PATH_DASHBOARD } from '../../routes/paths';
// hooks
import useSettings from '../../hooks/useSettings';
import useIsMountedRef from '../../hooks/useIsMountedRef';
// utils
import { fDate } from '../../utils/formatTime';
// components
import Page from '../../components/atoms/Page';
import Markdown from '../../components/atoms/Markdown';
import HeaderBreadcrumbs from '../../components/atoms/HeaderBreadcrumbs';
import { SkeletonPost } from '../../components/organismes/skeleton';
// sections
import { BlogPostHero, BlogPostTags } from '../../sections/@dashboard/blog';
import { BlogContext } from '../../contexts/BlogContext';
import i18n from '../../locales/i18n';

// ----------------------------------------------------------------------

export default function BlogPost() {
  const { themeStretch } = useSettings();

  const isMountedRef = useIsMountedRef();

  const { title } = useParams();
  const { currentBlog, getOneBlog } = useContext(BlogContext);

  const [post, setPost] = useState(null);

  const [error, setError] = useState(null);

  const getPost = useCallback(async () => {
    try {
      await getOneBlog(title);
    } catch (error) {
      setError(error.message);
    }
  }, [isMountedRef, title]);

  useEffect(() => {
    getPost();
  }, [getPost]);

  useEffect(() => {
    setPost(currentBlog);
  }, [currentBlog]);

  return (
    <Page title={post?.title} meta={post?.metaDescription} cover={post?.cover} id={post?.UID}>
      <Container
        sx={{
          pt: { md: 9 },
        }}
        maxWidth={themeStretch ? false : 'lg'}
      >
        {post?.UID === title && (
          <HeaderBreadcrumbs
            heading={post?.title || ''}
            links={[
              { name: i18n.t('dashboard.dashboard'), href: PATH_DASHBOARD.root },
              { name: i18n.t('blogs'), href: PATH_DASHBOARD.blog.root },
              { name: post?.title },
            ]}
          />
        )}

        {post?.UID === title && (
          <Card>
            <BlogPostHero post={post} />

            <Box sx={{ p: { xs: 3, md: 5 } }}>
              <Typography variant="h6" sx={{ mb: 5 }}>
                {post?.description}
              </Typography>

              <Markdown children={post?.body} />

              <Box sx={{ my: 5 }}>
                <Divider />
                <BlogPostTags post={post} />
                <Divider />
                {post?.editDates?.length > 0 && (
                  <Typography variant="caption" sx={{ mb: 5 }}>
                    {i18n.t('blog.editDates')} {fDate(post.editDates[post.editDates.length - 1])}
                  </Typography>
                )}
              </Box>
            </Box>
          </Card>
        )}

        {!post?.UID === title && !error && <SkeletonPost />}

        {error && <Typography variant="h6">404 {error}!</Typography>}
      </Container>
    </Page>
  );
}
