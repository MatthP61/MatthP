import orderBy from 'lodash/orderBy';
import { Link as RouterLink } from 'react-router-dom';
import React, { useEffect, useCallback, useState, useContext } from 'react';
// @mui
import { Grid, Button, Container, Stack } from '@mui/material';
// hooks
import { isNil } from 'lodash';
import useSettings from '../../hooks/useSettings';
import useIsMountedRef from '../../hooks/useIsMountedRef';
// routes
import { PATH_DASHBOARD } from '../../routes/paths';
// components
import Page from '../../components/atoms/Page';
import Iconify from '../../components/atoms/Iconify';
import { SkeletonPostItem } from '../../components/organismes/skeleton';
import HeaderBreadcrumbs from '../../components/atoms/HeaderBreadcrumbs';
import i18n from '../../locales/i18n';
// sections
import { BlogPostCard, BlogPostsSort, BlogPostsSearch } from '../../sections/@dashboard/blog';
import { BlogContext } from '../../contexts/BlogContext';
import { JournalistContext } from '../../contexts/JournalistContext';
import useAuth from '../../hooks/useAuth';
import { DashboardAnalyticsContext } from '../../contexts/DashboardAnalyticsContext';

const SORT_OPTIONS = [
  { value: 'latest', label: i18n.t('dashboard.blogs.sortOptions.recent') },
  { value: 'popular', label: i18n.t('dashboard.blogs.sortOptions.popular') },
  { value: 'oldest', label: i18n.t('dashboard.blogs.sortOptions.oldest') },
];
// ----------------------------------------------------------------------

const applySort = (posts, sortBy) => {
  if (sortBy === 'latest') {
    return orderBy(posts, ['createdAt'], ['desc']);
  }
  if (sortBy === 'oldest') {
    return orderBy(posts, ['createdAt'], ['asc']);
  }
  if (sortBy === 'popular') {
    return orderBy(posts, ['view'], ['desc']);
  }
  return posts;
};

export default function BlogPosts() {
  const { themeStretch } = useSettings();

  const isMountedRef = useIsMountedRef();

  const [posts, setPosts] = useState([]);

  const [filters, setFilters] = useState('latest');
  const { user, isAdmin } = useAuth();
  const { deleteBlog, BlogList } = useContext(BlogContext);
  const { getBlogs, getMoreBlogs, BlogListJournalist, disableMoreButton } = useContext(JournalistContext);

  const getBlogsListJournalist = useCallback(async () => {
    try {
      await getBlogs(user.UID, 11);
    } catch {
      console.log('error');
    }
  }, [user]);

  const getAllPosts = useCallback(async () => {
    try {
      if (isMountedRef.current) {
        setPosts(BlogList);
      }
    } catch (error) {
      console.error(error);
    }
  }, [isMountedRef, BlogList]);

  useEffect(() => {
    if (!isAdmin) {
      getBlogsListJournalist();
    }
  }, [getBlogsListJournalist]);
  useEffect(() => {
    if (isAdmin) {
      getAllPosts();
    }
  }, [getAllPosts]);

  useEffect(() => {
    if (!isAdmin) {
      setPosts(BlogListJournalist);
    }
  }, [BlogListJournalist]);
  useEffect(() => {
    if (isAdmin) {
      setPosts(BlogList);
    }
  }, [BlogList]);

  const getMore = async () => {
    await getMoreBlogs(user.UID, 4);
  };

  const handleChangeSort = (value) => {
    if (value) {
      setFilters(value);
    }
  };

  const handleDeleteBlog = (blogId) => {
    deleteBlog(blogId);
  };

  const sortedPosts = applySort(posts, filters);

  const { getVisitsForUIDs } = useContext(DashboardAnalyticsContext);

  const [viewsForAllUIDs, setViewsForAllUIDs] = useState({});
  const [newUIDs, setNewUIDs] = useState([]);

  useEffect(() => {
    const missingValues = {};
    const newUIDs = [];

    posts.forEach(({ UID }) => {
      if (isNil(viewsForAllUIDs[UID])) {
        missingValues[UID] = 0;
        newUIDs.push(UID);
      }
    });

    setViewsForAllUIDs({
      ...viewsForAllUIDs,
      ...missingValues,
    });
    setNewUIDs(newUIDs);
  }, [posts]);

  useEffect(() => {
    if (newUIDs < 1) return;

    getVisitsForUIDs(newUIDs).then((viewsForNewUIDs) => {
      setViewsForAllUIDs({
        ...viewsForAllUIDs,
        ...viewsForNewUIDs,
      });
      setNewUIDs([]);
    });
  }, [newUIDs, getVisitsForUIDs]);

  const renderBlogPosts = useCallback(
    (sortedPosts) => (
      <>
        {sortedPosts?.map((post, index) =>
          post ? (
            <Grid key={post.UID} item xs={12} sm={6} md={(index === 0 && 6) || 3}>
              <BlogPostCard
                handleDeleteBlog={handleDeleteBlog}
                post={post}
                index={index}
                viewCount={viewsForAllUIDs[post.UID]}
              />
            </Grid>
          ) : (
            <SkeletonPostItem key={index} />
          )
        )}
      </>
    ),
    [viewsForAllUIDs]
  );

  return (
    <Page title={i18n.t('dashboard.blogs.blogs')}>
      <Container maxWidth={themeStretch ? false : 'lg'}>
        <HeaderBreadcrumbs
          heading={i18n.t('dashboard.blogs.blogs')}
          links={[
            { name: i18n.t('dashboard.dashboard'), href: PATH_DASHBOARD.root },
            { name: i18n.t('dashboard.blogs.blogs'), href: PATH_DASHBOARD.blog.root },
          ]}
          action={
            <Button
              variant="contained"
              sx={{ textTransform: 'none' }}
              component={RouterLink}
              to={PATH_DASHBOARD.blog.newPost}
              startIcon={<Iconify icon={'eva:plus-fill'} />}
            >
              {i18n.t('dashboard.blogs.newBlog')}
            </Button>
          }
        />

        <Stack mb={5} direction="row" alignItems="center" justifyContent="space-between">
          <BlogPostsSearch />
          <BlogPostsSort query={filters} options={SORT_OPTIONS} onSort={handleChangeSort} />
        </Stack>

        <Grid container spacing={3}>
          {renderBlogPosts(sortedPosts)}
        </Grid>
        <br />
        <Grid container direction="column" display="flex" justify="center">
          <Button variant="text" onClick={getMore} disabled={disableMoreButton}>
            {i18n.t('home.more')}
          </Button>
        </Grid>
      </Container>
    </Page>
  );
}
