// @mui
import { useContext, useEffect } from 'react';

import { Container } from '@mui/material';
import { useParams, useLocation } from 'react-router-dom';
// routes
import { PATH_DASHBOARD } from '../../routes/paths';
// hooks
import useSettings from '../../hooks/useSettings';
// components
import Page from '../../components/atoms/Page';
import HeaderBreadcrumbs from '../../components/atoms/HeaderBreadcrumbs';
// sections
import { BlogContext } from '../../contexts/BlogContext';
import { BlogNewPostForm } from '../../sections/@dashboard/blog';
import LottieScreen from '../../components/atoms/LottieScreen';
import i18n from '../../locales/i18n';
// ----------------------------------------------------------------------

export default function BlogNewPost() {
  const { themeStretch } = useSettings();
  const { pathname } = useLocation();
  const { currentBlog, getOneBlog } = useContext(BlogContext);
  const { title = '' } = useParams();
  const isEdit = pathname.includes('edit');

  useEffect(() => {
    if (isEdit) {
      getOneBlog(title);
    }
  }, [title]);

  return currentBlog?.UID === title || !isEdit ? (
    <Page title={!isEdit ? i18n.t('dashboard.blogs.newBlog') : currentBlog?.title || ''}>
      <Container maxWidth={themeStretch ? false : 'lg'}>
        <HeaderBreadcrumbs
          heading={!isEdit ? i18n.t('dashboard.blogs.createNewBlog') : i18n.t('dashboard.blogs.editBlog')}
          links={[
            { name: i18n.t('dashboard.dashboard'), href: PATH_DASHBOARD.root },
            { name: i18n.t('dashboard.blogs.blogs'), href: PATH_DASHBOARD.blog.root },
            { name: !isEdit ? i18n.t('dashboard.blogs.newBlog') : currentBlog?.title || '' },
          ]}
        />
        <BlogNewPostForm isEdit={isEdit} currentBlog={currentBlog?.UID === title ? currentBlog : null} />
      </Container>
    </Page>
  ) : (
    <LottieScreen />
  );
}
