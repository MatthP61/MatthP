import React, { useContext } from 'react';

// components
import Page from '../components/atoms/Page';
import { AboutHero } from '../sections/about';
import TeamBody from '../sections/team/TeamBody';
import i18n from '../locales/i18n';
import { AboutContext } from '../contexts/AboutContext';
import { TeamContext } from '../contexts/TeamContext';
import { RootStyle } from '../utils/GeneralStyle';
// ----------------------------------------------------------------------

export default function Team() {
  const { slogan } = useContext(AboutContext);
  const { memberList } = useContext(TeamContext);

  return (
    <Page title={i18n.t('aboutTeam.theTeam')}>
      <RootStyle>
        <AboutHero
          slogan={slogan}
          titlePart1={i18n.t('aboutTeam.titlePart1')}
          titlePart2={i18n.t('aboutTeam.titlePart2')}
          titlePart3={''}
        />
        <TeamBody members={memberList} />
      </RootStyle>
    </Page>
  );
}
