// @mui
import { Grid, Container } from '@mui/material';
// components
import Page from '../components/atoms/Page';
import { ContactHero, ContactForm } from '../sections/contact';
import i18n from '../locales/i18n';
import { RootStyle } from '../utils/GeneralStyle';

// ----------------------------------------------------------------------

export default function Contact() {
  return (
    <Page title={i18n.t('contactus.title')}>
      <RootStyle>
        <ContactHero />

        <Container sx={{ my: 10 }}>
          <Grid container spacing={10}>
            <Grid item xs={12} md={12}>
              <ContactForm />
            </Grid>
          </Grid>
        </Container>
      </RootStyle>
    </Page>
  );
}
