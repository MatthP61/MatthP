import * as Yup from 'yup';
import { useMemo } from 'react';
import { useSnackbar } from 'notistack';
// form
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
// @mui
import { LoadingButton } from '@mui/lab';
import { Typography, Stack } from '@mui/material';
// firebase
import { useFirebaseApp } from 'reactfire';
import { getFunctions, httpsCallable } from 'firebase/functions';
// components
import { MotionInView, varFade } from '../../components/molecules/animate';
import { FormProvider, RHFTextField } from '../../components/organismes/hook-form';
import i18n from '../../locales/i18n';

// ----------------------------------------------------------------------

export default function ContactForm() {
  const { enqueueSnackbar } = useSnackbar();
  const firebaseApp = useFirebaseApp();
  const functions = getFunctions(firebaseApp);

  const defaultValues = useMemo(() => ({
    name: '',
    email: '',
    subject: '',
    text: '',
  }));

  const newContactSchema = Yup.object().shape({
    name: Yup.string().required(i18n.t('register.lastNamereq')),
    email: Yup.string().required(i18n.t('register.emailreq')).email(i18n.t('form.emailValid')),
    subject: Yup.string().required(i18n.t('contactus.subjectReq')),
    text: Yup.string().required(i18n.t('contactus.textReq')),
  });

  const methods = useForm({
    resolver: yupResolver(newContactSchema),
    defaultValues,
  });

  const {
    reset,
    watch,
    handleSubmit,
    formState: { isSubmitting },
  } = methods;

  const values = watch();

  const onSubmit = async () => {
    try {
      const msg = {
        subject: `${i18n.t('contactus.messageFrom')} ${values.name}`,
        object: values.subject,
        text: values.text,
        name: values.name,
        email: values.email,
      };
      const callable = httpsCallable(functions, 'genericEmail');
      await callable(msg)
        .then(enqueueSnackbar(i18n.t('contactus.msgSuccess')))
        .catch(() => {
          enqueueSnackbar(i18n.t('contactus.msgNoSuccess'), { variant: 'error' });
        });
      reset();
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <FormProvider methods={methods} onSubmit={handleSubmit(onSubmit)}>
      <Stack spacing={5}>
        <MotionInView variants={varFade().inUp}>
          <Typography variant="h3">
            {i18n.t('contactus.welcome')} <br />
            {i18n.t('contactus.glad')}
          </Typography>
        </MotionInView>

        <Stack spacing={3}>
          <MotionInView variants={varFade().inUp}>
            <RHFTextField required name="name" label={i18n.t('contactus.name')} />
          </MotionInView>

          <MotionInView variants={varFade().inUp}>
            <RHFTextField required name="email" label={i18n.t('contactus.email')} />
          </MotionInView>

          <MotionInView variants={varFade().inUp}>
            <RHFTextField required name="subject" label={i18n.t('contactus.subject')} />
          </MotionInView>

          <MotionInView variants={varFade().inUp}>
            <RHFTextField required name="text" label={i18n.t('contactus.enterMsg')} multiline rows={4} />
          </MotionInView>
        </Stack>
        <Stack direction="row" spacing={1.5} sx={{ mt: 3 }} style={{ display: 'flex', justifyContent: 'flex-end' }}>
          <LoadingButton type="submit" variant="contained" loading={isSubmitting} sx={{ textTransform: 'none' }}>
            {i18n.t('contactus.send')}
          </LoadingButton>
        </Stack>
      </Stack>
    </FormProvider>
  );
}
