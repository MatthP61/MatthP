import { m } from 'framer-motion';
// @mui
import { styled } from '@mui/material/styles';
import { Box, Container, Typography, Grid } from '@mui/material';
//
import { TextAnimate, MotionContainer, varFade } from '../../components/molecules/animate';
import i18n from '../../locales/i18n';

// ----------------------------------------------------------------------

const CONTACT = {
  country: 'Canada',
  address: 'Polytechnique Montreal Case postale 6079 Succursale « Centre-ville » Montréal (Québec) H3C 3A7',
  phoneNumber: '(514) 340-4711 #46-45',
};

const RootStyle = styled('div')(({ theme }) => ({
  backgroundSize: 'cover',
  backgroundPosition: 'center',
  backgroundImage:
    'url(https://minimal-assets-api.vercel.app/assets/overlay.svg), url(https://firebasestorage.googleapis.com/v0/b/polyscope-6feba.appspot.com/o/about%2Fcover?alt=media&token=1949b7ee-7616-43a9-b4e7-c16984e5b9f9)',
  padding: theme.spacing(10, 0),
  [theme.breakpoints.up('md')]: {
    height: 560,
    padding: 0,
  },
}));

const ContentStyle = styled('div')(({ theme }) => ({
  textAlign: 'center',
  [theme.breakpoints.up('md')]: {
    textAlign: 'left',
    position: 'absolute',
    bottom: theme.spacing(10),
  },
}));

// ----------------------------------------------------------------------

export default function ContactHero() {
  return (
    <RootStyle>
      <Container component={MotionContainer} sx={{ position: 'relative', height: '100%' }}>
        <ContentStyle>
          <TextAnimate text={i18n.t('contactus.title1')} sx={{ color: 'primary.main' }} variants={varFade().inRight} />
          <br />
          <Box sx={{ display: 'inline-flex', color: 'common.white' }}>
            <TextAnimate text={i18n.t('contactus.title2')} sx={{ mr: 2 }} />
            <TextAnimate text={i18n.t('contactus.title3')} />
          </Box>

          <Grid container spacing={5} sx={{ mt: 5, color: 'common.white' }}>
            <Grid key={CONTACT.country} item xs={12} sm={6} md={4} lg={4} sx={{ pr: { md: 5 } }}>
              <m.div variants={varFade().in}>
                <Typography variant="h6" paragraph>
                  {CONTACT.country}
                </Typography>
              </m.div>
              <m.div variants={varFade().inRight}>
                <Typography variant="body2">
                  {CONTACT.address}
                  <br /> {CONTACT.phoneNumber}
                </Typography>
              </m.div>
            </Grid>
          </Grid>
        </ContentStyle>
      </Container>
    </RootStyle>
  );
}
