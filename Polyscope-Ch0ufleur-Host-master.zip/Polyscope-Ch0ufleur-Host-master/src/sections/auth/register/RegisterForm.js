import * as Yup from 'yup';
import { useContext, useState } from 'react';
import { useSnackbar } from 'notistack';

// form
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
// @mui
import { Stack, IconButton, InputAdornment, Alert } from '@mui/material';
import { LoadingButton } from '@mui/lab';
// hooks
import useAuth from '../../../hooks/useAuth';
import useIsMountedRef from '../../../hooks/useIsMountedRef';
// components
import Iconify from '../../../components/atoms/Iconify';
import { FormProvider, RHFTextField } from '../../../components/organismes/hook-form';
import i18n from '../../../locales/i18n';
import { GeneralSettingsContext } from '../../../contexts/GeneralSettingsContext';

// ----------------------------------------------------------------------
const phoneRegExp =
  /^((\\+[1-9]{1,4}[ \\-]*)|(\\([0-9]{2,3}\\)[ \\-]*)|([0-9]{2,4})[ \\-]*)*?[0-9]{3,4}?[ \\-]*[0-9]{3,4}?$/;

export default function RegisterForm() {
  const { register } = useAuth();
  const { enqueueSnackbar } = useSnackbar();
  const isMountedRef = useIsMountedRef();

  const [showPassword, setShowPassword] = useState(false);
  const { isVerifyCodeValid, getInformations } = useContext(GeneralSettingsContext);

  const RegisterSchema = Yup.object().shape({
    firstName: Yup.string().required(i18n.t('register.firstNamereq')),
    lastName: Yup.string().required(i18n.t('register.lastNamereq')),
    email: Yup.string().email(i18n.t('register.emailValid')).required(i18n.t('register.emailreq')),
    password: Yup.string().required(i18n.t('register.pwreq')),
    phoneNumber: Yup.string()
      .required(i18n.t('register.phoneNumberreq'))
      .matches(phoneRegExp, i18n.t('register.phoneNumberValid'))
      .min(10, i18n.t('register.phoneNumberValid')),
    verifyCode: Yup.string().required(i18n.t('form.codeReq')),
  });

  const defaultValues = {
    firstName: '',
    lastName: '',
    email: '',
    password: '',
    phoneNumber: '',
    verifyCode: '',
  };

  const methods = useForm({
    resolver: yupResolver(RegisterSchema),
    defaultValues,
  });

  const {
    reset,
    setError,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = methods;

  const onSubmit = async (data) => {
    try {
      await getInformations();
      const res = isVerifyCodeValid(data.verifyCode);
      if (res === 'success') {
        await register(data.email, data.password, data.firstName, data.lastName, data.phoneNumber);
      } else if (res === 'nonActive') {
        reset();
        enqueueSnackbar(i18n.t('form.contactAdmin'), { variant: 'error' });
      } else if (res === 'invalid') {
        reset();
        enqueueSnackbar(i18n.t('form.codeInvalid'), { variant: 'error' });
      }
    } catch (error) {
      reset();
      if (isMountedRef.current) {
        setError('afterSubmit', error);
      }
    }
  };

  return (
    <FormProvider methods={methods} onSubmit={handleSubmit(onSubmit)}>
      <Stack spacing={3}>
        {!!errors.afterSubmit && <Alert severity="error">{i18n.t('register.emailExist')}</Alert>}

        <Stack direction={{ xs: 'column', sm: 'row' }} spacing={2}>
          <RHFTextField required name="firstName" label={i18n.t('register.firstName')} />
          <RHFTextField required name="lastName" label={i18n.t('register.lastName')} />
        </Stack>

        <RHFTextField required name="phoneNumber" label={i18n.t('register.phoneNumber')} />
        <RHFTextField required name="email" label={i18n.t('register.email')} />

        <RHFTextField
          required
          name="password"
          label={i18n.t('register.pw')}
          type={showPassword ? 'text' : 'password'}
          InputProps={{
            endAdornment: (
              <InputAdornment position="end">
                <IconButton edge="end" onClick={() => setShowPassword(!showPassword)}>
                  <Iconify icon={showPassword ? 'eva:eye-fill' : 'eva:eye-off-fill'} />
                </IconButton>
              </InputAdornment>
            ),
          }}
        />
        <RHFTextField required name="verifyCode" label={i18n.t('register.verifyCode')} />

        <LoadingButton fullWidth size="large" type="submit" variant="contained" loading={isSubmitting}>
          {i18n.t('register.signup')}
        </LoadingButton>
      </Stack>
    </FormProvider>
  );
}
