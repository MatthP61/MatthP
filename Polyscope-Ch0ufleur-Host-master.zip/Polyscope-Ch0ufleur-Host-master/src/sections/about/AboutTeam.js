import { Link as RouterLink } from 'react-router-dom';
import PropTypes from 'prop-types';
import { useRef } from 'react';
import Slider from 'react-slick';
// @mui
import { useTheme } from '@mui/material/styles';
import { Box, Button, Container, Typography } from '@mui/material';

// routes
import { PATH_PAGE } from '../../routes/paths';

// components
import Iconify from '../../components/atoms/Iconify';
import { CarouselArrows } from '../../components/organismes/carousel';
import MemberCard from '../../components/molecules/team/MemberCard';
import { MotionInView, varFade } from '../../components/molecules/animate';
import i18n from '../../locales/i18n';

// ----------------------------------------------------------------------
AboutTeam.propTypes = {
  title: PropTypes.string,
  subtitle: PropTypes.string,
  members: PropTypes.array,
};

const DevTeam = [
  {
    name: 'Karima Salem',
    role: 'Développeuse',
    picture:
      'https://firebasestorage.googleapis.com/v0/b/polyscope-6feba.appspot.com/o/dev-team%2Fkarima.jpg?alt=media&token=62c2ba20-6d33-4a56-9046-46b37d734b06',
    linkedin: 'https://www.linkedin.com/in/karima-salem-a59381152/',
  },
  {
    name: 'Nibrass Aljobouri',
    role: 'Développeuse',
    picture:
      'https://firebasestorage.googleapis.com/v0/b/polyscope-6feba.appspot.com/o/dev-team%2Fnibrass.jpg?alt=media&token=524c6a59-eee9-4514-81ce-e409584f61ea',
    linkedin: 'https://www.linkedin.com/in/nibrass-aljobouri/',
  },
  {
    name: 'Omid Adibi',
    role: 'Développeur',
    picture:
      'https://firebasestorage.googleapis.com/v0/b/polyscope-6feba.appspot.com/o/dev-team%2Fomid.jpeg?alt=media&token=0f9550d1-fb75-45d2-b515-d088507c5e55',
    linkedin: 'https://www.linkedin.com/in/omidadibi/',
  },
  {
    name: 'Andres Flores',
    role: 'Développeur',
    picture:
      'https://firebasestorage.googleapis.com/v0/b/polyscope-6feba.appspot.com/o/dev-team%2Fandres.jpg?alt=media&token=a0465c0f-6c4e-424b-b129-9c7c614eec40',
    linkedin: 'https://www.linkedin.com/in/andres-flores-3a679bb5/',
  },
  {
    name: 'Dinia Hamitouche',
    role: 'Développeuse',
    picture:
      'https://firebasestorage.googleapis.com/v0/b/polyscope-6feba.appspot.com/o/dev-team%2Fdinia.jpg?alt=media&token=24863a42-5762-401e-8bd9-dbc1b35a606e',
    linkedin: 'https://www.linkedin.com/in/dinia-hamitouche',
  },
];

export default function AboutTeam({ title, subtitle, members }) {
  const carouselRef = useRef(null);
  const theme = useTheme();

  const settings = {
    arrows: false,
    slidesToShow: 4,
    centerMode: true,
    centerPadding: '0px',
    rtl: Boolean(theme.direction === 'rtl'),
    responsive: [
      {
        breakpoint: 1279,
        settings: { slidesToShow: 3 },
      },
      {
        breakpoint: 959,
        settings: { slidesToShow: 2 },
      },
      {
        breakpoint: 600,
        settings: { slidesToShow: 1 },
      },
    ],
  };

  const settingDev = {
    arrows: false,
    slidesToShow: 5,
    centerMode: true,
    centerPadding: '0px',
    rtl: Boolean(theme.direction === 'rtl'),
    responsive: [
      {
        breakpoint: 1279,
        settings: { slidesToShow: 3 },
      },
      {
        breakpoint: 959,
        settings: { slidesToShow: 2 },
      },
      {
        breakpoint: 600,
        settings: { slidesToShow: 1 },
      },
    ],
  };

  const handlePrevious = () => {
    carouselRef.current.slickPrev();
  };

  const handleNext = () => {
    carouselRef.current.slickNext();
  };

  return (
    <Container sx={{ pb: 10, textAlign: 'center' }}>
      <MotionInView variants={varFade().inDown}>
        <Typography component="p" variant="overline" sx={{ mb: 2, color: 'text.secondary' }}>
          {i18n.t('aboutTeam.dreamTitle')}
        </Typography>
      </MotionInView>

      <MotionInView variants={varFade().inUp}>
        <Typography variant="h2" sx={{ mb: 3 }}>
          {title}
        </Typography>
      </MotionInView>

      <MotionInView variants={varFade().inUp}>
        <Typography
          sx={{
            mx: 'auto',
            maxWidth: 630,
            color: (theme) => (theme.palette.mode === 'light' ? 'text.secondary' : 'common.white'),
          }}
        >
          {subtitle}
        </Typography>
      </MotionInView>

      <Box sx={{ position: 'relative' }}>
        <CarouselArrows filled onNext={handleNext} onPrevious={handlePrevious}>
          <Slider ref={carouselRef} {...settings}>
            {members.map((member) => (
              <MotionInView key={member.UID} variants={varFade().in} sx={{ px: 1.5, py: 10 }}>
                <MemberCard member={member} />
              </MotionInView>
            ))}
          </Slider>
        </CarouselArrows>
      </Box>
      <Button
        variant="outlined"
        color="inherit"
        size="large"
        endIcon={<Iconify icon={'ic:round-arrow-right-alt'} width={24} height={24} />}
        sx={{ mx: 'auto', textTransform: 'none', mb: 10 }}
        component={RouterLink}
        to={PATH_PAGE.team}
      >
        {i18n.t('aboutTeam.seeAllMembers')}
      </Button>
      <MotionInView variants={varFade().inUp}>
        <Typography variant="h2" sx={{ mb: 3 }}>
          {i18n.t('aboutTeam.titlePart3')}
        </Typography>
      </MotionInView>

      <MotionInView variants={varFade().inUp}>
        <Typography
          sx={{
            mx: 'auto',
            maxWidth: 630,
            color: (theme) => (theme.palette.mode === 'light' ? 'text.secondary' : 'common.white'),
          }}
        >
          “Website without visitors is like a ship lost in the horizon.”, Dr. Christopher Dayagdag
        </Typography>
      </MotionInView>
      <Box sx={{ position: 'relative' }}>
        <CarouselArrows filled onNext={handleNext} onPrevious={handlePrevious}>
          <Slider ref={carouselRef} {...settingDev}>
            {DevTeam.map((member) => (
              <MotionInView key={member.UID} variants={varFade().in} sx={{ px: 1.5, py: 10 }}>
                <MemberCard member={member} />
              </MotionInView>
            ))}
          </Slider>
        </CarouselArrows>
      </Box>
    </Container>
  );
}
