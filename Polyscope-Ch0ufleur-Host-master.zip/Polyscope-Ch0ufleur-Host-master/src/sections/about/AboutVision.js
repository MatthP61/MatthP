import PropTypes from 'prop-types';

// @mui
import { Box, Container, Typography, Grid } from '@mui/material';

// components
import Image from '../../components/atoms/Image';
import Logo from '../../components/atoms/Logo';
import Markdown from '../../components/atoms/Markdown';
import { MotionInView, varFade } from '../../components/molecules/animate';

// ----------------------------------------------------------------------
AboutVision.propTypes = {
  text: PropTypes.string,
  vision: PropTypes.string,
};

export default function AboutVision({ text, vision }) {
  return (
    <Container sx={{ mt: 10 }}>
      <Box
        sx={{
          mb: 10,
          position: 'relative',
          borderRadius: 2,
          overflow: 'hidden',
        }}
      >
        <Grid container justifyContent="center">
          <Grid item xs={12} sm={8}>
            <MotionInView variants={varFade().inUp}>
              <Typography variant="h3" sx={{ textAlign: 'center' }}>
                {vision}
              </Typography>
            </MotionInView>
          </Grid>
        </Grid>

        <br />

        <Image
          src="https://firebasestorage.googleapis.com/v0/b/polyscope-6feba.appspot.com/o/about%2Fpic2?alt=media&token=e1ae0835-6578-4f6f-9d67-ea75011c926e"
          alt="about-vision"
          effect="black-and-white"
        />

        <Box
          sx={{
            bottom: { xs: 24, md: 80 },
            width: '100%',
            display: 'flex',
            flexWrap: 'wrap',
            alignItems: 'center',
            position: 'absolute',
            justifyContent: 'center',
          }}
        >
          <MotionInView key={'logo'} variants={varFade().in}>
            <Logo />
          </MotionInView>
        </Box>
      </Box>

      <Grid container justifyContent="center">
        <Grid item xs={12} sm={8}>
          <MotionInView variants={varFade().inUp}>
            <Markdown children={text || ''} />
          </MotionInView>
        </Grid>
      </Grid>
    </Container>
  );
}
