/* eslint-disable no-unused-vars */
// @mui
import React, { useContext, useState, useMemo, useEffect } from 'react';
import PropTypes from 'prop-types';
import { styled } from '@mui/material/styles';
import { Box, Container, Typography, Stack, Button, Link } from '@mui/material';
// components
import { Link as RouterLink } from 'react-router-dom';
import Masonry from '@mui/lab/Masonry';
import { BlogContext } from '../../contexts/BlogContext';
import i18n from '../../locales/i18n';
import useResponsive from '../../hooks/useResponsive';
// utils
import { fDate } from '../../utils/formatTime';
// components
import Image from '../../components/atoms/Image';
import BgOverlay from '../../components/atoms/BgOverlay';
import TextMaxLine from '../../components/atoms/TextMaxLine';
import { BlogPostItemMobile } from '../@dashboard/blog';
import { DashboardAnalyticsContext } from '../../contexts/DashboardAnalyticsContext';

// ----------------------------------------------------------------------

const RootStyle = styled('div')(({ theme }) => ({
  padding: theme.spacing(0, 0),
  [theme.breakpoints.up('md')]: {
    paddingBottom: theme.spacing(15),
  },
}));
// ----------------------------------------------------------------------

export default function HomePopulaire() {
  const { BlogList } = useContext(BlogContext);
  const isDesktop = useResponsive('up', 'md');

  const [popularBlogs, setPopularBlogs] = useState([]);
  const { getBlogViews, allViewsTableData } = useContext(DashboardAnalyticsContext);

  useEffect(() => {
    getBlogViews().then(() => {
      const sortedTableDataArray = Object.entries(allViewsTableData).sort(
        ([UID1, data1], [UID2, data2]) => data2.views - data1.views
      );
      const UIDList = sortedTableDataArray.map((x) => x[0]);
      setPopularBlogs(BlogList.filter((blog) => UIDList.includes(blog.UID)));
    });
  }, [getBlogViews, BlogList.length === 0, allViewsTableData.length === 0]);

  const sortedTableDataArray = useMemo(
    () => Object.entries(allViewsTableData).sort(([UID1, data1], [UID2, data2]) => data2.views - data1.views),
    [allViewsTableData]
  );

  useEffect(() => {
    const UIDList = sortedTableDataArray.map((x) => x[0]);
    setPopularBlogs(BlogList.filter((blog) => UIDList.includes(blog.UID)));
  }, [sortedTableDataArray]);

  return (
    <RootStyle>
      <Container>
        <Stack
          direction="row"
          alignItems="center"
          justifyContent={{ xs: 'center', md: 'space-between' }}
          sx={{
            mb: { xs: 8, md: 10 },
            textAlign: { xs: 'center', md: 'left' },
          }}
        >
          <Stack
            sx={{
              maxWidth: { md: 460 },
            }}
          >
            <Typography variant="h2" sx={{ mt: 2, mb: 3 }}>
              {i18n.t('home.populaireArticle')}
            </Typography>
            <Typography sx={{ color: 'text.secondary' }}>{i18n.t('home.popularSub')}</Typography>
          </Stack>

          <Link to={`blogs`} color="inherit" component={RouterLink} textAlign="left">
            <Button sx={{ display: { xs: 'none', md: 'inline-flex' } }}>{i18n.t('home.more')}</Button>
          </Link>
        </Stack>
        <Box
          sx={{
            display: 'grid',
            gap: { xs: 3, md: 4 },
            gridTemplateColumns: {
              xs: 'repeat(1, 1fr)',
              sm: 'repeat(2, 1fr)',
            },
          }}
        >
          {isDesktop ? (
            popularBlogs.length > 0 && (
              <>
                <PostItem post={popularBlogs[0]} largePost />

                <Masonry columns={{ xs: 1, md: 2 }} spacing={4}>
                  {popularBlogs.slice(1, 5).map((post, index) => (
                    <PostItem key={post?.UID} post={post} order={index % 2} />
                  ))}
                </Masonry>
              </>
            )
          ) : (
            <>
              {popularBlogs.length > 0 &&
                popularBlogs
                  .slice(0, 5)
                  .map((post) => <BlogPostItemMobile key={post?.UID} post={post} path="/career" />)}
            </>
          )}
        </Box>

        <Stack
          alignItems="center"
          sx={{
            mt: 8,
            display: { xs: 'flex', md: 'none' },
          }}
        >
          <Link to={`blogs`} color="inherit" component={RouterLink} textAlign="left">
            <Button>{i18n.t('home.more')}</Button>
          </Link>
        </Stack>
      </Container>
    </RootStyle>
  );
}

PostItem.propTypes = {
  largePost: PropTypes.bool,
  order: PropTypes.number,
  post: PropTypes.shape({
    cover: PropTypes.string,
    createdAt: PropTypes.number,
    description: PropTypes.string,
    duration: PropTypes.string,
    title: PropTypes.string,
    UID: PropTypes.string,
  }),
};

function PostItem({ post, order, largePost }) {
  const { title, duration, cover, description, createdAt, UID } = post;

  return (
    <Link to={`blog/post/${UID}`} color="inherit" component={RouterLink} textAlign="left">
      <Stack
        spacing={2}
        sx={{
          ...(largePost && {
            borderRadius: 2,
            overflow: 'hidden',
            position: 'relative',
          }),
        }}
      >
        <Image
          src={cover}
          alt={title}
          ratio={(largePost && '3/4') || (order && '4/3') || '1/1'}
          sx={{ borderRadius: 2 }}
        />

        <Stack
          spacing={largePost ? 2 : 1}
          sx={{
            ...(largePost && {
              p: 5,
              bottom: 0,
              zIndex: 9,
              position: 'absolute',
              color: 'common.white',
            }),
          }}
        >
          {createdAt && (
            <Stack
              direction="row"
              alignItems="center"
              sx={{
                typography: 'caption',
                color: 'text.disabled',
                ...(largePost && {
                  opacity: 0.72,
                  color: 'inherit',
                }),
              }}
            >
              {fDate(createdAt)}
            </Stack>
          )}
          <TextMaxLine variant={largePost ? 'h3' : 'h6'} asLink>
            {title}
          </TextMaxLine>
          {largePost ? (
            <Typography sx={{ opacity: 0.48 }}>{description}</Typography>
          ) : (
            <TextMaxLine variant="body2" sx={{ color: 'text.secondary' }}>
              {description}
            </TextMaxLine>
          )}
        </Stack>

        {largePost && <BgOverlay />}
      </Stack>
    </Link>
  );
}
