// @mui
import React, { useState, useContext, useEffect, useCallback } from 'react';
import { styled } from '@mui/material/styles';
import { Box, Grid, Container, Typography, Button, Tabs, Tab } from '@mui/material';
import { useNavigate } from 'react-router-dom';
// components
import { MotionInView, varFade } from '../../components/molecules/animate';
import CardBox from '../../components/molecules/card/CardBox';
// context
import { BlogContext } from '../../contexts/BlogContext';
import { CategoryContext } from '../../contexts/CategoryContext';
import i18n from '../../locales/i18n';
import useIsMountedRef from '../../hooks/useIsMountedRef';

const RootStyle = styled('div')(({ theme }) => ({
  paddingTop: theme.spacing(0),
  [theme.breakpoints.up('md')]: {
    paddingBottom: theme.spacing(15),
  },
}));

function a11yProps(index) {
  return {
    id: `simple-tab-${index}`,
    'aria-controls': `simple-tabpanel-${index}`,
  };
}

// ----------------------------------------------------------------------

export default function HomeRecent() {
  const [value, setValue] = useState(0);
  const { BlogList, getBlogsByCategory, CategoryList } = useContext(BlogContext);
  const { categoryActiveList } = useContext(CategoryContext);
  const navigate = useNavigate();
  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  const slicedCategoryArray = categoryActiveList.slice(0, 5);
  BlogList.filter((v) => v.category === slicedCategoryArray[value]?.title);
  const isMountedRef = useIsMountedRef();
  const getPosts = useCallback(async () => {
    try {
      if (isMountedRef.current) {
        getBlogsByCategory(slicedCategoryArray[value]?.title);
      }
    } catch (error) {
      console.error(error);
    }
  }, [isMountedRef, value]);

  useEffect(() => {
    getPosts();
  }, [getPosts, value]);

  return (
    <RootStyle>
      <Container>
        <Grid
          container
          sx={{
            mb: { xs: 8, md: 8 },
          }}
          spacing={2}
        >
          <Grid
            item
            sx={{
              textAlign: 'left',
            }}
            xs={9}
          >
            <MotionInView variants={varFade().inDown}>
              <Typography variant="h2">{i18n.t('home.recentArticle')}</Typography>
            </MotionInView>
          </Grid>
          <Grid
            item
            sx={{
              textAlign: 'right',
              alignSelf: 'center',
            }}
            xs={3}
          >
            <Button onClick={() => navigate('/blogs')} variant="text">
              {i18n.t('home.more')}
            </Button>
          </Grid>
          <Grid
            item
            sx={{
              textAlign: 'right',
              alignSelf: 'center',
            }}
            xs={12}
          >
            <Box sx={{ borderBottom: 1, overflow: 'visible', borderColor: 'divider' }}>
              <Tabs
                value={value}
                onChange={handleChange}
                variant="scrollable"
                scrollButtons="auto"
                textColor="secondary"
                indicatorColor="secondary"
                aria-label="Tags"
                allowScrollButtonsMobile
              >
                {slicedCategoryArray.map((category) => (
                  <Tab key={category?.UID} label={category.title} {...a11yProps(2)} />
                ))}
              </Tabs>
            </Box>
          </Grid>
          {CategoryList.length > 0 && (
            <Grid
              item
              sx={{
                textAlign: 'right',
                alignSelf: 'center',
              }}
              xs={12}
            >
              <Box
                sx={{
                  display: 'grid',
                  gap: { xs: 5, md: 3, lg: 5 },
                  alignItems: 'center',
                  gridTemplateColumns: { xs: 'repeat(1, 1fr)', md: 'repeat(4, 1fr)', lg: 'repeat(4, 1fr)' },
                  gridTemplateRows: { md: `repeat(${CategoryList.lenght > 4 ? '2' : '1'}, 1fr)` },
                }}
              >
                {CategoryList.sort((a, b) => (a.createdAt > b.createdAt ? 1 : -1))
                  .slice(0, 8)
                  .map(
                    (card, index) =>
                      card?.publish && (
                        <MotionInView variants={varFade().inUp} key={index} sx={{ alignItems: 'center' }}>
                          <CardBox blog={card} index={index} />
                        </MotionInView>
                      )
                  )}
              </Box>
            </Grid>
          )}
        </Grid>
      </Container>
    </RootStyle>
  );
}
