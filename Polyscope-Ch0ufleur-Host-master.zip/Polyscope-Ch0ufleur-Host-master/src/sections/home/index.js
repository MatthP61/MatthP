export { default as HomeMinimal } from './HomeMinimal';
export { default as HomePopulaire } from './HomePopulaire';
export { default as HomeRecent } from './HomeRecent';
