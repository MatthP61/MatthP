// @mui
import { styled } from '@mui/material/styles';
import { Grid, Container, Typography, Button } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { PATH_PAGE } from '../../routes/paths';
import i18n from '../../locales/i18n';
// components
import { MotionInView, varFade } from '../../components/molecules/animate';
import VolumeCard from '../../components/molecules/volume/VolumeCard';

const RootStyle = styled('div')(({ theme }) => ({
  paddingTop: theme.spacing(10),
  [theme.breakpoints.up('md')]: {
    paddingBottom: theme.spacing(5),
  },
}));

export default function HomeMinimal() {
  const navigate = useNavigate();
  const navigateToEditions = () => {
    navigate(PATH_PAGE.editions);
  };

  return (
    <RootStyle>
      <Container>
        <Grid
          container
          sx={{
            mb: { xs: 8, md: 8 },
          }}
          spacing={2}
        >
          <Grid
            item
            sx={{
              textAlign: 'left',
            }}
            xs={9}
          >
            <MotionInView variants={varFade().inDown}>
              <Typography variant="h2">{i18n.t('home.recentEdition')}</Typography>
            </MotionInView>
          </Grid>
          <Grid
            item
            sx={{
              textAlign: 'right',
              alignSelf: 'center',
            }}
            xs={3}
          >
            <Button variant="text" onClick={navigateToEditions} sx={{ textTransform: 'none' }}>
              {i18n.t('home.archivesPDF')}
            </Button>
          </Grid>
          <Grid
            item
            sx={{
              textAlign: 'right',
              alignSelf: 'center',
            }}
            xs={12}
          >
            <VolumeCard />
          </Grid>
        </Grid>
      </Container>
    </RootStyle>
  );
}
