import * as Yup from 'yup';
import { useMemo } from 'react';
import { useSnackbar } from 'notistack';
// form
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
// @mui
import { LoadingButton } from '@mui/lab';
import { Typography, Stack, Alert } from '@mui/material';
// firebase
import { useFirebaseApp } from 'reactfire';
import { getFunctions, httpsCallable } from 'firebase/functions';
// components
import { MotionInView, varFade } from '../../components/molecules/animate';
import { LabelStyle } from '../../utils/GeneralStyle';
import { FormProvider, RHFTextField } from '../../components/organismes/hook-form';
import i18n from '../../locales/i18n';

// ----------------------------------------------------------------------

export default function TextForm() {
  const { enqueueSnackbar } = useSnackbar();
  const firebaseApp = useFirebaseApp();
  const functions = getFunctions(firebaseApp);

  const defaultValues = useMemo(() => ({
    name: '',
    email: '',
    title: '',
    description: '',
    text: '',
    comment: '',
  }));

  const newTextSchema = Yup.object().shape({
    name: Yup.string().required(i18n.t('register.lastNamereq')),
    email: Yup.string().required(i18n.t('register.emailreq')).email(i18n.t('form.emailValid')),
    title: Yup.string().required(i18n.t('sendText.titleReq')),
    description: Yup.string().required(i18n.t('sendText.descReq')),
    text: Yup.string().required(i18n.t('contactus.textReq')),
    comment: Yup.string(),
  });

  const methods = useForm({
    resolver: yupResolver(newTextSchema),
    defaultValues,
  });

  const {
    reset,
    watch,
    handleSubmit,
    formState: { isSubmitting },
  } = methods;

  const values = watch();

  const onSubmit = async () => {
    try {
      const msg = {
        subject: `${i18n.t('sendText.textFrom')} ${values.name}`,
        object: `${i18n.t('sendText.title')} : ${values.title}`,
        description: `${i18n.t('sendText.desc')} : \n${values.description}`,
        text: `${i18n.t('sendText.textGrid')} : \n${values.text}`,
        comment: `${i18n.t('sendText.commentGrid')} : \n${values.comment}`,
        name: values.name,
        email: values.email,
      };
      const callable = httpsCallable(functions, 'genericEmail');
      await callable(msg)
        .then(enqueueSnackbar(i18n.t('sendText.textSuccess')))
        .catch(() => {
          enqueueSnackbar(i18n.t('sendText.textNoSuccess'), { variant: 'error' });
        });
      reset();
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <FormProvider methods={methods} onSubmit={handleSubmit(onSubmit)}>
      <Stack spacing={5}>
        <MotionInView variants={varFade().inUp}>
          <Typography variant="h3">{i18n.t('sendText.pleaseFill')}</Typography>
        </MotionInView>

        <Stack spacing={3}>
          <MotionInView variants={varFade().inUp}>
            <RHFTextField required name="name" label={i18n.t('contactus.name')} />
          </MotionInView>

          <MotionInView variants={varFade().inUp}>
            <RHFTextField required name="email" label={i18n.t('contactus.email')} />
          </MotionInView>

          <br />

          <LabelStyle>{i18n.t('sendText.infoBlog')}</LabelStyle>
          <MotionInView variants={varFade().inUp}>
            <RHFTextField required name="title" label={i18n.t('sendText.title')} />
          </MotionInView>

          <MotionInView variants={varFade().inUp}>
            <RHFTextField required name="description" label={i18n.t('sendText.description')} multiline rows={5} />
          </MotionInView>

          <MotionInView variants={varFade().inUp}>
            <RHFTextField required name="text" label={i18n.t('sendText.text')} multiline rows={15} />
          </MotionInView>

          <MotionInView variants={varFade().inUp}>
            <RHFTextField name="comment" label={i18n.t('sendText.comment')} multiline rows={4} />
          </MotionInView>
        </Stack>
        <MotionInView variants={varFade().inUp}>
          <Alert severity="info" sx={{ mb: 3 }}>
            {i18n.t('sendText.note')}
          </Alert>
        </MotionInView>

        <Stack direction="row" spacing={1.5} sx={{ mt: 3 }} style={{ display: 'flex', justifyContent: 'flex-end' }}>
          <LoadingButton
            fullWidth
            type="submit"
            variant="contained"
            loading={isSubmitting}
            sx={{ textTransform: 'none' }}
          >
            {i18n.t('sendText.send')}
          </LoadingButton>
        </Stack>
      </Stack>
    </FormProvider>
  );
}
