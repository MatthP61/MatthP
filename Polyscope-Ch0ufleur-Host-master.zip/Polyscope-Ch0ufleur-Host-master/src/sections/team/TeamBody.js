import PropTypes from 'prop-types';
// @mui
import { Container, Grid } from '@mui/material';

// components
import { MotionInView, varFade } from '../../components/molecules/animate';
import MemberCard from '../../components/molecules/team/MemberCard';

// ----------------------------------------------------------------------
TeamBody.propTypes = {
  members: PropTypes.array,
};

export default function TeamBody({ members }) {
  return (
    <Container sx={{ mt: 10 }}>
      <Grid container spacing={1}>
        {members.map((member) => (
          <Grid key={member.UID} item xs={12} md={4}>
            <MotionInView key={member.UID} variants={varFade().in} sx={{ px: 1.5, py: 3 }}>
              <MemberCard member={member} />
            </MotionInView>
          </Grid>
        ))}
      </Grid>
    </Container>
  );
}
