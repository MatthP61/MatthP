// @mui
import React, { useContext, useEffect, useState, useCallback } from 'react';
import { styled } from '@mui/material/styles';
import { Card, Box, Grid, Container, Typography } from '@mui/material';
// components
import { MotionInView, varFade } from '../../components/molecules/animate';
import EditionCardBox from '../../components/molecules/card/EditionCardBox';
import { EditionMenu } from '../@dashboard/edition';
import { EditionContext } from '../../contexts/EditionContext';
import { fTimestamp } from '../../utils/formatTime';
import i18n from '../../locales/i18n';

const RootStyle = styled('div')(({ theme }) => ({
  paddingTop: theme.spacing(0),
}));

// ----------------------------------------------------------------------

export default function ListEditions() {
  const { VolumeList, getVolumes, EditionByVolumeList, getEditionsVK, currentVolume } = useContext(EditionContext);

  const [listOfEdition, setListOfEdition] = useState([]);
  const [volumeList, setVolumeList] = useState([' ']);
  const [volume, setVolume] = useState('');

  const getEditions = useCallback(async () => {
    try {
      await getEditionsVK(volume);
    } catch (e) {
      console.log('ERROR: ', e);
    }
  }, [volume]);

  const getVolumesList = useCallback(async () => {
    try {
      await getVolumes();
    } catch (e) {
      console.log('ERROR: ', e);
    }
  }, []);

  useEffect(() => {
    getVolumesList();
  }, [getVolumesList]);

  const pluck = (arr, key) => arr.map((i) => i[key]);

  useEffect(() => {
    setVolumeList(pluck(VolumeList, 'name'));
  }, [VolumeList]);

  useEffect(() => {
    if (currentVolume !== undefined) {
      setVolume(currentVolume);
    }
  }, [currentVolume]);

  useEffect(() => {
    if (volume) getEditions();
  }, [getEditions]);

  useEffect(() => {
    const tmp = EditionByVolumeList.filter((value) => filterPublishedEdition(value.publishDate));
    setListOfEdition(tmp);
  }, [EditionByVolumeList]);

  const filterPublishedEdition = (time) => {
    const nowTime = fTimestamp(Date.now());
    return nowTime >= time;
  };

  const volumeMenu = () => {
    const volumes = [];
    volumeList.forEach((item) => {
      volumes.push({ value: item, label: item });
    });
    return volumes;
  };

  return (
    <RootStyle>
      <Container maxWidth={'xl'}>
        <Grid container sx={{ mb: { xs: 8, md: 8 } }} spacing={2}>
          <Grid
            item
            sx={{
              textAlign: 'left',
            }}
            xs={7}
          >
            <Typography variant="h4">{volume}</Typography>
          </Grid>
          <Grid
            item
            sx={{
              textAlign: 'right',
              alignSelf: 'center',
            }}
            xs={5}
          >
            <EditionMenu currentVolume={volume} setCurrentVolume={setVolume} sortedVolumesList={volumeMenu()} />
          </Grid>

          <Grid
            item
            sx={{
              textAlign: 'right',
              alignSelf: 'center',
            }}
            xs={12}
          >
            {listOfEdition.length > 0 ? (
              <Box
                sx={{
                  display: 'grid',
                  gap: { xs: 5, md: 3, lg: 3 },
                  alignItems: 'center',
                  gridTemplateColumns: { xs: 'repeat(1, 1fr)', md: 'repeat(3, 1fr)', lg: 'repeat(3, 1fr)' },
                }}
              >
                {listOfEdition.map((edition) => (
                  <MotionInView variants={varFade().inUp} key={edition.UID} sx={{ alignItems: 'center' }}>
                    <EditionCardBox key={edition.uid} edition={edition} />
                  </MotionInView>
                ))}
              </Box>
            ) : (
              <Card sx={{ borderRadius: 2, p: 2 }}>
                <Typography variant="h4" sx={{ textAlign: 'center' }} gutterBottom>
                  {i18n.t('editions.checkFuture')}
                </Typography>
              </Card>
            )}
          </Grid>
        </Grid>
      </Container>
    </RootStyle>
  );
}
