// @mui
import React, { useContext } from 'react';
import { styled } from '@mui/material/styles';
import { Grid, Card, Stack, Container, Typography } from '@mui/material';
// components
import { MotionInView, varFade } from '../../components/molecules/animate';
import FutureEditionCardBox from '../../components/molecules/card/FutureEditionCardBox';
import { EditionContext } from '../../contexts/EditionContext';
import i18n from '../../locales/i18n';

const RootStyle = styled('div')(({ theme }) => ({
  paddingTop: theme.spacing(0),
}));

// ----------------------------------------------------------------------

export default function EditionsCalendar() {
  const { futureEditions } = useContext(EditionContext);

  return (
    <RootStyle>
      <Container maxWidth={'xl'}>
        <Grid container sx={{ mb: { xs: 8, md: 8 } }} spacing={2}>
          <Grid
            item
            sx={{
              textAlign: 'left',
            }}
            xs={12}
          >
            <Typography variant="h4">
              {futureEditions.length > 1 ? i18n.t('editions.futureEditions') : i18n.t('editions.futureEdition')}
            </Typography>
          </Grid>

          <Grid
            item
            sx={{
              textAlign: 'center',
              alignSelf: 'center',
            }}
            xs={12}
          >
            {futureEditions.length > 0 ? (
              <Stack spacing={2}>
                {futureEditions.map((edition) => (
                  <MotionInView variants={varFade().inUp} key={edition.UID} sx={{ alignItems: 'center' }}>
                    <FutureEditionCardBox key={edition.uid} edition={edition} />
                  </MotionInView>
                ))}
              </Stack>
            ) : (
              <Card sx={{ borderRadius: 2, p: 2 }}>
                <Typography variant="h4" gutterBottom>
                  {i18n.t('editions.noFuture')}
                </Typography>
              </Card>
            )}
          </Grid>
        </Grid>
      </Container>
    </RootStyle>
  );
}
