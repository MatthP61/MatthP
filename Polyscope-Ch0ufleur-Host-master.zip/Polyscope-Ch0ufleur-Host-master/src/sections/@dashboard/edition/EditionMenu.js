import PropTypes from 'prop-types';
// @mui
import { MenuItem, TextField } from '@mui/material';

EditionMenu.propTypes = {
  currentVolume: PropTypes.string,
  setCurrentVolume: PropTypes.func,
  sortedVolumesList: PropTypes.array,
};

export default function EditionMenu({ currentVolume, setCurrentVolume, sortedVolumesList }) {
  const handleItemClick = (event) => {
    const menuItem = event.target.outerText;
    setCurrentVolume(menuItem);
  };

  return (
    <TextField select size="small" value={currentVolume}>
      {sortedVolumesList.map((volume) => (
        <MenuItem
          key={volume.value}
          value={volume.value}
          sx={{ mx: 1, my: 0.5, borderRadius: 1 }}
          onClick={handleItemClick}
        >
          {volume.label}
        </MenuItem>
      ))}
    </TextField>
  );
}
