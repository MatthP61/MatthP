import React, { useContext, useCallback, useState } from 'react';
import * as Yup from 'yup';
import { useNavigate } from 'react-router-dom';
import frLocale from 'date-fns/locale/fr';
// form
import { yupResolver } from '@hookform/resolvers/yup';
import { useForm } from 'react-hook-form';
import { useSnackbar } from 'notistack';
// @mui
import { LoadingButton } from '@mui/lab';
import { Card, Stack, Grid, TextField } from '@mui/material';
import DesktopDatePicker from '@mui/lab/DesktopDatePicker';
import LocalizationProvider from '@mui/lab/LocalizationProvider';
import AdapterDateFns from '@mui/lab/AdapterDateFns';
// routes
import { getStorage, ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { PATH_DASHBOARD } from '../../../routes/paths';
// components
import { FormProvider, RHFTextField, RHFUploadSingleFile, RHFSwitch } from '../../../components/organismes/hook-form';
import { EditionContext } from '../../../contexts/EditionContext';
import { deletePreviousDrop } from '../../../components/atoms/FirebaseFunctions';
import i18n from '../../../locales/i18n';
import { fTimestamp } from '../../../utils/formatTime';
import { LabelStyle } from '../../../utils/GeneralStyle';

// ----------------------------------------------------------------------

export default function EditionNewForm() {
  const { uploadEdition } = useContext(EditionContext);
  const { enqueueSnackbar } = useSnackbar();
  const navigate = useNavigate();
  const [coverStorage, setCoverStorage] = useState([]);
  const [pdfStorage, setPDFStorage] = useState([]);

  const [calendarValue, setCalendarValue] = useState(new Date());

  const NewEditionSchema = Yup.object().shape({
    volume: Yup.number().required(i18n.t('dashboard.newEdition.volumeReq')),
    number: Yup.number().required(i18n.t('dashboard.newEdition.numberReq')),
    description: Yup.string().required(i18n.t('dashboard.newEdition.desReq')),
    cover: Yup.mixed().test('required', i18n.t('dashboard.newEdition.coverReq'), (value) => value !== ''),
    pdf: Yup.mixed().required(i18n.t('dashboard.newEdition.fileReq')),
    parutionKapote: Yup.string().when('kapote', {
      is: true,
      then: Yup.string().required(i18n.t('dashboard.newEdition.yearReq')),
    }),
  });

  const defaultValues = {
    volume: '',
    number: '',
    cover: null,
    pdf: null,
    description: '',
    kapote: false,
    publishNow: true,
    publishDate: '',
    parutionKapote: '',
  };

  const methods = useForm({
    resolver: yupResolver(NewEditionSchema),
    defaultValues,
  });

  const {
    reset,
    watch,
    setValue,
    handleSubmit,
    formState: { isSubmitting },
  } = methods;

  const values = watch();

  const onSubmit = async () => {
    try {
      await new Promise((resolve) => setTimeout(resolve, 300));
      if (!values.publishNow) {
        values.publishDate = fTimestamp(calendarValue);
      } else {
        values.publishDate = fTimestamp(new Date());
      }
      deletePreviousDrop(coverStorage);
      deletePreviousDrop(pdfStorage);
      values.volume = parseInt(values.volume, 10);
      values.number = parseInt(values.number, 10);

      uploadEdition(values);
      reset();

      enqueueSnackbar(i18n.t('form.createSuccess'));
      navigate(PATH_DASHBOARD.edition.list);
    } catch (error) {
      console.error(error);
    }
  };

  const handleDropPicture = useCallback(
    (acceptedFiles) => {
      const file = acceptedFiles[0];

      if (file === '') {
        console.error(`not an image, the image file is a ${typeof file}`);
      }

      const tmp = Math.random();
      const storage = getStorage();
      const storageRef = ref(storage, `/editions-image/${file.name}${tmp}`);
      uploadImage(storageRef, 'cover', file);
    },
    [setValue]
  );

  const handleDropPDF = useCallback(
    (acceptedFiles) => {
      const file = acceptedFiles[0];

      if (file === '') {
        console.error(`not an image, the image file is a ${typeof file}`);
      }

      const tmp = Math.random();
      const storage = getStorage();
      const storageRef = ref(storage, `/editions-pdf/${file.name}${tmp}`);
      uploadImage(storageRef, 'pdf', file);
    },
    [setValue]
  );

  const uploadImage = (storageRef, field, file) => {
    uploadBytes(storageRef, file).then(() => {
      getDownloadURL(storageRef).then((url) => {
        setValue(field, url);
        if (field === 'cover') {
          setCoverStorage((coverStorage) => [...coverStorage, url]);
        } else {
          setPDFStorage((pdfStorage) => [...pdfStorage, url]);
        }
      });
    });
  };

  const handleCalendarValue = (newValue) => {
    setCalendarValue(newValue);
  };

  return (
    <>
      <FormProvider methods={methods} onSubmit={handleSubmit(onSubmit)}>
        <Grid container spacing={3}>
          <Grid item xs={12} md={8}>
            <Card sx={{ p: 3 }}>
              <LabelStyle> {i18n.t('dashboard.newEdition.volumeNumber')} </LabelStyle>
              <Stack spacing={3}>
                <Stack direction="row" spacing={1.5}>
                  <RHFTextField name="volume" label={i18n.t('editions.volume')} type="number" />
                  <RHFTextField name="number" label={i18n.t('editions.number')} type="number" />
                </Stack>
                <div>
                  <LabelStyle> {i18n.t('dashboard.newEdition.description')} </LabelStyle>
                  <RHFTextField
                    name="description"
                    label={i18n.t('dashboard.newEdition.writeDesc')}
                    inputProps={{ maxLength: 200 }}
                    multiline
                    rows={3}
                  />
                </div>
                <div>
                  <LabelStyle> {i18n.t('dashboard.newEdition.edition')} </LabelStyle>
                  <RHFUploadSingleFile sx={{ p: 2 }} name="pdf" accept="application/pdf" onDrop={handleDropPDF} />
                </div>
                <div>
                  <LabelStyle> {i18n.t('dashboard.newEdition.cover')} </LabelStyle>
                  <RHFUploadSingleFile sx={{ p: 2 }} name="cover" accept="image/*" onDrop={handleDropPicture} />
                </div>
              </Stack>
            </Card>
          </Grid>

          <Grid item xs={12} md={4}>
            <Card sx={{ p: 3 }}>
              <Stack spacing={3}>
                <div>
                  <LabelStyle> {i18n.t('dashboard.newEdition.publishDate')} </LabelStyle>
                  <LocalizationProvider dateAdapter={AdapterDateFns} locale={frLocale}>
                    <DesktopDatePicker
                      disablePast
                      name="publishDate"
                      inputFormat="dd/MM/yyyy"
                      disabled={values.publishNow}
                      value={calendarValue}
                      onChange={handleCalendarValue}
                      renderInput={(params) => <TextField {...params} />}
                    />
                  </LocalizationProvider>
                </div>
                <div>
                  <RHFSwitch
                    name="publishNow"
                    label={i18n.t('dashboard.newEdition.publishNow')}
                    labelPlacement="start"
                    sx={{ mb: 1, mx: 0, width: 1, justifyContent: 'space-between' }}
                  />
                </div>
                <div>
                  <RHFSwitch
                    name="kapote"
                    label={i18n.t('dashboard.newEdition.kapote')}
                    labelPlacement="start"
                    sx={{ mb: 1, mx: 0, width: 1, justifyContent: 'space-between' }}
                  />
                </div>
                <div>
                  {values.kapote && (
                    <>
                      <LabelStyle> {i18n.t('dashboard.newEdition.yearParution')} </LabelStyle>
                      <RHFTextField required name="parutionKapote" label="ex: (2020-2021)" type="text" />
                    </>
                  )}
                </div>
              </Stack>
            </Card>

            <Stack direction="row" spacing={1.5} sx={{ mt: 3 }}>
              <LoadingButton
                sx={{ textTransform: 'none' }}
                fullWidth
                type="submit"
                variant="contained"
                size="large"
                loading={isSubmitting}
              >
                {i18n.t('dashboard.newEdition.addEdition')}
              </LoadingButton>
            </Stack>
          </Grid>
        </Grid>
      </FormProvider>
    </>
  );
}
