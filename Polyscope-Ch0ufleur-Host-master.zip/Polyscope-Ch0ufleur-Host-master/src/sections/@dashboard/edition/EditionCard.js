import ReactGA from 'react-ga4';
import { useCallback, useState } from 'react';
import PropTypes from 'prop-types';
import { useSnackbar } from 'notistack';
// @mui
import { Box, Card, CardHeader, Stack } from '@mui/material';
// components
import Image from '../../../components/atoms/Image';
import ModalCard from '../../../components/molecules/card/ModalCard';
import i18n from '../../../locales/i18n';
import { ListMoreMenu } from '../user/list';
import { fTimestamp } from '../../../utils/formatTime';
import { OverlayStyle } from '../../../utils/GeneralStyle';
import TextIconLabel from '../../../components/atoms/TextIconLabel';
import Iconify from '../../../components/atoms/Iconify';
import { fShortenNumber } from '../../../utils/formatNumber';

// ----------------------------------------------------------------------

const IS_EDIT = false;

EditionCard.propTypes = {
  edition: PropTypes.object.isRequired,
  handleDeletePDF: PropTypes.any,
  viewCount: PropTypes.number,
  currentVolume: PropTypes.string,
};

export default function EditionCard({ edition, currentVolume, handleDeletePDF, viewCount }) {
  const { volume, number, cover, pdf, UID, kapote, parutionKapote, publishDate, eventID } = edition;
  const { enqueueSnackbar } = useSnackbar();

  const [showActions, setShowActions] = useState(false);
  const [openWarningDelete, setWarningDelete] = useState(false);

  const handleOpenPDF = () => {
    ReactGA.send({ hitType: 'pageview', page: `/edition/${UID}` });
    window.open(`${pdf}`);
  };
  const handleOpenWarning = () => setWarningDelete(true);
  const handleCloseWarning = () => setWarningDelete(false);

  const deleteEdition = () => {
    handleDeletePDF(UID, cover, pdf, kapote, volume.toString(), eventID);
    handleCloseWarning();
    enqueueSnackbar(i18n.t('form.deleteSuccess'));
  };

  const getTitle = () =>
    kapote
      ? currentVolume === 'Kapoté'
        ? `${i18n.t('editions.volume')} ${volume} ${i18n.t('editions.number')} ${number}* ${parutionKapote}`
        : `${i18n.t('editions.number')} ${number}*`
      : `${i18n.t('editions.number')} ${number}`;

  const getSubheader = useCallback(
    () => (
      <>
        {
          <Stack
            flexWrap="wrap"
            direction="row"
            justifyContent="center"
            sx={{
              mt: 0,
              color: 'text.disabled',
            }}
          >
            <TextIconLabel
              icon={<Iconify icon="eva:download-fill" sx={{ width: 16, height: 16, mr: 0.5 }} />}
              value={fShortenNumber(viewCount)}
              sx={{ typography: 'caption', ml: 4 }}
            />
          </Stack>
        }
      </>
    ),
    [viewCount]
  );

  return (
    <Card
      sx={{ textAlign: 'center' }}
      onMouseEnter={() => setShowActions(true)}
      onMouseLeave={() => setShowActions(false)}
    >
      <Box sx={{ position: 'relative' }}>
        {publishDate > fTimestamp(Date.now()) ? <OverlayStyle /> : null}
        <Image src={cover} ratio="3/4" />
      </Box>

      <CardHeader
        style={{ padding: '10px' }}
        action={
          <ListMoreMenu onDelete={() => handleOpenWarning()} editPath={''} isEdit={IS_EDIT} openPDF={handleOpenPDF} />
        }
        title={getTitle()}
        subheader={getSubheader()}
      />
      {showActions && (
        <ModalCard
          isOpen={openWarningDelete}
          handleClose={handleCloseWarning}
          UID={edition.UID}
          deleteElement={deleteEdition}
        />
      )}
    </Card>
  );
}
