import i18n from '../../../../../locales/i18n';

export const DATA_RANGE = {
  week: i18n.t('dashboard.charts.action.ranges.week'),
  month: i18n.t('dashboard.charts.action.ranges.month'),
  year: i18n.t('dashboard.charts.action.ranges.year'),
  all: i18n.t('dashboard.charts.action.ranges.all'),
};
