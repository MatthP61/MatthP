import { Card, CardHeader, LinearProgress, TextField } from '@mui/material';
import { Box } from '@mui/system';
import { useCallback, useContext, useEffect, useState } from 'react';
import ReactApexChart from 'react-apexcharts';
import i18n from '../../../../locales/i18n';
import { BaseOptionChart } from '../../../../components/organismes/chart';
import { DashboardAnalyticsContext } from '../../../../contexts/DashboardAnalyticsContext';
import { DATA_RANGE } from './constants/DataRange';

export default function AppSiteVisits() {
  const { getSiteVisits, allVisitsChartData } = useContext(DashboardAnalyticsContext);

  const [isLoading, setIsLoading] = useState(true);
  const [range, setRange] = useState('month');

  useEffect(() => {
    setChartOptions({
      ...chartOptions,
      xaxis: { categories: allVisitsChartData.categories },
      noData: { text: i18n.t('dashboard.charts.noData') },
    });
  }, [allVisitsChartData]);

  useEffect(() => {
    getSiteVisits(range).then(() => {
      setIsLoading(false);
    });

    // getSiteVisits is memoized, so it needs to be included in the list of dependencies
  }, [getSiteVisits, range]);

  const [chartOptions, setChartOptions] = useState(BaseOptionChart());

  const handleChangeSeriesData = (event) => {
    setIsLoading(true);
    setRange(event.target.value);
  };

  const getChartData = useCallback(
    () => (
      <>
        {isLoading ? (
          <LinearProgress />
        ) : (
          <Box sx={{ mt: 3, mx: 3 }} dir="ltr">
            <ReactApexChart type="line" series={allVisitsChartData.series} options={chartOptions} height={364} />
          </Box>
        )}
      </>
    ),
    [allVisitsChartData, chartOptions, isLoading]
  );

  return (
    <Card>
      <CardHeader
        title={i18n.t('dashboard.charts.visits.title')}
        action={
          <TextField
            select
            value={range}
            SelectProps={{ native: true }}
            onChange={handleChangeSeriesData}
            sx={{
              '& fieldset': { border: '0 !important' },
              '& select': {
                pl: 1,
                py: 0.5,
                pr: '24px !important',
                typography: 'subtitle2',
              },
              '& .MuiOutlinedInput-root': {
                borderRadius: 0.75,
                bgcolor: 'background.neutral',
              },
              '& .MuiNativeSelect-icon': {
                top: 4,
                right: 0,
                width: 20,
                height: 20,
              },
            }}
          >
            {Object.entries(DATA_RANGE)
              .filter(([key]) => key !== 'all')
              .map(([key, val]) => (
                <option key={key} value={key}>
                  {val}
                </option>
              ))}
          </TextField>
        }
      />
      {getChartData()}
    </Card>
  );
}
