import merge from 'lodash/merge';
import ReactApexChart from 'react-apexcharts';
// @mui
import { styled } from '@mui/material/styles';
import { Card, CardHeader, LinearProgress, TextField } from '@mui/material';
// utils
import { useCallback, useContext, useEffect, useState } from 'react';
import { DashboardAnalyticsContext } from '../../../../contexts/DashboardAnalyticsContext';
import { fNumber } from '../../../../utils/formatNumber';
//
import { BaseOptionChart } from '../../../../components/organismes/chart';
import { DATA_RANGE } from './constants/DataRange';
import i18n from '../../../../locales/i18n';

// ----------------------------------------------------------------------

const CHART_HEIGHT = 392;
const LEGEND_HEIGHT = 72;

const ChartWrapperStyle = styled('div')(({ theme }) => ({
  height: CHART_HEIGHT,
  marginTop: theme.spacing(5),
  '& .apexcharts-canvas svg': { height: CHART_HEIGHT },
  '& .apexcharts-canvas svg,.apexcharts-canvas foreignObject': {
    overflow: 'visible',
  },
  '& .apexcharts-legend': {
    height: LEGEND_HEIGHT,
    alignContent: 'center',
    position: 'relative !important',
    borderTop: `solid 1px ${theme.palette.divider}`,
    top: `calc(${CHART_HEIGHT - LEGEND_HEIGHT}px) !important`,
  },
}));

// ----------------------------------------------------------------------

export default function AppUserPlatforms() {
  const { getUserPlatforms, userPlatformChartData } = useContext(DashboardAnalyticsContext);

  const [isLoading, setIsLoading] = useState(true);
  const [range, setRange] = useState('all');

  const [chartOptions, setChartOptions] = useState(
    merge(BaseOptionChart(), {
      legend: { floating: true, horizontalAlign: 'center' },
      tooltip: {
        fillSeriesColor: false,
        y: {
          formatter: (seriesName) => fNumber(seriesName),
          title: {
            formatter: (seriesName) => `${seriesName}`,
          },
        },
      },
      plotOptions: {
        pie: {
          donut: {
            size: '90%',
            labels: {
              value: {
                formatter: (val) => fNumber(val),
              },
              total: {
                formatter: (w) => {
                  const sum = w.globals.seriesTotals.reduce((a, b) => a + b, 0);
                  return fNumber(sum);
                },
              },
            },
          },
        },
      },
    })
  );

  useEffect(() => {
    getUserPlatforms(range).then(() => {
      setIsLoading(false);
    });
  }, [getUserPlatforms, range]);

  useEffect(() => {
    setChartOptions({
      ...chartOptions,
      labels: userPlatformChartData.categories,
    });
  }, [userPlatformChartData]);

  const handleChangeSeriesData = (event) => {
    setIsLoading(true);
    setRange(event.target.value);
  };

  const getChartData = useCallback(
    () => (
      <>
        {isLoading ? (
          <LinearProgress />
        ) : (
          <ChartWrapperStyle dir="ltr">
            <ReactApexChart type="donut" series={userPlatformChartData.data} options={chartOptions} height={280} />
          </ChartWrapperStyle>
        )}
      </>
    ),
    [userPlatformChartData, chartOptions, isLoading]
  );

  return (
    <Card>
      <CardHeader
        title={i18n.t('dashboard.charts.platform.title')}
        action={
          <TextField
            select
            value={range}
            SelectProps={{ native: true }}
            onChange={handleChangeSeriesData}
            sx={{
              '& fieldset': { border: '0 !important' },
              '& select': {
                pl: 1,
                py: 0.5,
                pr: '24px !important',
                typography: 'subtitle2',
              },
              '& .MuiOutlinedInput-root': {
                borderRadius: 0.75,
                bgcolor: 'background.neutral',
              },
              '& .MuiNativeSelect-icon': {
                top: 4,
                right: 0,
                width: 20,
                height: 20,
              },
            }}
          >
            {Object.entries(DATA_RANGE).map(([key, val]) => (
              <option key={key} value={key}>
                {val}
              </option>
            ))}
          </TextField>
        }
      />
      {getChartData()}
    </Card>
  );
}
