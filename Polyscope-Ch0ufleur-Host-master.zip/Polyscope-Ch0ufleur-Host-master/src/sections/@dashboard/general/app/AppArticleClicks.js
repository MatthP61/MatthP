import { useCallback, useContext, useEffect, useMemo, useState } from 'react';
// @mui
import {
  Card,
  CardHeader,
  LinearProgress,
  TableContainer,
  Table,
  TableCell,
  TableHead,
  TableRow,
  TableBody,
  Typography,
  Link,
  Avatar,
  useTheme,
} from '@mui/material';
// components
import { Link as RouterLink } from 'react-router-dom';
import { DashboardAnalyticsContext } from '../../../../contexts/DashboardAnalyticsContext';
import DateHelper from '../../../../utils/DateHelper';
import Label from '../../../../components/atoms/Label';
import { PATH_DASHBOARD } from '../../../../routes/paths';
import i18n from '../../../../locales/i18n';

// ----------------------------------------------------------------------

const blogDataMap = {
  rank: i18n.t('dashboard.tables.views.columns.rank'),
  title: i18n.t('dashboard.tables.views.columns.title'),
  createdAt: i18n.t('dashboard.tables.views.columns.createdAt'),
  categories: i18n.t('dashboard.tables.views.columns.categories'),
  views: i18n.t('dashboard.tables.views.columns.views'),
};

export default function AppArticleClicks() {
  const theme = useTheme();
  const { getBlogViews, allViewsTableData } = useContext(DashboardAnalyticsContext);

  const sortedTableDataArray = useMemo(
    // eslint-disable-next-line no-unused-vars
    () => Object.entries(allViewsTableData).sort(([UID1, data1], [UID2, data2]) => data2.views - data1.views),
    [allViewsTableData]
  );

  const [isLoading, setIsLoading] = useState(true);

  const tableRowStyle = useMemo(() => {
    const color = theme.palette.subtleDivider;

    return {
      '&>td': { borderBottom: `1px solid ${color}` },
    };
  }, [theme]);

  useEffect(() => {
    getBlogViews().then(() => {
      setIsLoading(false);
    });
  }, [getBlogViews]);

  const getColumnNames = useCallback(
    () =>
      Object.values(blogDataMap).map((columnTitle) => (
        <TableCell sx={{ whiteSpace: 'nowrap' }} key={columnTitle}>
          {' '}
          {columnTitle}{' '}
        </TableCell>
      )),
    []
  );

  const getTableRows = useCallback(
    () => (
      <>
        {sortedTableDataArray.map(([UID, data], index) => (
          <TableRow key={UID} hover sx={tableRowStyle}>
            <TableCell align="left">
              <Typography variant="body2" color="text.disabled">
                {index + 1}
              </Typography>
            </TableCell>

            <TableCell sx={{ display: 'flex', alignItems: 'center' }}>
              <Avatar variant="rounded" src="asd" alt={data.title} sx={{ mr: 2 }} />
              <Link color="text.disabled" to={`${PATH_DASHBOARD.blog.root}/post/${UID}`} component={RouterLink}>
                <Typography variant="subtitle2">{data.title}</Typography>
              </Link>
            </TableCell>

            <TableCell align="left">{DateHelper.formatLocale(data.createdAt, 'PP')}</TableCell>

            <TableCell align="left">{data.category && <Label>{data.category}</Label>}</TableCell>

            <TableCell align="right">{data.views}</TableCell>
          </TableRow>
        ))}
      </>
    ),
    [sortedTableDataArray, tableRowStyle]
  );

  const getTable = useCallback(
    () => (
      <>
        {isLoading ? (
          <LinearProgress />
        ) : (
          <TableContainer sx={{ maxHeight: 440 }}>
            <Table stickyHeader>
              <TableHead>
                <TableRow>{getColumnNames()}</TableRow>
              </TableHead>

              <TableBody>{getTableRows()}</TableBody>
            </Table>
          </TableContainer>
        )}
      </>
    ),
    [getColumnNames, getTableRows, isLoading]
  );

  return (
    <Card>
      <CardHeader title={i18n.t('dashboard.tables.views.title')} />
      {getTable()}
    </Card>
  );
}
