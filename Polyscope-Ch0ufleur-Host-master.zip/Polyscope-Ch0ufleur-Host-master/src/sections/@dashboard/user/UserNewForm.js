import PropTypes from 'prop-types';
import * as Yup from 'yup';
import { useCallback, useContext, useEffect, useMemo } from 'react';
import { useSnackbar } from 'notistack';
import { useNavigate } from 'react-router-dom';
// form
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
// @mui
import { LoadingButton } from '@mui/lab';
import { Box, Card, Grid, Stack, Typography } from '@mui/material';
// utils
import { getStorage, ref, uploadBytes, getDownloadURL } from 'firebase/storage';
// routes
import { PATH_DASHBOARD } from '../../../routes/paths';
// components
import Label from '../../../components/atoms/Label';
import { FormProvider, RHFSwitch, RHFTextField, RHFUploadAvatar } from '../../../components/organismes/hook-form';
import i18n from '../../../locales/i18n';
import { UserContext } from '../../../contexts/UserContext';
import { fData } from '../../../utils/formatNumber';
import * as SOCIAL_REGEX from '../../../utils/regexSocialMedia';
import { LabelStyle } from '../../../utils/GeneralStyle';

// ----------------------------------------------------------------------

UserNewForm.propTypes = {
  isEdit: PropTypes.bool,
  currentUser: PropTypes.object,
};

export default function UserNewForm({ isEdit, currentUser: currentUsera }) {
  const navigate = useNavigate();
  const { addUser, editUser } = useContext(UserContext);
  const { enqueueSnackbar } = useSnackbar();

  const defaultValues = useMemo(
    () => ({
      UID: currentUsera?.UID || '',
      name: currentUsera?.name || '',
      displayName: currentUsera?.displayName || '',
      email: currentUsera?.email || '',
      phoneNumber: currentUsera?.phoneNumber || '',
      photoURL: currentUsera?.photoURL || '',
      isActif: currentUsera?.isActif || false,
      isAdmin: currentUsera?.isAdmin || false,
      facebook: currentUsera?.facebook || '',
      instagram: currentUsera?.instagram || '',
      linkedin: currentUsera?.linkedin || '',
      twitter: currentUsera?.twitter || '',
    }),
    [currentUsera]
  );

  const NewUserSchema = Yup.object().shape({
    name: Yup.string().required('Le nom est obligatoire'),
    displayName: Yup.string().required("Le nom d'affichage est obligatoire"),
    email: Yup.string().required('Le courriel est obligatoire').email(),
    phoneNumber: Yup.string(),
    facebook: Yup.lazy((value) =>
      !value ? Yup.string() : Yup.string().matches(SOCIAL_REGEX.FACEBOOK, 'Mettre un lien valide')
    ),
    instagram: Yup.lazy((value) =>
      !value ? Yup.string() : Yup.string().matches(SOCIAL_REGEX.INSTAGRAM, 'Mettre un lien valide')
    ),
    linkedin: Yup.lazy((value) =>
      !value ? Yup.string() : Yup.string().matches(SOCIAL_REGEX.LINKEDIN, 'Mettre un lien valide')
    ),
    twitter: Yup.lazy((value) =>
      !value ? Yup.string() : Yup.string().matches(SOCIAL_REGEX.TWITTER, 'Mettre un lien valide')
    ),
  });

  const methods = useForm({
    resolver: yupResolver(NewUserSchema),
    defaultValues,
  });

  const {
    reset,
    watch,
    getValues,
    setValue,
    handleSubmit,
    formState: { isSubmitting },
  } = methods;

  const values = watch();

  useEffect(() => {
    if (!values?.isActif && values?.isAdmin) {
      enqueueSnackbar(i18n.t('dashboard.users.bannedAdmin'), { variant: 'error' });
    }
    if (!values?.isActif) {
      setValue('isAdmin', false);
    }
  }, [values?.isActif, values?.isAdmin]);

  useEffect(() => {
    if (isEdit) {
      reset(currentUsera);
    } else {
      reset(defaultValues);
    }
  }, [isEdit, currentUsera, defaultValues]);

  const onSubmit = async () => {
    try {
      await new Promise((resolve) => setTimeout(resolve, 500));
      if (isEdit) {
        editUser(values);
      } else {
        addUser(values);
      }
      reset();
      enqueueSnackbar(!isEdit ? i18n.t('form.createSuccess') : i18n.t('form.updateSuccess'));
      navigate(PATH_DASHBOARD.user.list);
    } catch (error) {
      console.error(error);
    }
  };

  const handleDrop = useCallback(
    (acceptedFiles) => {
      const file = acceptedFiles[0];

      if (file === '') {
        console.error(`not an image, the image file is a ${typeof file}`);
      }

      const storage = getStorage();
      const storageRef = ref(storage, `/user-image/${getValues('UID')}`);
      uploadBytes(storageRef, file).then(() => {
        getDownloadURL(storageRef).then((url) => {
          setValue('photoURL', url);
        });
      });
    },
    [setValue]
  );

  return (
    <FormProvider methods={methods} onSubmit={handleSubmit(onSubmit)}>
      <Grid container spacing={3}>
        <Grid item xs={12} md={4}>
          <Card sx={{ py: 10, px: 3 }}>
            {isEdit && (
              <Label
                color={values.isActif !== true ? 'error' : 'success'}
                sx={{ textTransform: 'uppercase', position: 'absolute', top: 24, right: 24 }}
              >
                {values.isActif ? i18n.t('user.active') : i18n.t('user.banned')}
              </Label>
            )}

            <Box sx={{ mb: 5 }}>
              <RHFUploadAvatar
                required
                name="photoURL"
                accept="image/*"
                maxSize={3145728}
                onDrop={handleDrop}
                helperText={
                  <Typography
                    variant="caption"
                    sx={{
                      mt: 2,
                      mx: 'auto',
                      display: 'block',
                      textAlign: 'center',
                      color: 'text.secondary',
                    }}
                  >
                    {i18n.t('userAccount.accept')}
                    <br /> {i18n.t('userAccount.maxSize')} {fData(3145728)}
                  </Typography>
                }
              />
            </Box>

            {isEdit && (
              <RHFSwitch
                name="isActif"
                label="Actif(ve)"
                labelPlacement="start"
                sx={{ mb: 1, mx: 0, width: 1, justifyContent: 'space-between' }}
              />
            )}
          </Card>
        </Grid>

        <Grid item xs={12} md={8}>
          <Card sx={{ p: 3 }}>
            <Stack spacing={3}>
              <LabelStyle>{i18n.t('dashboard.users.infoGeneral')}</LabelStyle>
              <Box
                sx={{
                  display: 'grid',
                  columnGap: 2,
                  rowGap: 3,
                  gridTemplateColumns: { xs: 'repeat(1, 1fr)', sm: 'repeat(2, 1fr)' },
                }}
              >
                <RHFTextField disabled required name="name" label={i18n.t('user.name')} />
                <RHFTextField disabled required name="displayName" label={i18n.t('user.displayName')} />
                <RHFTextField disabled required name="email" label={i18n.t('user.email')} />
                <RHFTextField disabled name="phoneNumber" label={i18n.t('user.phoneNumber')} />
              </Box>
              <Box
                sx={{
                  display: 'grid',
                  columnGap: 2,
                  rowGap: 3,
                  gridTemplateColumns: { xs: 'repeat(1, 1fr)', sm: 'repeat(2, 1fr)' },
                }}
              >
                <RHFSwitch
                  name="isAdmin"
                  label={i18n.t('user.isAdmin')}
                  labelPlacement="start"
                  sx={{ mb: 1, mx: 0, width: 1, justifyContent: 'space-between' }}
                />
              </Box>
              <LabelStyle>{i18n.t('user.socialLinks')}</LabelStyle>
              <Box
                sx={{
                  display: 'grid',
                  columnGap: 2,
                  rowGap: 3,
                  gridTemplateColumns: { xs: 'repeat(1, 1fr)', sm: 'repeat(2, 1fr)' },
                }}
              >
                <RHFTextField name="facebook" label={i18n.t('user.fb')} />
                <RHFTextField name="instagram" label={i18n.t('user.insta')} />
                <RHFTextField name="linkedin" label={i18n.t('user.linkedin')} />
                <RHFTextField name="twitter" label={i18n.t('user.twitter')} />
              </Box>
            </Stack>

            <Stack alignItems="flex-end" sx={{ mt: 3 }}>
              <LoadingButton type="submit" variant="contained" loading={isSubmitting}>
                {!isEdit ? i18n.t('form.create') : i18n.t('form.save')}
              </LoadingButton>
            </Stack>
          </Card>
        </Grid>
      </Grid>
    </FormProvider>
  );
}
