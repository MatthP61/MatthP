/* eslint-disable no-dupe-keys */
import * as Yup from 'yup';
import { useSnackbar } from 'notistack';
import { useCallback } from 'react';
// form
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
// @mui
import { Box, Grid, Card, Stack, Typography } from '@mui/material';
import { LoadingButton } from '@mui/lab';
// hooks
import { getStorage, ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import useAuth from '../../../../hooks/useAuth';
// utils
import { fData } from '../../../../utils/formatNumber';
// components
import { FormProvider, RHFTextField, RHFUploadAvatar } from '../../../../components/organismes/hook-form';
import i18n from '../../../../locales/i18n';
// ----------------------------------------------------------------------
const phoneRegExp =
  /^((\\+[1-9]{1,4}[ \\-]*)|(\\([0-9]{2,3}\\)[ \\-]*)|([0-9]{2,4})[ \\-]*)*?[0-9]{3,4}?[ \\-]*[0-9]{3,4}?$/;

export default function AccountGeneral() {
  const { enqueueSnackbar } = useSnackbar();

  const { user, updateUser } = useAuth();

  const UpdateUserSchema = Yup.object().shape({
    name: Yup.string().required(`${i18n.t('user.name')} ${i18n.t('form.isrequiredM')}`),
    displayName: Yup.string().required(`${i18n.t('user.displayName')} ${i18n.t('form.isrequiredM')}`),
    email: Yup.string().required(`${i18n.t('user.email')} ${i18n.t('form.isrequiredM')}`),
    phoneNumber: Yup.string()
      .required(i18n.t('register.phoneNumberreq'))
      .matches(phoneRegExp, i18n.t('register.phoneNumberValid'))
      .min(10, i18n.t('register.phoneNumberValid')),
    about: Yup.string().max(1500, i18n.t('form.aboutForm')),
  });

  const defaultValues = {
    name: user?.name || '',
    displayName: user?.displayName || '',
    email: user?.email || '',
    phoneNumber: user?.phoneNumber || '',
    photoURL: user?.photoURL || '',
    about: user?.about || '',
  };

  const methods = useForm({
    resolver: yupResolver(UpdateUserSchema),
    defaultValues,
  });

  const {
    setValue,
    watch,
    reset,
    handleSubmit,
    formState: { isSubmitting, isDirty },
  } = methods;
  const values = watch();

  const onSubmit = async () => {
    try {
      updateUser(values, false).then((error) => {
        switch (error) {
          case 'error':
            enqueueSnackbar(i18n.t('form.error'), { variant: 'error' });
            reset(defaultValues);
            break;
          case 'log':
            enqueueSnackbar(i18n.t('form.loginReq'), { variant: 'error' });
            reset(defaultValues);
            break;
          default:
            enqueueSnackbar(i18n.t('form.updateSuccess'));
            break;
        }
      });
    } catch (error) {
      console.error(error);
    }
  };

  const handleDrop = useCallback(
    (acceptedFiles) => {
      const file = acceptedFiles[0];

      if (file) {
        const storage = getStorage();
        const storageRef = ref(storage, `/user-image/${user.UID}`);
        uploadBytes(storageRef, file).then(() => {
          getDownloadURL(storageRef).then((url) => {
            // Insert url into an <img> tag to "download"
            setValue('photoURL', url);
          });
        });
      }
    },
    [setValue]
  );

  return (
    <FormProvider methods={methods} onSubmit={handleSubmit(onSubmit)}>
      <Grid container spacing={3}>
        <Grid item xs={12} md={4}>
          <Card sx={{ py: 10, px: 3, textAlign: 'center' }}>
            <RHFUploadAvatar
              name="photoURL"
              accept="image/*"
              maxSize={3145728}
              onDrop={handleDrop}
              helperText={
                <Typography
                  variant="caption"
                  sx={{
                    mt: 2,
                    mx: 'auto',
                    display: 'block',
                    textAlign: 'center',
                    color: 'text.secondary',
                  }}
                >
                  {i18n.t('userAccount.accept')}
                  <br /> {i18n.t('userAccount.maxSize')} {fData(3145728)}
                </Typography>
              }
            />
          </Card>
        </Grid>

        <Grid item xs={12} md={8}>
          <Card sx={{ p: 3 }}>
            <Box
              sx={{
                display: 'grid',
                rowGap: 3,
                columnGap: 2,
                gridTemplateColumns: { xs: 'repeat(1, 1fr)', sm: 'repeat(2, 1fr)' },
              }}
            >
              <RHFTextField disabled name="name" label={i18n.t('journalist.name')} />
              <RHFTextField disabled name="displayName" label={i18n.t('journalist.displayName')} />
              <RHFTextField name="email" label={i18n.t('journalist.email')} />
              <RHFTextField name="phoneNumber" label={i18n.t('journalist.phoneNumber')} />
            </Box>

            <Stack spacing={3} alignItems="flex-end" sx={{ mt: 3 }}>
              <RHFTextField name="about" multiline rows={4} label={i18n.t('dashboard.settings.about')} />
              <LoadingButton disabled={!isDirty} type="submit" variant="contained" loading={isSubmitting}>
                {i18n.t('form.save')}
              </LoadingButton>
            </Stack>
          </Card>
        </Grid>
      </Grid>
    </FormProvider>
  );
}
