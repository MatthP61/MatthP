import * as Yup from 'yup';
import { useSnackbar } from 'notistack';

// form
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';

// @mui
import { Stack, Card, InputAdornment } from '@mui/material';
import { LoadingButton } from '@mui/lab';
// components
import Iconify from '../../../../components/atoms/Iconify';
import { FormProvider, RHFTextField } from '../../../../components/organismes/hook-form';
import i18n from '../../../../locales/i18n';
import useAuth from '../../../../hooks/useAuth';
import * as SOCIAL_REGEX from '../../../../utils/regexSocialMedia';

// ----------------------------------------------------------------------

const SOCIAL_LINKS = [
  {
    value: 'facebook',
    icon: <Iconify icon={'eva:facebook-fill'} width={24} height={24} />,
  },
  {
    value: 'instagram',
    icon: <Iconify icon={'ant-design:instagram-filled'} width={24} height={24} />,
  },
  {
    value: 'linkedin',
    icon: <Iconify icon={'eva:linkedin-fill'} width={24} height={24} />,
  },
  {
    value: 'twitter',
    icon: <Iconify icon={'eva:twitter-fill'} width={24} height={24} />,
  },
];

// ----------------------------------------------------------------------

export default function AccountSocialLinks() {
  const { enqueueSnackbar } = useSnackbar();
  const { user, updateUser } = useAuth();

  const UpdateSocialLinksSchema = Yup.object().shape({
    facebook: Yup.lazy((value) =>
      !value ? Yup.string() : Yup.string().matches(SOCIAL_REGEX.FACEBOOK, 'Mettre un lien valide')
    ),
    instagram: Yup.lazy((value) =>
      !value ? Yup.string() : Yup.string().matches(SOCIAL_REGEX.INSTAGRAM, 'Mettre un lien valide')
    ),
    linkedin: Yup.lazy((value) =>
      !value ? Yup.string() : Yup.string().matches(SOCIAL_REGEX.LINKEDIN, 'Mettre un lien valide')
    ),
    twitter: Yup.lazy((value) =>
      !value ? Yup.string() : Yup.string().matches(SOCIAL_REGEX.TWITTER, 'Mettre un lien valide')
    ),
  });

  const defaultValues = {
    facebook: user?.facebook || '',
    instagram: user?.instagram || '',
    linkedin: user?.linkedin || '',
    twitter: user?.twitter || '',
  };

  const methods = useForm({
    resolver: yupResolver(UpdateSocialLinksSchema),
    defaultValues,
  });

  const {
    watch,
    handleSubmit,
    formState: { isSubmitting, isDirty },
  } = methods;
  const values = watch();

  const onSubmit = async () => {
    try {
      // await new Promise((resolve) => setTimeout(resolve, 500));
      await updateUser(values, true).then((error) => {
        if (error === 'error') {
          enqueueSnackbar(i18n.t('form.error'), { variant: 'error' });
        } else {
          enqueueSnackbar(i18n.t('form.updateSuccess'));
        }
      });
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <Card sx={{ p: 3 }}>
      <FormProvider methods={methods} onSubmit={handleSubmit(onSubmit)}>
        <Stack spacing={3} alignItems="flex-end">
          {SOCIAL_LINKS.map((link) => (
            <RHFTextField
              key={link.value}
              name={link.value}
              InputProps={{
                startAdornment: <InputAdornment position="start">{link.icon}</InputAdornment>,
              }}
            />
          ))}

          <LoadingButton disabled={!isDirty} type="submit" variant="contained" loading={isSubmitting}>
            {i18n.t('form.save')}
          </LoadingButton>
        </Stack>
      </FormProvider>
    </Card>
  );
}
