import * as Yup from 'yup';
import { useSnackbar } from 'notistack';
// form
import { yupResolver } from '@hookform/resolvers/yup';
import { useForm } from 'react-hook-form';
// @mui
import { Stack, Card } from '@mui/material';
import { LoadingButton } from '@mui/lab';
// components
import { FormProvider, RHFTextField } from '../../../../components/organismes/hook-form';
import i18n from '../../../../locales/i18n';
import useAuth from '../../../../hooks/useAuth';
// ----------------------------------------------------------------------

export default function AccountChangePassword() {
  const { enqueueSnackbar } = useSnackbar();
  const { changePassword } = useAuth();

  const ChangePassWordSchema = Yup.object().shape({
    newPassword: Yup.string()
      .min(6, i18n.t('form.minCharac'))
      .required(`${i18n.t('userAccount.newPw')} ${i18n.t('form.isrequiredM')}`),
    confirmNewPassword: Yup.string().oneOf([Yup.ref('newPassword'), null], i18n.t('form.pwMatch')),
  });

  const defaultValues = {
    newPassword: '',
    confirmNewPassword: '',
  };

  const methods = useForm({
    resolver: yupResolver(ChangePassWordSchema),
    defaultValues,
  });

  const {
    reset,
    watch,
    handleSubmit,
    formState: { isSubmitting, isDirty },
  } = methods;

  const values = watch();

  const onSubmit = async () => {
    try {
      await changePassword(values.newPassword).then((error) => {
        if (error === 'error') {
          enqueueSnackbar(i18n.t('form.error'), { variant: 'error' });
        } else {
          enqueueSnackbar(i18n.t('form.updateSuccess'));
        }
      });
      reset();
    } catch (error) {
      enqueueSnackbar(i18n.t('form.error'));
      console.error(error);
    }
  };

  return (
    <Card sx={{ p: 3 }}>
      <FormProvider methods={methods} onSubmit={handleSubmit(onSubmit)}>
        <Stack spacing={3} alignItems="flex-end">
          <RHFTextField name="newPassword" type="password" label={i18n.t('userAccount.newPw')} />

          <RHFTextField name="confirmNewPassword" type="password" label={i18n.t('userAccount.confirmPw')} />

          <LoadingButton disabled={!isDirty} type="submit" variant="contained" loading={isSubmitting}>
            {i18n.t('form.save')}
          </LoadingButton>
        </Stack>
      </FormProvider>
    </Card>
  );
}
