import PropTypes from 'prop-types';
import { useState } from 'react';
import { Link as RouterLink } from 'react-router-dom';

// @mui
import { MenuItem, IconButton } from '@mui/material';

// components
import Iconify from '../../../../components/atoms/Iconify';
import MenuPopover from '../../../../components/atoms/MenuPopover';
import i18n from '../../../../locales/i18n';

// ----------------------------------------------------------------------

ListMoreMenu.propTypes = {
  onDelete: PropTypes.func,
  editPath: PropTypes.string,
  isEdit: PropTypes.bool,
  openPDF: PropTypes.func,
};

export default function ListMoreMenu({ onDelete, editPath, isEdit, openPDF }) {
  const [open, setOpen] = useState(null);

  const handleOpen = (event) => {
    setOpen(event.currentTarget);
  };

  const handleClose = () => {
    setOpen(null);
  };

  const ICON = {
    mr: 2,
    width: 20,
    height: 20,
  };

  return (
    <>
      <IconButton onClick={handleOpen} sx={{ bgcolor: 'white' }}>
        <Iconify icon={'eva:more-vertical-fill'} width={20} height={20} />
      </IconButton>

      <MenuPopover
        open={Boolean(open)}
        anchorEl={open}
        onClose={handleClose}
        anchorOrigin={{ vertical: 'top', horizontal: 'left' }}
        transformOrigin={{ vertical: 'top', horizontal: 'right' }}
        arrow="right-top"
        sx={{
          mt: -1,
          width: 160,
          '& .MuiMenuItem-root': { px: 1, typography: 'body2', borderRadius: 0.75 },
        }}
      >
        <MenuItem onClick={onDelete} sx={{ color: 'error.main' }}>
          <Iconify icon={'eva:trash-2-outline'} sx={{ ...ICON }} />
          {i18n.t('form.delete')}
        </MenuItem>

        {isEdit ? (
          <MenuItem component={RouterLink} to={editPath}>
            <Iconify icon={'eva:edit-fill'} sx={{ ...ICON }} />
            {i18n.t('form.edit')}
          </MenuItem>
        ) : (
          <MenuItem onClick={openPDF}>
            <Iconify icon={'eva:book-open-outline'} sx={{ ...ICON }} />
            {i18n.t('form.read')}
          </MenuItem>
        )}
      </MenuPopover>
    </>
  );
}
