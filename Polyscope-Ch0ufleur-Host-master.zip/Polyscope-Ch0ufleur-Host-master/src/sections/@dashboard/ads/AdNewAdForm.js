/* eslint-disable no-useless-escape */
import React, { useCallback, useContext, useMemo, useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import { useForm } from 'react-hook-form';
import { useSnackbar } from 'notistack';

// form
import * as Yup from 'yup';
import { useNavigate } from 'react-router-dom';
import { yupResolver } from '@hookform/resolvers/yup';

// @mui
import { LoadingButton } from '@mui/lab';
import { Grid, Card, Stack } from '@mui/material';

// routes
import { getStorage, ref, uploadBytes, getDownloadURL, getMetadata } from 'firebase/storage';
import { PATH_DASHBOARD } from '../../../routes/paths';

// components
import { RHFSwitch, FormProvider, RHFTextField, RHFUploadSingleFile } from '../../../components/organismes/hook-form';
import { AdContext } from '../../../contexts/AdContext';
import { deletePreviousDrop } from '../../../components/atoms/FirebaseFunctions';
import i18n from '../../../locales/i18n';
import { LabelStyle } from '../../../utils/GeneralStyle';

// ----------------------------------------------------------------------

const URL =
  /^((https?|ftp):\/\/)?(www.)?(((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:)*@)?(((\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5]))|((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?)(:\d*)?)(\/((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)+(\/(([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)*)*)?)?(\?((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|[\uE000-\uF8FF]|\/|\?)*)?(\#((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|\/|\?)*)?$/;

AdNewAdForm.propTypes = {
  isEdit: PropTypes.bool,
  currentAd: PropTypes.object,
};

export default function AdNewAdForm({ isEdit, currentAd }) {
  const navigate = useNavigate();
  const { uploadAd, editAd } = useContext(AdContext);
  const { enqueueSnackbar } = useSnackbar();
  const [coverStorage, setCoverStorage] = useState([]);

  const defaultValues = useMemo(
    () => ({
      UID: currentAd?.UID || '',
      title: currentAd?.title || '',
      description: currentAd?.description || '',
      cover: currentAd?.cover || '',
      publish: currentAd?.publish || false,
      link: currentAd?.link || '',
    }),
    [currentAd]
  );

  const NewAdSchema = Yup.object().shape({
    title: Yup.string().required(i18n.t('dashboard.ad.titleRequired')),
    description: Yup.string().required(i18n.t('dashboard.ad.desReq')),
    cover: Yup.mixed().test('required', i18n.t('form.imageRequired'), (value) => value !== ''),
    link: Yup.string().matches(URL, i18n.t('form.linkValid')).required(i18n.t('dashboard.ad.linkReq')),
  });

  const methods = useForm({
    resolver: yupResolver(NewAdSchema),
    defaultValues,
  });

  const {
    watch,
    reset,
    setValue,
    handleSubmit,
    formState: { isSubmitting },
  } = methods;

  const values = watch();

  useEffect(() => {
    reset(defaultValues);
    setCoverStorage((coverStorage) => [...coverStorage, defaultValues.cover]);
  }, [isEdit, currentAd]);

  const onSubmit = async () => {
    try {
      deletePreviousDrop(coverStorage);
      if (isEdit) {
        editAd(values);
      } else {
        uploadAd(values);
      }
      reset();
      enqueueSnackbar(!isEdit ? i18n.t('form.createSuccess') : i18n.t('form.updateSuccess'));
      navigate(PATH_DASHBOARD.ads.list);
    } catch (error) {
      console.error(error);
    }
  };

  const handleDrop = useCallback(
    (acceptedFiles) => {
      const file = acceptedFiles[0];

      if (file === '') {
        console.error(`not an image, the image file is a ${typeof file}`);
      }

      const storage = getStorage();
      const storageRef = ref(storage, `/ad-image/${file.name}`);

      getMetadata(storageRef)
        .then(() => {
          const tmp = Math.random();
          const storageRef = ref(storage, `/ad-image/${file.name}${tmp}`);
          uploadImage(storageRef, 'cover', file);
        })
        .catch(() => {
          uploadImage(storageRef, 'cover', file);
        });
    },
    [setValue]
  );

  const uploadImage = (storageRef, field, file) => {
    uploadBytes(storageRef, file).then(() => {
      getDownloadURL(storageRef).then((url) => {
        setValue(field, url);
        setCoverStorage((coverStorage) => [...coverStorage, url]);
      });
    });
  };

  return (
    <>
      <FormProvider methods={methods} onSubmit={handleSubmit(onSubmit)}>
        <Grid container spacing={3}>
          <Grid item xs={12} md={8}>
            <Card sx={{ p: 3 }}>
              <Stack spacing={3}>
                <RHFTextField required name="title" label={i18n.t('dashboard.ad.title')} />
                <RHFTextField required name="description" label={i18n.t('dashboard.ad.description')} />
                <RHFTextField required name="link" label={i18n.t('dashboard.ad.link')} />
                <div>
                  <LabelStyle> {i18n.t('dashboard.ad.cover')} </LabelStyle>
                  <RHFUploadSingleFile required name="cover" accept="image/*" onDrop={handleDrop} />
                </div>
              </Stack>
            </Card>
          </Grid>
          <Grid item xs={12} md={4}>
            <Card sx={{ p: 3 }}>
              <Stack spacing={3}>
                <RHFSwitch
                  name="publish"
                  label={i18n.t('dashboard.ad.publish')}
                  labelPlacement="start"
                  sx={{ mb: 1, mx: 0, width: 1, justifyContent: 'space-between' }}
                />
              </Stack>
              <Stack direction="row" spacing={1.5} sx={{ mt: 3 }}>
                <LoadingButton fullWidth type="submit" variant="contained" size="large" loading={isSubmitting}>
                  {!isEdit ? i18n.t('form.create') : i18n.t('form.save')}
                </LoadingButton>
              </Stack>
            </Card>
          </Grid>
        </Grid>
      </FormProvider>
    </>
  );
}
