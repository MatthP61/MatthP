import React, { useContext, useEffect, useState } from 'react';
import { useSnackbar } from 'notistack';

// @mui
import {
  Avatar,
  Card,
  Table,
  Checkbox,
  TableRow,
  TableBody,
  TableCell,
  TableContainer,
  TablePagination,
} from '@mui/material';

// components
import { TeamContext } from '../../../contexts/TeamContext';
import Scrollbar from '../../../components/atoms/Scrollbar';
import SearchNotFound from '../../../components/atoms/SearchNotFound';
import ModalCard from '../../../components/molecules/card/ModalCard';

// sections
import { ListHead, ListToolbar, ListMoreMenu } from '../user/list';

// routes
import { PATH_DASHBOARD } from '../../../routes/paths';
import i18n from '../../../locales/i18n';

// ----------------------------------------------------------------------
const TABLE_HEAD = [
  { id: 'name', label: i18n.t('dashboard.team.name'), alignRight: false },
  { id: 'picture', label: i18n.t('dashboard.team.picture'), alignRight: false },
  { id: 'role', label: i18n.t('dashboard.team.role'), alignRight: false },
  { id: 'order', label: i18n.t('dashboard.team.priority'), alignRight: false },
  { id: '' },
];

const IS_EDIT = true;
// ----------------------------------------------------------------------

export default function MembersList() {
  const { memberList, deleteMember, deleteMultiMembers, resetCurrentMember } = useContext(TeamContext);

  const [members, setMembers] = useState([]);
  const [page, setPage] = useState(0);
  const [order, setOrder] = useState('asc');
  const [selected, setSelected] = useState([]);
  const [orderBy, setOrderBy] = useState('title');
  const [filterName, setFilterName] = useState('');
  const [rowsPerPage, setRowsPerPage] = useState(5);

  const [openModal, setOpenModal] = useState(false);
  const [elementToDelete, setElementToDelete] = useState({});
  const [elementsToDelete, setElementsToDelete] = useState([]);

  const { enqueueSnackbar } = useSnackbar();

  const handleOpenModal = (UID, picture, isMulti) => {
    if (isMulti) {
      setElementsToDelete(UID);
    } else {
      setElementToDelete({
        UID,
        picture,
      });
    }
    setOpenModal(true);
  };
  const handleCloseModal = () => {
    setOpenModal(false);
    setElementsToDelete([]);
    setElementToDelete({});
  };

  const handleRequestSort = (event, property) => {
    const isAsc = orderBy === property && order === 'asc';
    setOrder(isAsc ? 'desc' : 'asc');
    setOrderBy(property);
  };

  const handleSelectAllClick = (checked) => {
    if (checked) {
      const newSelecteds = members.map((n) => n.UID);
      setSelected(newSelecteds);
      return;
    }
    setSelected([]);
  };

  const handleClick = (UID) => {
    const selectedIndex = selected.indexOf(UID);
    let newSelected = [];
    if (selectedIndex === -1) {
      newSelected = newSelected.concat(selected, UID);
    } else if (selectedIndex === 0) {
      newSelected = newSelected.concat(selected.slice(1));
    } else if (selectedIndex === selected.length - 1) {
      newSelected = newSelected.concat(selected.slice(0, -1));
    } else if (selectedIndex > 0) {
      newSelected = newSelected.concat(selected.slice(0, selectedIndex), selected.slice(selectedIndex + 1));
    }
    setSelected(newSelected);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const handleFilterByName = (filterName) => {
    setFilterName(filterName);
    setPage(0);
  };

  const handleDeleteMember = () => {
    const deleteMemberList = members.filter((member) => member.UID !== elementToDelete.UID);
    deleteMember(elementToDelete.UID, elementToDelete.picture, deleteMemberList);
    setSelected([]);
    setMembers(deleteMemberList);
    handleCloseModal();
    enqueueSnackbar(i18n.t('form.deleteSuccess'));
  };

  const handleDeleteMultiMembers = async () => {
    const deleteMembersList = members.filter((member) => !elementsToDelete.includes(member.UID));
    deleteMultiMembers(elementsToDelete, deleteMembersList);
    setSelected([]);
    setMembers(deleteMembersList);
    handleCloseModal();
    enqueueSnackbar(i18n.t('form.deleteSuccess'));
  };

  const handleDeleteModal = async () => {
    if (elementsToDelete.length > 0) {
      handleDeleteMultiMembers();
    } else {
      handleDeleteMember();
    }
  };

  const emptyRows = page > 0 ? Math.max(0, (1 + page) * rowsPerPage - members.length) : 0;

  const filteredMembers = applySortFilter(members, getComparator(order, orderBy), filterName);

  const isNotFound = !filteredMembers.length && Boolean(filterName);

  useEffect(() => {
    setMembers(memberList);
  }, [memberList]);

  useEffect(() => {
    setMembers(memberList);
    resetCurrentMember();
  }, []);

  return (
    <>
      <Card>
        <ListToolbar
          numSelected={selected.length}
          filterName={filterName}
          onFilterName={handleFilterByName}
          onDeleteUsers={() => handleOpenModal(selected, '', true)}
        />
        <Scrollbar>
          <TableContainer sx={{ minWidth: 800 }}>
            <Table>
              <ListHead
                order={order}
                orderBy={orderBy}
                headLabel={TABLE_HEAD}
                rowCount={members.length}
                numSelected={selected.length}
                onRequestSort={handleRequestSort}
                onSelectAllClick={handleSelectAllClick}
              />
              <TableBody>
                {filteredMembers.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((row) => {
                  const { UID, order, name, picture, role } = row;
                  const isItemSelected = selected.indexOf(UID) !== -1;

                  return (
                    <TableRow
                      hover
                      key={UID}
                      tabIndex={-1}
                      role="checkbox"
                      selected={isItemSelected}
                      aria-checked={isItemSelected}
                    >
                      <TableCell padding="checkbox">
                        <Checkbox checked={isItemSelected} onClick={() => handleClick(UID)} />
                      </TableCell>
                      <TableCell align="left">{name}</TableCell>
                      <TableCell sx={{ display: 'flex', alignItems: 'center' }}>
                        <Avatar alt={picture} src={picture} sx={{ mr: 2 }} />
                      </TableCell>
                      <TableCell align="left">{role}</TableCell>
                      <TableCell align="left">{order}</TableCell>
                      <TableCell align="right">
                        <ListMoreMenu
                          onDelete={() => handleOpenModal(UID, picture, false)}
                          editPath={`${PATH_DASHBOARD.settings.team}/${UID}/edit`}
                          isEdit={IS_EDIT}
                        />
                      </TableCell>
                    </TableRow>
                  );
                })}
                {emptyRows > 0 && (
                  <TableRow style={{ height: 53 * emptyRows }}>
                    <TableCell colSpan={6} />
                  </TableRow>
                )}
              </TableBody>
              {isNotFound && (
                <TableBody>
                  <TableRow>
                    <TableCell align="center" colSpan={6} sx={{ py: 3 }}>
                      <SearchNotFound searchQuery={filterName} />
                    </TableCell>
                  </TableRow>
                </TableBody>
              )}
            </Table>
          </TableContainer>
        </Scrollbar>

        <TablePagination
          rowsPerPageOptions={[5, 10, 25]}
          component="div"
          count={members.length}
          rowsPerPage={rowsPerPage}
          page={page}
          onPageChange={(e, page) => setPage(page)}
          onRowsPerPageChange={handleChangeRowsPerPage}
        />
        {openModal && (
          <ModalCard isOpen={openModal} handleClose={handleCloseModal} UID={'UID'} deleteElement={handleDeleteModal} />
        )}
      </Card>
    </>
  );
}

// --------------------------------------------------------------------------------------------------------------
function descendingComparator(a, b, orderBy) {
  if (b[orderBy] < a[orderBy]) {
    return -1;
  }
  if (b[orderBy] > a[orderBy]) {
    return 1;
  }
  return 0;
}

function getComparator(order, orderBy) {
  return order === 'desc'
    ? (a, b) => descendingComparator(a, b, orderBy)
    : (a, b) => -descendingComparator(a, b, orderBy);
}

function applySortFilter(array, comparator, query) {
  const stabilizedThis = array.map((el, index) => [el, index]);
  stabilizedThis.sort((a, b) => {
    const order = comparator(a[0], b[0]);
    if (order !== 0) return order;
    return a[1] - b[1];
  });
  if (query) {
    return array.filter((members) => members.name.toLowerCase().indexOf(query.toLowerCase()) !== -1);
  }
  return stabilizedThis.map((el) => el[0]);
}
