import React, { useEffect, useContext, useMemo, useCallback } from 'react';
import { useForm } from 'react-hook-form';
import { useSnackbar } from 'notistack';

// form
import * as Yup from 'yup';
import { yupResolver } from '@hookform/resolvers/yup';

// @mui
import { Grid, Card, Stack } from '@mui/material';
import { LoadingButton } from '@mui/lab';

// routes
import { getStorage, ref, uploadBytes, getDownloadURL } from 'firebase/storage';

// components
import { FormProvider, RHFTextField, RHFUploadSingleFile, RHFEditor } from '../../../components/organismes/hook-form';
import i18n from '../../../locales/i18n';
import { AboutContext } from '../../../contexts/AboutContext';
import { LabelStyle } from '../../../utils/GeneralStyle';

// ----------------------------------------------------------------------

export default function AboutForm() {
  const { cover, pic2, slogan, text, vision, getAbout, editAbout } = useContext(AboutContext);
  const { enqueueSnackbar } = useSnackbar();

  useEffect(() => {
    getAbout();
  }, []);

  const defaultValues = useMemo(
    () => ({
      cover: cover || null,
      pic2: pic2 || '',
      slogan: slogan || '',
      text: text || '',
      vision: vision || '',
    }),
    [cover, pic2, slogan, text, vision]
  );

  const SettingsSchema = Yup.object().shape({
    cover: Yup.mixed().test('required', i18n.t('form.imageRequired'), (value) => value !== ''),
    pic2: Yup.mixed().test('required', i18n.t('form.imageRequired'), (value) => value !== ''),
    slogan: Yup.string().required(i18n.t('form.textRequired')),
    text: Yup.string().required(i18n.t('form.textRequired')),
    vision: Yup.string().required(i18n.t('form.textRequired')),
  });

  const methods = useForm({
    resolver: yupResolver(SettingsSchema),
    defaultValues,
  });

  const {
    watch,
    reset,
    setValue,
    handleSubmit,
    formState: { isSubmitting },
  } = methods;

  const values = watch();

  useEffect(() => {
    reset(defaultValues);
  }, [cover, pic2, slogan, text]);

  const onSubmit = async () => {
    try {
      await editAbout(values).then((error) => {
        if (error === 'error') {
          enqueueSnackbar(i18n.t('form.error'), { variant: 'error' });
          reset(defaultValues);
        } else {
          enqueueSnackbar(i18n.t('form.updateSuccess'));
        }
      });
    } catch (error) {
      console.error(error);
    }
  };

  const handleDropCover = useCallback(
    (acceptedFiles) => {
      const file = acceptedFiles[0];

      if (file === '') {
        console.error(`not an image, the image file is a ${typeof file}`);
      }
      uploadImage('cover', file);
    },
    [setValue]
  );

  const handleDropPic = useCallback(
    (acceptedFiles) => {
      const file = acceptedFiles[0];

      if (file === '') {
        console.error(`not an image, the image file is a ${typeof file}`);
      }
      uploadImage('pic2', file);
    },
    [setValue]
  );

  const uploadImage = (field, file) => {
    const storage = getStorage();
    const storageRef = ref(storage, `/about/${field}`);

    uploadBytes(storageRef, file).then(() => {
      getDownloadURL(storageRef).then((url) => {
        setValue(field, url);
      });
    });
  };

  return (
    <>
      <FormProvider methods={methods} onSubmit={handleSubmit(onSubmit)}>
        <Grid container spacing={3}>
          <Grid item xs={12} md={12}>
            <Card sx={{ p: 3 }}>
              <Stack spacing={3}>
                <RHFTextField required name="slogan" label={i18n.t('dashboard.settings.slogan')} />
                <RHFTextField required name="vision" label={i18n.t('dashboard.settings.vision')} />
                <div>
                  <LabelStyle>{i18n.t('dashboard.settings.body')}</LabelStyle>
                  <RHFEditor name="text" />
                </div>
                <div>
                  <LabelStyle>{i18n.t('dashboard.settings.cover')} </LabelStyle>
                  <RHFUploadSingleFile required name="cover" accept="image/*" onDrop={handleDropCover} />
                </div>
                <div>
                  <LabelStyle>{i18n.t('dashboard.settings.pic')} </LabelStyle>
                  <RHFUploadSingleFile required name="pic2" accept="image/*" onDrop={handleDropPic} />
                </div>
              </Stack>
            </Card>
            <br />
            <LoadingButton fullWidth type="submit" variant="contained" size="large" loading={isSubmitting}>
              {i18n.t('Sauvegarder')}
            </LoadingButton>
          </Grid>
        </Grid>
      </FormProvider>
    </>
  );
}
