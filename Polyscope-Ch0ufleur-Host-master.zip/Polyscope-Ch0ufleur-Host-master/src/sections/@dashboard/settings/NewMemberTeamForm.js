import React, { useCallback, useContext, useMemo, useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import { useForm } from 'react-hook-form';
import { useSnackbar } from 'notistack';

// form
import * as Yup from 'yup';
import { useNavigate } from 'react-router-dom';
import { yupResolver } from '@hookform/resolvers/yup';

// @mui
import { LoadingButton } from '@mui/lab';
import { Grid, Card, Stack, InputAdornment, Box } from '@mui/material';

// routes
import { getStorage, ref, uploadBytes, getDownloadURL, getMetadata } from 'firebase/storage';
import { PATH_DASHBOARD } from '../../../routes/paths';

// components
import { FormProvider, RHFTextField, RHFUploadSingleFile, RHFSelect } from '../../../components/organismes/hook-form';
import Iconify from '../../../components/atoms/Iconify';
import { deletePreviousDrop } from '../../../components/atoms/FirebaseFunctions';
import i18n from '../../../locales/i18n';
import * as SOCIAL_REGEX from '../../../utils/regexSocialMedia';
import { TeamContext } from '../../../contexts/TeamContext';
import { LabelStyle } from '../../../utils/GeneralStyle';

// ----------------------------------------------------------------------
const DEFAULT_PICTURE =
  'https://firebasestorage.googleapis.com/v0/b/polyscope-6feba.appspot.com/o/team-image%2Ftmp.jpg?alt=media&token=d400f96f-06fa-4b5f-ae71-25be65f2a56b';

const SOCIAL_LINKS = [
  {
    value: 'facebook',
    icon: <Iconify icon={'eva:facebook-fill'} width={24} height={24} />,
  },
  {
    value: 'instagram',
    icon: <Iconify icon={'ant-design:instagram-filled'} width={24} height={24} />,
  },
  {
    value: 'linkedin',
    icon: <Iconify icon={'eva:linkedin-fill'} width={24} height={24} />,
  },
  {
    value: 'twitter',
    icon: <Iconify icon={'eva:twitter-fill'} width={24} height={24} />,
  },
];

NewMemberTeamForm.propTypes = {
  isEdit: PropTypes.bool,
  currentMember: PropTypes.object,
};

export default function NewMemberTeamForm({ isEdit, currentMember }) {
  const navigate = useNavigate();
  const { addMember, editMember, memberList } = useContext(TeamContext);
  const [priority, setPriority] = useState([]);
  const { enqueueSnackbar } = useSnackbar();
  const [picStorage, setPicStorage] = useState([]);

  const createPriorityArray = () => {
    const data = [];
    for (let i = 1; i < memberList.length + 2; i += 1) {
      data.push({ value: i, label: i });
    }
    setPriority(data);
    return data;
  };

  const defaultValues = useMemo(
    () => ({
      UID: currentMember?.UID || '',
      name: currentMember?.name || '',
      role: currentMember?.role || '',
      order: currentMember?.order || 1,
      picture: currentMember?.picture || DEFAULT_PICTURE,
      facebook: currentMember?.facebook || '',
      instagram: currentMember?.instagram || '',
      linkedin: currentMember?.linkedin || '',
      twitter: currentMember?.twitter || '',
    }),
    [currentMember]
  );

  const NewTeamMemberSchema = Yup.object().shape({
    name: Yup.string().required(i18n.t('dashboard.team.nameRequired')),
    role: Yup.string().required(i18n.t('dashboard.team.roleRequired')),
    order: Yup.number().required(i18n.t('dashboard.team.orderRequired')),
    picture: Yup.mixed().test('required', i18n.t('form.imageRequired'), (value) => value !== ''),
    facebook: Yup.lazy((value) =>
      !value ? Yup.string() : Yup.string().matches(SOCIAL_REGEX.FACEBOOK, i18n.t('form.linkValid'))
    ),
    instagram: Yup.lazy((value) =>
      !value ? Yup.string() : Yup.string().matches(SOCIAL_REGEX.INSTAGRAM, i18n.t('form.linkValid'))
    ),
    linkedin: Yup.lazy((value) =>
      !value ? Yup.string() : Yup.string().matches(SOCIAL_REGEX.LINKEDIN, i18n.t('form.linkValid'))
    ),
    twitter: Yup.lazy((value) =>
      !value ? Yup.string() : Yup.string().matches(SOCIAL_REGEX.TWITTER, i18n.t('form.linkValid'))
    ),
  });

  const methods = useForm({
    resolver: yupResolver(NewTeamMemberSchema),
    defaultValues,
  });

  const {
    watch,
    reset,
    setValue,
    handleSubmit,
    formState: { isSubmitting },
  } = methods;

  const values = watch();

  useEffect(() => {
    reset(defaultValues);
    if (defaultValues.picture !== DEFAULT_PICTURE) {
      setPicStorage((picStorage) => [...picStorage, defaultValues.picture]);
    }
    createPriorityArray();
  }, [isEdit, currentMember]);

  const onSubmit = async () => {
    try {
      deletePreviousDrop(picStorage);
      if (isEdit) {
        editMember(values);
      } else {
        addMember(values);
      }
      reset();
      enqueueSnackbar(!isEdit ? i18n.t('form.createSuccess') : i18n.t('form.updateSuccess'));
      navigate(PATH_DASHBOARD.settings.team);
    } catch (error) {
      console.error(error);
    }
  };

  const handleDrop = useCallback(
    (acceptedFiles) => {
      const file = acceptedFiles[0];

      if (file === '') {
        console.error(`not an image, the image file is a ${typeof file}`);
      }

      const storage = getStorage();
      const storageRef = ref(storage, `/team-image/${file.name}`);

      getMetadata(storageRef)
        .then(() => {
          const tmp = Math.random();
          const storageRef = ref(storage, `/team-image/${file.name}${tmp}`);
          uploadImage(storageRef, 'picture', file);
        })
        .catch(() => {
          uploadImage(storageRef, 'picture', file);
        });
    },
    [setValue]
  );

  const uploadImage = (storageRef, field, file) => {
    uploadBytes(storageRef, file).then(() => {
      getDownloadURL(storageRef).then((url) => {
        setValue(field, url);
        setPicStorage((picStorage) => [...picStorage, url]);
      });
    });
  };

  return (
    <>
      <FormProvider methods={methods} onSubmit={handleSubmit(onSubmit)}>
        <Grid container spacing={3}>
          <Grid item xs={12} md={12}>
            <Card sx={{ p: 3 }}>
              <Stack spacing={3}>
                <RHFTextField required name="name" label={i18n.t('dashboard.team.name')} />
                <Box
                  sx={{
                    display: 'grid',
                    columnGap: 2,
                    rowGap: 3,
                    gridTemplateColumns: { xs: 'repeat(1, 1fr)', sm: 'repeat(2, 1fr)' },
                  }}
                >
                  <RHFTextField required name="role" label={i18n.t('dashboard.team.role')} />
                  <RHFSelect required name="order" label={i18n.t('dashboard.team.priority')}>
                    {priority.map((option) => (
                      <option key={option.value} value={option.value}>
                        {option.label}
                      </option>
                    ))}
                  </RHFSelect>
                </Box>
                {SOCIAL_LINKS.map((link) => (
                  <RHFTextField
                    key={link.value}
                    name={link.value}
                    InputProps={{
                      startAdornment: <InputAdornment position="start">{link.icon}</InputAdornment>,
                    }}
                  />
                ))}

                <div>
                  <LabelStyle>{i18n.t('dashboard.team.picture')} </LabelStyle>
                  <RHFUploadSingleFile required name="picture" accept="image/*" onDrop={handleDrop} />
                </div>
              </Stack>
            </Card>
            <br />
            <LoadingButton fullWidth type="submit" variant="contained" size="large" loading={isSubmitting}>
              {!isEdit ? i18n.t('form.create') : i18n.t('form.save')}
            </LoadingButton>
          </Grid>
        </Grid>
      </FormProvider>
    </>
  );
}
