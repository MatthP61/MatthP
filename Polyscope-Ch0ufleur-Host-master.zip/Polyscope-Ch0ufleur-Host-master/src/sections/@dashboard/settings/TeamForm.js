import React, { useEffect, useContext, useMemo } from 'react';
import { useForm } from 'react-hook-form';
import { useSnackbar } from 'notistack';

// form
import * as Yup from 'yup';
import { yupResolver } from '@hookform/resolvers/yup';

// @mui
import { Grid, Card, Stack } from '@mui/material';
import { LoadingButton } from '@mui/lab';

// components
import { FormProvider, RHFTextField } from '../../../components/organismes/hook-form';
import i18n from '../../../locales/i18n';
import { TeamContext } from '../../../contexts/TeamContext';

// ---------------------------------------------------------------------

export default function TeamForm() {
  const { title, subtitle, editInformations, getInformations } = useContext(TeamContext);
  const { enqueueSnackbar } = useSnackbar();

  useEffect(() => {
    getInformations();
  }, []);

  const defaultValues = useMemo(
    () => ({
      title: title || '',
      subtitle: subtitle || '',
    }),
    [title, subtitle]
  );

  const SettingsSchema = Yup.object().shape({
    title: Yup.string().required(i18n.t('form.textRequired')),
    subtitle: Yup.string().required(i18n.t('form.textRequired')),
  });

  const methods = useForm({
    resolver: yupResolver(SettingsSchema),
    defaultValues,
  });

  const {
    watch,
    reset,
    handleSubmit,
    formState: { isSubmitting, isDirty },
  } = methods;

  const values = watch();

  useEffect(() => {
    reset(defaultValues);
  }, [title, subtitle]);

  const onSubmit = async () => {
    try {
      await editInformations(values).then((error) => {
        if (error === 'error') {
          enqueueSnackbar(i18n.t('form.error'), { variant: 'error' });
          reset(defaultValues);
        } else {
          enqueueSnackbar(i18n.t('form.updateSuccess'));
        }
      });
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <>
      <FormProvider methods={methods} onSubmit={handleSubmit(onSubmit)}>
        <Grid container spacing={3}>
          <Grid item xs={12} md={12}>
            <Card sx={{ p: 3 }}>
              <Stack spacing={3}>
                <RHFTextField required name="title" label={i18n.t('dashboard.settings.title')} />
                <RHFTextField
                  required
                  name="subtitle"
                  label={i18n.t('dashboard.settings.subtitle')}
                  multiline
                  rows="2"
                />
              </Stack>
            </Card>
            <br />
            <LoadingButton
              fullWidth
              type="submit"
              variant="contained"
              size="large"
              loading={isSubmitting}
              disabled={!isDirty}
            >
              {i18n.t('Sauvegarder')}
            </LoadingButton>
          </Grid>
        </Grid>
      </FormProvider>
    </>
  );
}
