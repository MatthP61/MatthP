import React, { useEffect, useContext, useMemo } from 'react';
import { useForm } from 'react-hook-form';
import { useSnackbar } from 'notistack';

// form
import * as Yup from 'yup';
import { yupResolver } from '@hookform/resolvers/yup';

// @mui
import { Grid, Card, Stack } from '@mui/material';
import { LoadingButton } from '@mui/lab';

// components
import { FormProvider, RHFTextField, RHFSwitch } from '../../../components/organismes/hook-form';
import i18n from '../../../locales/i18n';
import { GeneralSettingsContext } from '../../../contexts/GeneralSettingsContext';
import { LabelStyle } from '../../../utils/GeneralStyle';
// ---------------------------------------------------------------------

export default function VerifyCodeUserForm() {
  const { code, isActive, editInformations, getInformations } = useContext(GeneralSettingsContext);
  const { enqueueSnackbar } = useSnackbar();

  useEffect(() => {
    getInformations();
  }, []);

  const defaultValues = useMemo(
    () => ({
      code: code || '',
      isActive: isActive || false,
    }),
    [code, isActive]
  );

  const VerifyCodeUserSchema = Yup.object().shape({
    code: Yup.string().required(i18n.t('form.codeReq')),
  });

  const methods = useForm({
    resolver: yupResolver(VerifyCodeUserSchema),
    defaultValues,
  });

  const {
    watch,
    reset,
    handleSubmit,
    formState: { isSubmitting, isDirty },
  } = methods;

  const values = watch();

  useEffect(() => {
    reset(defaultValues);
  }, [code, isActive]);

  const onSubmit = async () => {
    try {
      await editInformations(values).then((error) => {
        if (error === 'error') {
          enqueueSnackbar(i18n.t('form.error'), { variant: 'error' });
          reset(defaultValues);
        } else {
          enqueueSnackbar(i18n.t('form.updateSuccess'));
        }
      });
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <>
      <FormProvider methods={methods} onSubmit={handleSubmit(onSubmit)}>
        <Grid container spacing={3}>
          <Grid item xs={12} md={6}>
            <Card sx={{ p: 3 }}>
              <Stack spacing={3}>
                <LabelStyle>{i18n.t('dashboard.settings.titleCode')}</LabelStyle>

                <Stack spacing={10} direction="row">
                  <RHFTextField required name="code" label={i18n.t('dashboard.settings.code')} />
                  <RHFSwitch
                    name="isActive"
                    label={i18n.t('dashboard.settings.codeActive')}
                    labelPlacement="start"
                    sx={{ mb: 1, mx: 0, width: 1, justifyContent: 'space-between' }}
                  />
                </Stack>
              </Stack>
            </Card>
            <br />
            <LoadingButton
              fullWidth
              type="submit"
              variant="contained"
              size="large"
              loading={isSubmitting}
              disabled={!isDirty}
            >
              {i18n.t('Sauvegarder')}
            </LoadingButton>
          </Grid>
        </Grid>
      </FormProvider>
    </>
  );
}
