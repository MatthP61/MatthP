import React, { useCallback, useContext, useMemo, useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import { useForm } from 'react-hook-form';
import { useSnackbar } from 'notistack';

// form
import * as Yup from 'yup';
import { useNavigate } from 'react-router-dom';
import { yupResolver } from '@hookform/resolvers/yup';

// @mui
import { LoadingButton } from '@mui/lab';
import { Grid, Box, FormControl, Card, Stack } from '@mui/material';

// routes
import { getStorage, ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { PATH_DASHBOARD } from '../../../routes/paths';

// components
import {
  RHFSwitch,
  FormProvider,
  RHFTextField,
  RHFSelect,
  RHFUploadSingleFile,
} from '../../../components/organismes/hook-form';
import { CategoryContext } from '../../../contexts/CategoryContext';
import i18n from '../../../locales/i18n';
import { deletePreviousDrop } from '../../../components/atoms/FirebaseFunctions';
import { LabelStyle } from '../../../utils/GeneralStyle';

// ----------------------------------------------------------------------

NewCategoryForm.propTypes = {
  isEdit: PropTypes.bool,
  currentCategory: PropTypes.object,
};

export default function NewCategoryForm({ isEdit, currentCategory }) {
  const navigate = useNavigate();
  const { uploadCategory, editCategory, CategoryList } = useContext(CategoryContext);
  const { enqueueSnackbar } = useSnackbar();
  const [coverStorage, setCoverStorage] = useState([]);

  const defaultValues = useMemo(
    () => ({
      UID: currentCategory?.UID || '',
      title: currentCategory?.title || '',
      cover: currentCategory?.cover || '',
      priority: currentCategory?.priority || 0,
      publish: currentCategory?.publish || false,
    }),
    [currentCategory]
  );

  const NewCategorySchema = Yup.object().shape({
    title: Yup.string().required(i18n.t('dashboard.category.titleRequired')),
    priority: Yup.number().required(i18n.t('dashboard.category.priorityRequired')),
    cover: Yup.mixed().test('required', i18n.t('form.imageRequired'), (value) => value !== ''),
  });

  const methods = useForm({
    resolver: yupResolver(NewCategorySchema),
    defaultValues,
  });

  const {
    watch,
    reset,
    setValue,
    handleSubmit,
    formState: { isSubmitting },
  } = methods;

  const values = watch();

  useEffect(() => {
    reset(defaultValues);
    setCoverStorage((coverStorage) => [...coverStorage, defaultValues.cover]);
  }, [isEdit, currentCategory]);

  const onSubmit = async () => {
    try {
      deletePreviousDrop(coverStorage);
      if (isEdit) {
        editCategory(values);
      } else {
        uploadCategory(values);
      }
      reset();
      enqueueSnackbar(!isEdit ? i18n.t('form.createSuccess') : i18n.t('form.updateSuccess'));
      navigate(PATH_DASHBOARD.category.list);
    } catch (error) {
      console.error(error);
    }
  };

  const [priority, setPriority] = useState([]);

  const createPriorityArray = () => {
    const data = [];
    for (let i = 0; i < CategoryList.length + 2; i += 1) {
      data.push({ value: i, label: i });
    }
    setPriority(data);
    return data;
  };

  useEffect(() => {
    createPriorityArray();
  }, [isEdit, currentCategory]);

  const handleDrop = useCallback(
    (acceptedFiles) => {
      const file = acceptedFiles[0];

      if (file === '') {
        console.error(`not an image, the image file is a ${typeof file}`);
      }

      const tmp = Math.random();
      const storage = getStorage();
      const storageRef = ref(storage, `/category-image/${file.name}${tmp}`);
      uploadImage(storageRef, 'cover', file);
    },
    [setValue]
  );

  const uploadImage = (storageRef, field, file) => {
    uploadBytes(storageRef, file).then(() => {
      getDownloadURL(storageRef).then((url) => {
        setValue(field, url);
        setCoverStorage((coverStorage) => [...coverStorage, url]);
      });
    });
  };

  return (
    <>
      <FormProvider methods={methods} onSubmit={handleSubmit(onSubmit)}>
        <Grid container spacing={3}>
          <Grid item xs={12} md={8}>
            <Card sx={{ p: 3 }}>
              <Stack spacing={3}>
                <RHFTextField required name="title" label={i18n.t('dashboard.category.titleCategory')} />
                <Box sx={{ minWidth: 120 }}>
                  <FormControl fullWidth>
                    <RHFSelect required name="priority" label={i18n.t('dashboard.category.priority')}>
                      {priority.map((option) => (
                        <option key={option.value} value={option.value}>
                          {option.label}
                        </option>
                      ))}
                    </RHFSelect>
                  </FormControl>
                </Box>
                <div>
                  <LabelStyle> {i18n.t('dashboard.ad.cover')} </LabelStyle>
                  <RHFUploadSingleFile required name="cover" accept="image/*" onDrop={handleDrop} />
                </div>
              </Stack>
            </Card>
          </Grid>
          <Grid item xs={12} md={4}>
            <Card sx={{ p: 3 }}>
              <Stack spacing={3}>
                <RHFSwitch
                  name="publish"
                  label={i18n.t('dashboard.category.ispublish')}
                  labelPlacement="start"
                  sx={{ mb: 1, mx: 0, width: 1, justifyContent: 'space-between' }}
                />
              </Stack>
              <Stack direction="row" spacing={1.5} sx={{ mt: 3 }}>
                <LoadingButton fullWidth type="submit" variant="contained" size="large" loading={isSubmitting}>
                  {!isEdit ? i18n.t('form.create') : i18n.t('form.save')}
                </LoadingButton>
              </Stack>
            </Card>
          </Grid>
        </Grid>
      </FormProvider>
    </>
  );
}
