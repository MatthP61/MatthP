import PropTypes from 'prop-types';
// Link
import { Link as RouterLink } from 'react-router-dom';
// @mui
import { Stack, Link } from '@mui/material';
// utils
import { fDate } from '../../../utils/formatTime';
// components
import Image from '../../../components/atoms/Image';
import TextMaxLine from '../../../components/atoms/TextMaxLine';

// ----------------------------------------------------------------------

BlogPostItemMobile.propTypes = {
  onSiderbar: PropTypes.bool,
  path: PropTypes.string,
  post: PropTypes.shape({
    cover: PropTypes.string,
    UID: PropTypes.string,
    createdAt: PropTypes.number,
    title: PropTypes.string,
  }),
};

export default function BlogPostItemMobile({ path, post, onSiderbar }) {
  const { title, cover, createdAt, UID } = post;

  return (
    <Link underline="none" component={RouterLink} to={`${path}/post/${UID}`}>
      <Stack spacing={2} direction="row" alignItems={{ xs: 'flex-start', md: 'unset' }} sx={{ width: 1 }}>
        <Image
          alt={title}
          src={cover}
          sx={{
            width: 80,
            height: 80,
            flexShrink: 0,
            borderRadius: 1.5,
          }}
        />

        <Stack spacing={onSiderbar ? 0.5 : 1}>
          <TextMaxLine
            variant={onSiderbar ? 'subtitle2' : 'h6'}
            sx={{
              color: 'text.primary',
            }}
            asLink
          >
            {title}
          </TextMaxLine>
          {createdAt && (
            <Stack
              direction="row"
              flexWrap="wrap"
              alignItems="center"
              sx={{ typography: 'caption', color: 'text.disabled' }}
            >
              {fDate(createdAt)}
            </Stack>
          )}
        </Stack>
      </Stack>
    </Link>
  );
}
