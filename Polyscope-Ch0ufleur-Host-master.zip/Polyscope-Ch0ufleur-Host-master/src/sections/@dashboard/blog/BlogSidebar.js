import PropTypes from 'prop-types';
// @mui
import { Stack } from '@mui/material';
// hooks
import useResponsive from '../../../hooks/useResponsive';
// components
import BlogPostsSearch from './BlogPostsSearch';
import Advertisement01 from '../ads/Advertisement01';
import BlogSidebarAuthor from './BlogSidebarAuthor';
import BlogSidebarCategories from './BlogSidebarCategories';
import BlogSidebarRecentPosts from './BlogSidebarRecentPosts';

// ----------------------------------------------------------------------

BlogSidebar.propTypes = {
  advertisement: PropTypes.object,
  author: PropTypes.object,
  recentPosts: PropTypes.object,
  sx: PropTypes.object,
};

export default function BlogSidebar({ author, recentPosts, advertisement, sx, ...other }) {
  const isDesktop = useResponsive('up', 'md');

  return (
    <>
      {author && isDesktop && <BlogSidebarAuthor author={author} />}

      {isDesktop && <BlogPostsSearch />}

      <Stack
        spacing={5}
        sx={{
          pt: { md: 5 },
          pb: { xs: 8, md: 8 },
          position: { md: 'sticky' },
          top: { md: 0 },
          ...sx,
        }}
        {...other}
      >
        <BlogSidebarCategories />
        <BlogSidebarRecentPosts recentPosts={recentPosts} />
        <Advertisement01 advertisement={advertisement} />
      </Stack>
    </>
  );
}
