import PropTypes from 'prop-types';
import { useRef, useContext } from 'react';
import Slider from 'react-slick';
import { m } from 'framer-motion';
// netx
import { Link as RouterLink } from 'react-router-dom';
// @mui
import { styled, useTheme } from '@mui/material/styles';
import { Typography, Link, Stack, Container, Box } from '@mui/material';
// components
import Image from '../../../components/atoms/Image';
import BgOverlay from '../../../components/atoms/BgOverlay';
import { CarouselArrows } from '../../../components/organismes/carousel';
import { varHover, varTranHover } from '../../../components/molecules/animate';
import { CategoryContext } from '../../../contexts/CategoryContext';
import i18n from '../../../locales/i18n';
// ----------------------------------------------------------------------
const RootStyle = styled(Stack)(({ theme }) => ({
  padding: theme.spacing(8, 0),
  backgroundColor: theme.palette.background.neutral,
  [theme.breakpoints.up('md')]: {
    padding: theme.spacing(10, 0),
  },
}));

// ----------------------------------------------------------------------
const CATEGORY_MINIMUM = 4;

export default function BlogTrendingTopics() {
  const theme = useTheme();
  const carouselRef = useRef(null);
  const { categoryActiveList } = useContext(CategoryContext);

  const carouselSettings = {
    arrows: false,
    slidesToShow: CATEGORY_MINIMUM,
    slidesToScroll: 1,
    rtl: Boolean(theme.direction === 'rtl'),
    responsive: [
      {
        breakpoint: theme.breakpoints.values.md,
        settings: { slidesToShow: 2 },
      },
      {
        breakpoint: theme.breakpoints.values.sm,
        settings: { slidesToShow: 1 },
      },
    ],
  };

  const handlePrevious = () => {
    carouselRef.current?.slickPrev();
  };

  const handleNext = () => {
    carouselRef.current?.slickNext();
  };

  return (
    <RootStyle>
      <Container>
        <Stack direction="row" justifyContent={{ md: 'space-between' }} sx={{ mb: 6 }}>
          <Typography variant="h3">{i18n.t('dashboard.category.popular')}</Typography>
          {categoryActiveList.length > CATEGORY_MINIMUM && (
            <CarouselArrows
              onNext={handleNext}
              onPrevious={handlePrevious}
              sx={{
                display: { xs: 'none', md: 'block' },
              }}
            />
          )}
        </Stack>

        <Slider ref={carouselRef} {...carouselSettings}>
          {categoryActiveList
            .sort((category, category1) => category.priority - category1.priority)
            .map((topic) => (
              <TopicItem key={topic?.UID} topic={topic} />
            ))}
        </Slider>
        <CarouselArrows
          onNext={handleNext}
          onPrevious={handlePrevious}
          sx={{
            mt: 6,
            justifyContent: 'center',
            display: { md: 'none' },
          }}
        />
      </Container>
    </RootStyle>
  );
}

// ----------------------------------------------------------------------

TopicItem.propTypes = {
  topic: PropTypes.shape({
    category: PropTypes.string,
    title: PropTypes.string,
    cover: PropTypes.string,
    total: PropTypes.number,
  }),
};

function TopicItem({ topic }) {
  const { title, category, cover, total } = topic;

  return (
    <Link to={`category/${title}`} color="inherit" component={RouterLink} textAlign="left">
      <Box
        component={m.div}
        whileHover="hover"
        variants={varHover(1)}
        transition={varTranHover()}
        sx={{ px: 1.5, cursor: 'pointer' }}
      >
        <Box sx={{ borderRadius: 2, overflow: 'hidden', position: 'relative' }}>
          <Stack
            spacing={0.5}
            sx={{
              py: 3,
              width: 1,
              zIndex: 9,
              bottom: 0,
              textAlign: 'center',
              position: 'absolute',
              color: 'common.white',
            }}
          >
            <m.div variants={varHover(1.05)} transition={varTranHover()}>
              <Typography variant="h5">{title}</Typography>
            </m.div>

            <Typography variant="body2" sx={{ opacity: 0.72 }}>
              {total} {i18n.t('blogs')}
            </Typography>
          </Stack>

          <BgOverlay />

          <m.div variants={varHover(1.25)} transition={varTranHover()}>
            <Image alt={category} src={cover} ratio="4/3" />
          </m.div>
        </Box>
      </Box>
    </Link>
  );
}
