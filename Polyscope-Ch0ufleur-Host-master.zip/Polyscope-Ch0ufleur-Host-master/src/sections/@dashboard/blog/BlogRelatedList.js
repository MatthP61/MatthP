import PropTypes from 'prop-types';
// @mui
import { styled } from '@mui/material/styles';
import { Box, Stack, Button, Avatar, Container, Typography, Link } from '@mui/material';
import { Link as RouterLink } from 'react-router-dom';
import i18n from '../../../locales/i18n';
// hooks
import useResponsive from '../../../hooks/useResponsive';
// utils
import { fDate } from '../../../utils/formatTime';
// components
import Image from '../../../components/atoms/Image';
import TextMaxLine from '../../../components/atoms/TextMaxLine';
import BlogPostItemMobile from './BlogPostItemMobile';

// ----------------------------------------------------------------------

const RootStyle = styled('div')(({ theme }) => ({
  padding: theme.spacing(8, 0),
  [theme.breakpoints.up('md')]: {
    padding: theme.spacing(15, 0),
  },
}));

// ----------------------------------------------------------------------

BlogRelatedList.propTypes = {
  posts: PropTypes.array.isRequired,
};

export default function BlogRelatedList({ posts }) {
  const isDesktop = useResponsive('up', 'md');
  return (
    <RootStyle>
      <Container>
        <Stack
          direction="row"
          alignItems="center"
          justifyContent={{ xs: 'center', md: 'space-between' }}
          sx={{
            mb: { xs: 8, md: 10 },
          }}
        >
          <Typography variant="h2">{i18n.t('home.relatedBlogs')}</Typography>

          <Link to={`blogs`} color="inherit" component={RouterLink} textAlign="left">
            <Button sx={{ display: { xs: 'none', md: 'inline-flex' } }}>{i18n.t('home.more')}</Button>
          </Link>
        </Stack>

        <Box
          sx={{
            display: 'grid',
            gap: 3,
            gridTemplateColumns: {
              xs: 'repeat(1, 1fr)',
              sm: 'repeat(2, 1fr)',
              md: 'repeat(4, 1fr)',
            },
          }}
        >
          {posts
            .slice(0, 4)
            .map((post) =>
              isDesktop ? (
                <PostItem key={post?.UID} post={post} />
              ) : (
                <BlogPostItemMobile key={post?.UID} post={post} path="/travel/blog" />
              )
            )}
        </Box>

        <Stack
          alignItems="center"
          sx={{
            mt: 8,
            display: { xs: 'flex', md: 'none' },
          }}
        >
          <Link to={`blogs`} color="inherit" component={RouterLink} textAlign="left">
            <Button>{i18n.t('home.more')}</Button>
          </Link>
        </Stack>
      </Container>
    </RootStyle>
  );
}

// ----------------------------------------------------------------------

PostItem.propTypes = {
  post: PropTypes.shape({
    author: PropTypes.shape({
      name: PropTypes.string,
      photoURL: PropTypes.string,
    }),
    cover: PropTypes.string,
    createdAt: PropTypes.number,
    duration: PropTypes.string,
    title: PropTypes.string,
    objectID: PropTypes.string,
  }),
};

function PostItem({ post }) {
  const { title, cover, author, createdAt, objectID } = post;

  return (
    <Link to={`/blog/post/${objectID}`} color="inherit" component={RouterLink} textAlign="left">
      <Stack spacing={2.5}>
        <Image src={cover} alt={title} ratio="1/1" sx={{ borderRadius: 2 }} />

        <Stack spacing={1}>
          {createdAt && (
            <Stack direction="row" alignItems="center" sx={{ typography: 'caption', color: 'text.disabled' }}>
              {fDate(createdAt)}
            </Stack>
          )}

          <TextMaxLine variant="h6" asLink persistent>
            {title}
          </TextMaxLine>
        </Stack>

        <Stack spacing={1} direction="row" alignItems="center">
          <Avatar src={author?.photoURL} sx={{ width: 32, height: 32 }} />
          <Typography variant="body2">{author.name}</Typography>
        </Stack>
      </Stack>
    </Link>
  );
}
