import PropTypes from 'prop-types';
import { Link as RouterLink } from 'react-router-dom';
import { useSnackbar } from 'notistack';
// @mui
import { alpha, styled } from '@mui/material/styles';
import { Box, Link, Avatar, SpeedDial, Typography, SpeedDialAction } from '@mui/material';
import { FacebookShareButton, LinkedinShareButton, TwitterShareButton } from 'react-share';
// routes
import { PATH_PAGE } from '../../../routes/paths';
// hooks
import useResponsive from '../../../hooks/useResponsive';
// utils
import { fDate } from '../../../utils/formatTime';
// components
import Image from '../../../components/atoms/Image';
import Iconify from '../../../components/atoms/Iconify';
import i18n from '../../../locales/i18n';

// ----------------------------------------------------------------------

const OverlayStyle = styled('h1')(({ theme }) => ({
  top: 0,
  right: 0,
  bottom: 0,
  left: 0,
  zIndex: 9,
  position: 'absolute',
  backgroundColor: alpha(theme.palette.grey[900], 0.72),
}));

const TitleStyle = styled('h1')(({ theme }) => ({
  ...theme.typography.h2,
  top: 0,
  zIndex: 10,
  width: '100%',
  position: 'absolute',
  padding: theme.spacing(3),
  color: theme.palette.common.white,
  [theme.breakpoints.up('lg')]: {
    padding: theme.spacing(10),
  },
}));

const FooterStyle = styled('div')(({ theme }) => ({
  bottom: 0,
  zIndex: 10,
  width: '100%',
  display: 'flex',
  position: 'absolute',
  alignItems: 'flex-end',
  paddingLeft: theme.spacing(3),
  paddingRight: theme.spacing(2),
  paddingBottom: theme.spacing(3),
  justifyContent: 'space-between',
  [theme.breakpoints.up('sm')]: {
    alignItems: 'center',
    paddingRight: theme.spacing(3),
  },
  [theme.breakpoints.up('lg')]: {
    padding: theme.spacing(10),
  },
}));

// ----------------------------------------------------------------------

BlogPostHero.propTypes = {
  post: PropTypes.object.isRequired,
};

export default function BlogPostHero({ post }) {
  const { cover, title, author, editDates } = post;
  const journalistLink = `${PATH_PAGE.journalist}/${author.UID}`;
  const isDesktop = useResponsive('up', 'sm');
  const shareUrl = window.location.href;
  const { enqueueSnackbar } = useSnackbar();
  const polyscopeLink = 'https://polyscope.step.polymtl.ca/';

  const copy = () => {
    navigator.clipboard.writeText(shareUrl);
    enqueueSnackbar(i18n.t('copySuccess'));
  };

  const SOCIALS = [
    {
      name: 'Facebook',
      action: (
        <FacebookShareButton url={shareUrl} quote={title}>
          <Iconify icon="eva:facebook-fill" width={20} height={20} color="#1877F2" />
        </FacebookShareButton>
      ),
    },
    {
      name: 'Linkedin',
      action: (
        <LinkedinShareButton url={shareUrl} quote={title} source={polyscopeLink}>
          <Iconify icon="eva:linkedin-fill" width={20} height={20} color="#006097" />
        </LinkedinShareButton>
      ),
    },
    {
      name: 'Twitter',
      action: (
        <TwitterShareButton url={shareUrl} title={title}>
          <Iconify icon="eva:twitter-fill" width={20} height={20} color="#1C9CEA" />
        </TwitterShareButton>
      ),
    },
  ];

  return (
    <Box sx={{ position: 'relative' }}>
      <TitleStyle>{title}</TitleStyle>

      <FooterStyle>
        <Box sx={{ display: 'flex', alignItems: 'center' }}>
          <Avatar alt={author?.displayName} src={author?.photoURL} sx={{ width: 48, height: 48 }} />
          <Box sx={{ ml: 2 }}>
            <Link to={journalistLink} color="inherit" component={RouterLink} textAlign="left">
              <Typography variant="subtitle1" sx={{ color: 'common.white' }}>
                {author?.displayName}
              </Typography>
            </Link>
            {editDates.length > 0 && (
              <Typography variant="body2" sx={{ color: 'grey.500' }}>
                {fDate(editDates[0])}
              </Typography>
            )}
          </Box>
        </Box>
        <SpeedDial
          direction={isDesktop ? 'left' : 'up'}
          ariaLabel="Share post"
          icon={<Iconify icon="eva:share-fill" sx={{ width: 20, height: 20 }} />}
          sx={{ '& .MuiSpeedDial-fab': { width: 48, height: 48 } }}
        >
          {SOCIALS.map((action) => (
            <SpeedDialAction
              key={action.name}
              icon={action.action}
              tooltipTitle={action.name}
              tooltipPlacement="top"
              FabProps={{ color: 'default' }}
            />
          ))}
          <SpeedDialAction
            key={i18n.t('copy')}
            icon={<Iconify icon="eva:copy-outline" width={20} height={20} color="error.main" />}
            tooltipTitle={i18n.t('copy')}
            tooltipPlacement="top"
            FabProps={{ color: 'default' }}
            onClick={copy}
          />
        </SpeedDial>
      </FooterStyle>

      <OverlayStyle />
      <Image alt="post cover" src={cover} ratio={isDesktop ? '16/9' : '3/4'} />
    </Box>
  );
}
