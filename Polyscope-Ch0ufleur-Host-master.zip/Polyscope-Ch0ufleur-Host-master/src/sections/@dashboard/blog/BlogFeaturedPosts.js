import PropTypes from 'prop-types';
// next
import { Link as RouterLink } from 'react-router-dom';
// @mui
import { styled } from '@mui/material/styles';
import { Container, Stack, Link, Box, Avatar } from '@mui/material';
// utils
import { fDate } from '../../../utils/formatTime';
// components
import Image from '../../../components/atoms/Image';
import BgOverlay from '../../../components/atoms/BgOverlay';
import TextMaxLine from '../../../components/atoms/TextMaxLine';
import { PATH_PAGE } from '../../../routes/paths';

// ----------------------------------------------------------------------

const RootStyle = styled('div')(({ theme }) => ({
  paddingBottom: theme.spacing(8, 0),
  [theme.breakpoints.up('md')]: {
    padding: theme.spacing(10, 0),
  },
}));

// ----------------------------------------------------------------------

BlogFeaturedPosts.propTypes = {
  posts: PropTypes.array.isRequired,
};

export default function BlogFeaturedPosts({ posts }) {
  return (
    <RootStyle>
      <Container>
        <Box
          sx={{
            display: 'grid',
            gap: 3,
            gridTemplateColumns: {
              xs: 'repeat(1, 1fr)',
              md: 'repeat(2, 1fr)',
            },
          }}
        >
          <PostItem post={posts[0]} largePost />

          <Box
            sx={{
              display: 'grid',
              gap: 3,
              gridTemplateColumns: {
                xs: 'repeat(1, 1fr)',
                sm: 'repeat(2, 1fr)',
              },
            }}
          >
            {posts.slice(1, 5).map((post) => post.publish && <PostItem key={post.UID} post={post} />)}
          </Box>
        </Box>
      </Container>
    </RootStyle>
  );
}

// ----------------------------------------------------------------------

PostItem.propTypes = {
  largePost: PropTypes.bool,
  post: PropTypes.shape({
    author: PropTypes.shape({
      name: PropTypes.string,
      photoURL: PropTypes.string,
    }),
    cover: PropTypes.string,
    createdAt: PropTypes.number,
    description: PropTypes.string,
    title: PropTypes.string,
    UID: PropTypes.string,
  }),
};

function PostItem({ post, largePost }) {
  const { title, UID, description, createdAt, author, cover } = post;

  return (
    <Link underline="none" component={RouterLink} to={`${PATH_PAGE.blog}/post/${UID}`}>
      <Box sx={{ borderRadius: 2, overflow: 'hidden', position: 'relative' }}>
        <Image src={cover} alt={title} ratio="1/1" />

        <Stack
          spacing={1}
          sx={{
            p: 3,
            bottom: 0,
            zIndex: 9,
            position: 'absolute',
            color: 'common.white',
            ...(largePost && {
              p: { xs: 3, md: 5 },
            }),
          }}
        >
          {createdAt && (
            <Stack direction="row" alignItems="center" sx={{ opacity: 0.72, typography: 'caption' }}>
              {fDate(createdAt)}
            </Stack>
          )}
          <TextMaxLine
            asLink
            sx={{
              typography: 'h6',
              ...(largePost && {
                typography: { xs: 'h6', md: 'h4' },
              }),
            }}
          >
            {title}
          </TextMaxLine>
          {largePost && <TextMaxLine sx={{ opacity: 0.48 }}>{description}</TextMaxLine>}
          <Stack direction="row" alignItems="center" sx={{ typography: 'body2', pt: 1.5 }}>
            <Avatar
              src={author?.photoURL}
              sx={{
                mr: 1,
                width: 32,
                height: 32,
                ...(largePost && {
                  width: { xs: 32, md: 40 },
                  height: { xs: 32, md: 40 },
                }),
              }}
            />
            {author.name}
          </Stack>
        </Stack>

        <BgOverlay />
      </Box>
    </Link>
  );
}
