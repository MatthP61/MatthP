import PropTypes from 'prop-types';
// @mui
import { Stack, Typography } from '@mui/material';
//
import BlogPostItemMobile from './BlogPostItemMobile';
import i18n from '../../../locales/i18n';
// ----------------------------------------------------------------------

BlogSidebarRecentPosts.propTypes = {
  recentPosts: PropTypes.shape({
    list: PropTypes.array,
    path: PropTypes.string,
  }),
};

export default function BlogSidebarRecentPosts({ recentPosts }) {
  const { list, path } = recentPosts;

  return (
    <Stack spacing={3}>
      <Typography variant="h4" gutterBottom>
        {i18n.t('dashboard.blogs.recentPost')}
      </Typography>
      {list.map((post) => (
        <BlogPostItemMobile key={post?.UID} post={post} onSiderbar path={path} />
      ))}
    </Stack>
  );
}
