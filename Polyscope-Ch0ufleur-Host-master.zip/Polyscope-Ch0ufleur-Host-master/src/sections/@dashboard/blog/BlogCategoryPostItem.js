import PropTypes from 'prop-types';
// @mui
import { Stack, Link, Avatar, Typography } from '@mui/material';
import { Link as RouterLink } from 'react-router-dom';
import { PATH_PAGE } from '../../../routes/paths';
import TextMaxLine from '../../../components/atoms/TextMaxLine';
// utils
import { fDate } from '../../../utils/formatTime';
// components
import Image from '../../../components/atoms/Image';

// ----------------------------------------------------------------------

BlogCategoryPostItem.propTypes = {
  index: PropTypes.number,
  post: PropTypes.shape({
    author: PropTypes.shape({
      name: PropTypes.string,
      photoURL: PropTypes.string,
    }),
    objectID: PropTypes.string,
    cover: PropTypes.string,
    createdAt: PropTypes.number,
    description: PropTypes.string,
    title: PropTypes.string,
  }),
};

export default function BlogCategoryPostItem({ post, index }) {
  const { title, cover, author, description, createdAt, objectID } = post;
  const noImage = index === 1 || index === 4;
  const smallImage = index === 2 || index === 7;

  return (
    <Link underline="none" component={RouterLink} to={`${PATH_PAGE.blog}/post/${objectID}`}>
      <Stack
        sx={{
          borderRadius: 2,
          overflow: 'hidden',
          position: 'relative',
        }}
      >
        {!noImage && <Image src={cover} alt={title} ratio={smallImage ? '4/3' : '1/1'} />}

        <Stack
          spacing={1}
          sx={{
            p: 3,
            bgcolor: 'background.neutral',
            ...(noImage && {
              bgcolor: 'primary.lighter',
            }),
          }}
        >
          {createdAt && (
            <Stack
              direction="row"
              alignItems="center"
              sx={{
                typography: 'caption',
                color: 'text.disabled',
                ...(noImage && {
                  color: 'grey.500',
                }),
              }}
            >
              {fDate(createdAt)}
            </Stack>
          )}
          <TextMaxLine
            variant="h5"
            sx={{
              color: 'text.primary',
            }}
            asLink
          >
            {title}
          </TextMaxLine>
          <Typography
            variant="body2"
            sx={{
              color: 'text.secondary',
              ...(noImage && {
                color: 'grey.600',
              }),
            }}
          >
            {description}
          </Typography>
          <Stack
            direction="row"
            alignItems="center"
            sx={{
              typography: 'body2',
              pt: 1.5,
              ...(noImage && {
                color: 'grey.800',
              }),
            }}
          >
            <Avatar src={author?.photoURL} sx={{ mr: 1 }} />
            {author?.name}
          </Stack>
        </Stack>
      </Stack>
    </Link>
  );
}
