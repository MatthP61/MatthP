import PropTypes from 'prop-types';
import Masonry from '@mui/lab/Masonry';
// @mui
import { Pagination, Stack } from '@mui/material';
import BlogCategoryPostItem from './BlogCategoryPostItem';

// ----------------------------------------------------------------------

BlogPostListCategory.propTypes = {
  posts: PropTypes.array.isRequired,
  page: PropTypes.number,
  handleChange: PropTypes.func,
  total: PropTypes.number,
};

export default function BlogPostListCategory({ posts, page, handleChange, total }) {
  return (
    <>
      <Masonry
        columns={{ xs: 1, md: 2 }}
        spacing={5}
        defaultHeight={450}
        defaultColumns={1}
        defaultSpacing={4}
        sx={{
          mx: { xs: 'unset', md: 0 },
        }}
      >
        {posts?.slice(0, 8).map((post, index) => (
          <BlogCategoryPostItem key={post?.objectID} post={post} index={index} />
        ))}
      </Masonry>

      <Stack
        alignItems="center"
        sx={{
          pt: 8,
          pb: { xs: 8, md: 10 },
        }}
      >
        <Pagination
          count={total}
          color="primary"
          page={page + 1}
          onChange={handleChange}
          size="large"
          sx={{
            py: { xs: 8, md: 10 },
            '& .MuiPagination-ul': {
              justifyContent: 'center',
            },
          }}
        />
      </Stack>
    </>
  );
}
