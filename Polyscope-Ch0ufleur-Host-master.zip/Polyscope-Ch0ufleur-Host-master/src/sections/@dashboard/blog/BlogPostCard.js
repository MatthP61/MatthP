import PropTypes from 'prop-types';
import React, { useState } from 'react';

import { Link as RouterLink } from 'react-router-dom';
// @mui
import { styled, alpha } from '@mui/material/styles';
import { Box, Link, Card, Avatar, Typography, CardContent, Stack } from '@mui/material';
// routes
import { PATH_DASHBOARD } from '../../../routes/paths';
// hooks
import useResponsive from '../../../hooks/useResponsive';
// components
import Image from '../../../components/atoms/Image';
import TextMaxLine from '../../../components/atoms/TextMaxLine';
import SvgIconStyle from '../../../components/atoms/SvgIconStyle';
import ModalCard from '../../../components/molecules/card/ModalCard';
import { ListMoreMenu } from '../user/list';
import TextIconLabel from '../../../components/atoms/TextIconLabel';
import Iconify from '../../../components/atoms/Iconify';
// utils
import { fShortenNumber } from '../../../utils/formatNumber';
import { fDate } from '../../../utils/formatTime';

// ----------------------------------------------------------------------

const OverlayStyle = styled('div')(({ theme }) => ({
  top: 0,
  zIndex: 1,
  width: '100%',
  height: '100%',
  position: 'absolute',
  backgroundColor: alpha(theme.palette.grey[900], 0.8),
}));

const IS_EDIT = true;
// ----------------------------------------------------------------------

BlogPostCard.propTypes = {
  post: PropTypes.object.isRequired,
  index: PropTypes.number,
  viewCount: PropTypes.number,
  handleDeleteBlog: PropTypes.func,
};

export default function BlogPostCard({ post, index, viewCount, handleDeleteBlog }) {
  const isDesktop = useResponsive('up', 'md');

  const { cover, title, author, createdAt, UID } = post;
  const linkTo = `${PATH_DASHBOARD.blog.root}/post/${UID}`;

  const latestPost = index === 0 || index === 1 || index === 2;
  const [openModal, setOpenModal] = useState(false);

  const handleOpenModal = () => setOpenModal(true);
  const handleCloseModal = () => setOpenModal(false);

  const handleDelete = () => {
    handleDeleteBlog(UID, post);
    handleCloseModal();
  };

  if (isDesktop && latestPost) {
    return (
      <Card sx={{}}>
        <Stack
          sx={{
            display: 'flex',
            flexDirection: 'row',
            justifyContent: 'space-between',
            zIndex: 9,
            px: 3,
            width: 1,
            top: 24,
            position: 'absolute',
          }}
        >
          <Avatar alt={author?.displayName || 'Test'} src={author?.photoURL || 'Test'} />
          <ListMoreMenu
            onDelete={handleOpenModal}
            editPath={`${PATH_DASHBOARD.blog.root}/${UID}/edit`}
            isEdit={IS_EDIT}
          />
        </Stack>
        <Link to={linkTo} color="inherit" component={RouterLink}>
          <PostContent id={UID} title={title} createdAt={createdAt} index={index} viewCount={viewCount} />
          <OverlayStyle />
          <Image alt="cover" src={cover} sx={{ height: 360 }} />
          {openModal && (
            <ModalCard isOpen={openModal} handleClose={handleCloseModal} UID={UID} deleteElement={handleDelete} />
          )}
        </Link>
      </Card>
    );
  }

  return (
    <Card>
      <Box sx={{ position: 'relative' }}>
        <SvgIconStyle
          src="https://minimal-assets-api.vercel.app/assets/icons/shape-avatar.svg"
          sx={{
            width: 80,
            height: 36,
            zIndex: 9,
            bottom: -15,
            position: 'absolute',
            color: 'background.paper',
          }}
        />
        <Avatar
          alt={author?.displayName || 'Test'}
          src={author?.photoURL || 'Test'}
          sx={{
            left: 24,
            zIndex: 9,
            width: 32,
            height: 32,
            bottom: -16,
            position: 'absolute',
          }}
        />
        <Stack
          sx={{
            display: 'flex',
            flexDirection: 'row',
            justifyContent: 'flex-end',
            zIndex: 9,
            px: 1,
            width: 1,
            top: 24,
            position: 'absolute',
          }}
        >
          <ListMoreMenu
            onDelete={() => handleDeleteBlog(UID, post)}
            editPath={`${PATH_DASHBOARD.blog.root}/${UID}/edit`}
            isEdit={IS_EDIT}
          />
        </Stack>
        <Image alt="cover" src={cover} ratio="4/3" />
      </Box>

      <PostContent id={UID} title={title} createdAt={createdAt} index={index} viewCount={viewCount} />
    </Card>
  );
}

// ----------------------------------------------------------------------

PostContent.propTypes = {
  index: PropTypes.number,
  title: PropTypes.string,
  id: PropTypes.string,
  viewCount: PropTypes.number,
  createdAt: PropTypes.number,
};

export function PostContent({ title, createdAt, index, id, viewCount }) {
  const isDesktop = useResponsive('up', 'md');

  const linkTo = `${PATH_DASHBOARD.blog.root}/post/${id}`;

  const latestPostLarge = index === 0;
  const latestPostSmall = index === 1 || index === 2;

  return (
    <CardContent
      sx={{
        pt: 4.5,
        width: 1,
        ...((latestPostLarge || latestPostSmall) && {
          pt: 0,
          zIndex: 9,
          bottom: 0,
          position: 'absolute',
          color: 'common.white',
        }),
      }}
    >
      <Link to={linkTo} color="inherit" component={RouterLink}>
        {createdAt && (
          <Typography
            gutterBottom
            variant="caption"
            component="div"
            sx={{
              color: 'text.disabled',
              ...((latestPostLarge || latestPostSmall) && {
                opacity: 0.64,
                color: 'common.white',
              }),
            }}
          >
            {fDate(createdAt)}
          </Typography>
        )}

        <TextMaxLine variant={isDesktop && latestPostLarge ? 'h5' : 'subtitle2'} line={2} persistent>
          {title}
        </TextMaxLine>

        <Stack
          flexWrap="wrap"
          direction="row"
          justifyContent="flex-end"
          sx={{
            mt: 3,
            color: 'text.disabled',
            ...((latestPostLarge || latestPostSmall) && {
              opacity: 0.64,
              color: 'common.white',
            }),
          }}
        >
          <TextIconLabel
            icon={<Iconify icon="eva:eye-fill" sx={{ width: 16, height: 16, mr: 0.5 }} />}
            value={fShortenNumber(viewCount)}
            sx={{ typography: 'caption', ml: 0 }}
          />
        </Stack>
      </Link>
    </CardContent>
  );
}
