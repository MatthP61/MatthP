import PropTypes from 'prop-types';
import * as Yup from 'yup';
import { useCallback, useState, useContext, useMemo } from 'react';
import { useSnackbar } from 'notistack';
import { useNavigate } from 'react-router-dom';
// form
import { yupResolver } from '@hookform/resolvers/yup';
import { useForm, Controller } from 'react-hook-form';
// @mui
import { LoadingButton } from '@mui/lab';
import { Grid, Card, Chip, Stack, Button, TextField, Autocomplete } from '@mui/material';
// routes
import { getStorage, ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { PATH_DASHBOARD } from '../../../routes/paths';
// components
import {
  RHFSwitch,
  RHFEditor,
  FormProvider,
  RHFTextField,
  RHFSelect,
  RHFUploadSingleFile,
} from '../../../components/organismes/hook-form';
import BlogNewPostPreview from './BlogNewPostPreview';
// contexts
import { BlogContext } from '../../../contexts/BlogContext';
import { CategoryContext } from '../../../contexts/CategoryContext';
// hooks
import useAuth from '../../../hooks/useAuth';
// utils
import { fTimestamp } from '../../../utils/formatTime';
import { LabelStyle } from '../../../utils/GeneralStyle';
import i18n from '../../../locales/i18n';

// ----------------------------------------------------------------------

const TAGS_OPTION = [
  'Toy Story 3',
  'Logan',
  'Full Metal Jacket',
  'Dangal',
  'The Sting',
  '2001: A Space Odyssey',
  "Singin' in the Rain",
  'Toy Story',
  'Bicycle Thieves',
  'The Kid',
  'Inglourious Basterds',
  'Snatch',
  'polytechnique',
];

// ----------------------------------------------------------------------

BlogNewPostForm.propTypes = {
  currentBlog: PropTypes.object,
  isEdit: PropTypes.bool,
};

export default function BlogNewPostForm({ isEdit, currentBlog }) {
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const { enqueueSnackbar } = useSnackbar();
  const { uploadBlog, editBlog } = useContext(BlogContext);
  const { CategoryList } = useContext(CategoryContext);
  const { user } = useAuth();

  const handleOpenPreview = () => {
    setOpen(true);
  };

  const handleClosePreview = () => {
    setOpen(false);
  };

  const NewBlogSchema = Yup.object().shape({
    title: Yup.string().required(i18n.t('dashboard.newBlog.titleReq')),
    description: Yup.string().required(i18n.t('dashboard.newBlog.descRep')),
    body: Yup.string().min(10).required(i18n.t('dashboard.newBlog.bodyReq')),
    cover: Yup.mixed().required(i18n.t('dashboard.newBlog.coverReq')),
    tags: Yup.array().min(1, i18n.t('dashboard.newBlog.tagsReq')),
  });

  const pluck = (arr, key) => arr.map((i) => i[key]);

  const defaultValues = useMemo(
    () => ({
      UID: currentBlog?.UID || '',
      title: currentBlog?.title || '',
      description: currentBlog?.description || '',
      body: currentBlog?.body || '',
      cover: currentBlog?.cover || null,
      tags: currentBlog?.tags || ['Polytechnique'],
      publish: currentBlog?.publish || false,
      createdAt: '',
      author: currentBlog?.author || null,
      category: currentBlog?.category || CategoryList[0]?.title,
      editDates: currentBlog?.editDates || [],
    }),
    [currentBlog]
  );

  const methods = useForm({
    resolver: yupResolver(NewBlogSchema),
    defaultValues,
  });

  const {
    reset,
    watch,
    control,
    setValue,
    handleSubmit,
    formState: { isSubmitting },
  } = methods;

  const values = watch();

  const onSubmit = async () => {
    await handleClosePreview();
    try {
      values.createdAt = fTimestamp(Date.now());
      values.editDates.push(values.createdAt);
      await new Promise((resolve) => setTimeout(resolve, 300));
      if (isEdit) {
        editBlog(values);
      } else {
        values.author = user;
        uploadBlog(values);
      }
      reset();
      enqueueSnackbar(!isEdit ? i18n.t('form.createSuccess') : i18n.t('form.updateSuccess'));
      navigate(PATH_DASHBOARD.blog.posts);
    } catch (error) {
      console.error(error);
    }
  };

  const handleDrop = useCallback(
    (acceptedFiles) => {
      const file = acceptedFiles[0];

      if (file === '') {
        console.error(`not an image, the image file is a ${typeof file}`);
      }

      const storage = getStorage();
      const storageRef = ref(storage, `/blog-image/${file.name}`);
      uploadBytes(storageRef, file).then(() => {
        getDownloadURL(storageRef).then((url) => {
          setValue('cover', url);
        });
      });
    },
    [setValue]
  );

  return (
    <>
      <FormProvider methods={methods} onSubmit={handleSubmit(onSubmit)}>
        <Grid container spacing={3}>
          <Grid item xs={12} md={8}>
            <Card sx={{ p: 3 }}>
              <Stack spacing={3}>
                <div>
                  <LabelStyle>{i18n.t('dashboard.newBlog.cover')}</LabelStyle>
                  <RHFUploadSingleFile required name="cover" accept="image/*" maxSize={3145728} onDrop={handleDrop} />
                </div>
                <RHFTextField required name="title" label={i18n.t('dashboard.newBlog.title')} />

                <RHFTextField required name="description" label={i18n.t('dashboard.newBlog.desc')} multiline rows={3} />

                <div>
                  <LabelStyle>{i18n.t('dashboard.newBlog.body')}</LabelStyle>
                  <RHFEditor required name="body" />
                </div>
              </Stack>
            </Card>
          </Grid>

          <Grid item xs={12} md={4}>
            <Card sx={{ p: 3 }}>
              <Stack spacing={3}>
                <div>
                  <RHFSwitch
                    name="publish"
                    label={i18n.t('dashboard.newBlog.publish')}
                    labelPlacement="start"
                    sx={{ mb: 1, mx: 0, width: 1, justifyContent: 'space-between' }}
                  />
                </div>

                <Controller
                  name="tags"
                  control={control}
                  render={({ field, fieldState: { error } }) => (
                    <Autocomplete
                      {...field}
                      multiple
                      freeSolo
                      defaultValue={values.tags}
                      onChange={(event, newValue) => field.onChange(newValue)}
                      options={TAGS_OPTION.map((option) => option)}
                      renderTags={(value, getTagProps) =>
                        value.map((option, index) => (
                          <Chip {...getTagProps({ index })} key={option} size="small" label={option} />
                        ))
                      }
                      renderInput={(params) => (
                        <TextField
                          error={!!error}
                          helperText={error?.message}
                          label={i18n.t('dashboard.newBlog.tags')}
                          {...params}
                        />
                      )}
                    />
                  )}
                />

                <RHFSelect required name="category" label={i18n.t('dashboard.newBlog.category')}>
                  {pluck(CategoryList, 'title').map((option) => (
                    <option key={option.value} value={option.value}>
                      {option}
                    </option>
                  ))}
                </RHFSelect>
              </Stack>
            </Card>
            <Stack direction="row" spacing={1.5} sx={{ mt: 3 }}>
              <Button fullWidth color="inherit" variant="outlined" size="large" onClick={handleOpenPreview}>
                {i18n.t('dashboard.newBlog.preview')}
              </Button>
              <LoadingButton fullWidth type="submit" variant="contained" size="large" loading={isSubmitting}>
                {values.publish
                  ? isEdit
                    ? i18n.t('form.save')
                    : i18n.t('dashboard.newBlog.publish')
                  : i18n.t('form.draft')}
              </LoadingButton>
            </Stack>
          </Grid>
        </Grid>
      </FormProvider>

      <BlogNewPostPreview
        values={values}
        isOpen={open}
        isSubmitting={isSubmitting}
        onClose={handleClosePreview}
        onSubmit={handleSubmit(onSubmit)}
      />
    </>
  );
}
