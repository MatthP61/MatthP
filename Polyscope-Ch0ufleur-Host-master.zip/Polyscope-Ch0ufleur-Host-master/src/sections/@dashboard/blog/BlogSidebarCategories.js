import PropTypes from 'prop-types';
import { useContext } from 'react';
import { Link as RouterLink } from 'react-router-dom';
import { Stack, Link, Typography, Box } from '@mui/material';
import { CategoryContext } from '../../../contexts/CategoryContext';
import i18n from '../../../locales/i18n';

// ----------------------------------------------------------------------

export default function BlogSidebarCategories() {
  const { CategoryList } = useContext(CategoryContext);

  return (
    <Stack spacing={1}>
      <Typography variant="h4" gutterBottom>
        {i18n.t('dashboard.category.title')}
      </Typography>
      {CategoryList.map((category) => (
        <CategoryItem key={category?.UID} category={category} />
      ))}
    </Stack>
  );
}

// ----------------------------------------------------------------------

CategoryItem.propTypes = {
  category: PropTypes.shape({
    title: PropTypes.string,
    UID: PropTypes.string,
    name: PropTypes.string,
    path: PropTypes.string,
  }),
};

function CategoryItem({ category }) {
  const { UID, title } = category;

  return (
    <Stack key={UID} direction="row" alignItems="center">
      <Box sx={{ width: 6, height: 6, mr: 2, bgcolor: 'primary.main', borderRadius: '50%' }} />
      <Link to={`/blogs/category/${title}`} color="inherit" component={RouterLink} textAlign="left">
        {title}
      </Link>
    </Stack>
  );
}
