import PropTypes from 'prop-types';
// Link
import { Link as RouterLink } from 'react-router-dom';
// @mui
import { Stack, Avatar, Link } from '@mui/material';
// utils
import { fDate } from '../../../utils/formatTime';
// components
import Image from '../../../components/atoms/Image';
import TextMaxLine from '../../../components/atoms/TextMaxLine';
import { PATH_PAGE } from '../../../routes/paths';

// ----------------------------------------------------------------------

BlogPostItem.propTypes = {
  post: PropTypes.shape({
    author: PropTypes.shape({
      name: PropTypes.string,
      photoURL: PropTypes.string,
    }),
    cover: PropTypes.string,
    objectID: PropTypes.string,
    createdAt: PropTypes.number,
    title: PropTypes.string,
  }),
};

export default function BlogPostItem({ post }) {
  const { objectID, title, cover, author, createdAt } = post;

  return (
    <Link underline="none" component={RouterLink} to={`${PATH_PAGE.blog}/post/${objectID}`}>
      <Stack spacing={2.5}>
        <Image src={cover} alt={title} ratio="1/1" sx={{ borderRadius: 2 }} />

        <Stack spacing={1}>
          {createdAt && (
            <Stack direction="row" alignItems="center" sx={{ typography: 'caption', color: 'text.disabled' }}>
              {fDate(createdAt)}
            </Stack>
          )}
          <TextMaxLine
            asLink
            sx={{
              typography: 'h6',
              color: 'text.primary',
            }}
          >
            {title}
          </TextMaxLine>
        </Stack>

        <Stack direction="row" alignItems="center" sx={{ typography: 'body2', color: 'text.primary' }}>
          <Avatar src={author?.photoURL} sx={{ mr: 1 }} />
          {author.name}
        </Stack>
      </Stack>
    </Link>
  );
}
