import PropTypes from 'prop-types';
// @mui
import { Pagination, Box } from '@mui/material';
//
import BlogPostItem from './BlogPostItem';

// ----------------------------------------------------------------------
BlogPostList.propTypes = {
  posts: PropTypes.array.isRequired,
  page: PropTypes.number,
  handleChange: PropTypes.func,
  total: PropTypes.number,
};

export default function BlogPostList({ posts, page, handleChange, total }) {
  return (
    <>
      <Box
        sx={{
          display: 'grid',
          rowGap: { xs: 4, md: 5 },
          columnGap: 4,
          gridTemplateColumns: {
            xs: 'repeat(1, 1fr)',
            sm: 'repeat(2, 1fr)',
          },
        }}
      >
        {posts.slice(0, 8).map((post) => (
          <BlogPostItem key={post?.objectID} post={post} />
        ))}
      </Box>

      <Pagination
        count={total}
        color="primary"
        page={page + 1}
        onChange={handleChange}
        size="large"
        sx={{
          py: { xs: 8, md: 10 },
          '& .MuiPagination-ul': {
            justifyContent: 'center',
          },
        }}
      />
    </>
  );
}
