import { useState } from 'react';
import parse from 'autosuggest-highlight/parse';
import match from 'autosuggest-highlight/match';
import { useNavigate, useLocation } from 'react-router-dom';
// @mui
import { styled } from '@mui/material/styles';
import { Link, Typography, Autocomplete, InputAdornment, Popper } from '@mui/material';
// hooks
import useAlgolia from '../../../hooks/useAlgolia';
import useIsMountedRef from '../../../hooks/useIsMountedRef';
import { PATH_DASHBOARD, PATH_PAGE } from '../../../routes/paths';
// components
import Image from '../../../components/atoms/Image';
import Iconify from '../../../components/atoms/Iconify';
import InputStyle from '../../../components/atoms/InputStyle';
import SearchNotFound from '../../../components/atoms/SearchNotFound';
import i18n from '../../../locales/i18n';

// ----------------------------------------------------------------------

const PopperStyle = styled((props) => <Popper placement="bottom-start" {...props} />)({
  width: '300px !important',
});

// ----------------------------------------------------------------------

export default function BlogPostsSearch() {
  const navigate = useNavigate();
  const isMountedRef = useIsMountedRef();
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const index = useAlgolia();

  const handleChangeSearch = async (value) => {
    try {
      setSearchQuery(value);
      if (value) {
        if (isMountedRef.current) {
          index.search(value).then(({ hits }) => {
            setSearchResults(hits);
          });
        }
      }
    } catch (error) {
      console.error(error);
    }
  };

  const { pathname } = useLocation();
  const handleClick = (title) => {
    navigate(`${pathname.includes('/dashboard') ? PATH_DASHBOARD.blog.root : PATH_PAGE.blog}/post/${title}`);
  };

  const handleKeyUp = (event) => {
    if (event.key === 'Enter') {
      if (searchResults[0]) {
        handleClick(searchResults[0].objectID);
      }
    }
  };

  return (
    <Autocomplete
      size="small"
      autoHighlight
      popupIcon={null}
      PopperComponent={PopperStyle}
      options={searchResults}
      onInputChange={(event, value) => handleChangeSearch(value)}
      getOptionLabel={(post) => post.title}
      noOptionsText={<SearchNotFound searchQuery={searchQuery} />}
      isOptionEqualToValue={(option, value) => option.id === value.id}
      renderInput={(params) => (
        <InputStyle
          {...params}
          stretchStart={300}
          placeholder={i18n.t('blog.searchBlog')}
          onKeyUp={handleKeyUp}
          InputProps={{
            ...params.InputProps,
            startAdornment: (
              <InputAdornment position="start">
                <Iconify icon={'eva:search-fill'} sx={{ ml: 1, width: 20, height: 20, color: 'text.disabled' }} />
              </InputAdornment>
            ),
          }}
        />
      )}
      renderOption={(props, post, { inputValue }) => {
        const { title, cover, objectID } = post;
        const matches = match(title, inputValue);
        const parts = parse(title, matches);

        return (
          <li {...props} key={objectID}>
            <Image alt={cover} src={cover} sx={{ width: 48, height: 48, borderRadius: 1, flexShrink: 0, mr: 1.5 }} />
            <Link underline="none" onClick={() => handleClick(objectID)}>
              {parts.map((part, index) => (
                <Typography
                  key={index}
                  component="span"
                  variant="subtitle2"
                  color={part.highlight ? 'primary' : 'textPrimary'}
                >
                  {part.text}
                </Typography>
              ))}
            </Link>
          </li>
        );
      }}
    />
  );
}
