import algoliasearch from 'algoliasearch/lite';

// ----------------------------------------------------------------------

const client = algoliasearch('DPA1GFF4MA', '93ce20303e6422775b3b66fe7637d2b5');
const index = client.initIndex('polyscope');

const useAlgolia = () => index;

export default useAlgolia;
