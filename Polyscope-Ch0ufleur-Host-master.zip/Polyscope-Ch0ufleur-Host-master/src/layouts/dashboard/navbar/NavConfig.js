// routes
import { PATH_DASHBOARD } from '../../../routes/paths';

// components
import SvgIconStyle from '../../../components/atoms/SvgIconStyle';

// ----------------------------------------------------------------------

const getIcon = (name) => <SvgIconStyle src={`/icons/${name}.svg`} sx={{ width: 1, height: 1 }} />;

const ICONS = {
  blog: getIcon('ic_blog'),
  edition: getIcon('ic_magazin'),
  user: getIcon('ic_user'),
  calendar: getIcon('ic_calendar'),
  analytics: getIcon('ic_analytics'),
  dashboard: getIcon('ic_dashboard'),
  ad: getIcon('ic_ad'),
  category: getIcon('ic_category'),
  settings: getIcon('ic_settings'),
};

const navConfig = [
  // GENERAL
  // ----------------------------------------------------------------------
  {
    subheader: 'général',
    items: [{ title: 'Application', path: PATH_DASHBOARD.general.app, icon: ICONS.dashboard }],
  },

  // MANAGEMENT
  // ----------------------------------------------------------------------
  {
    subheader: 'Gestion',
    items: [
      {
        title: 'Éditions',
        path: PATH_DASHBOARD.edition.root,
        icon: ICONS.edition,
        children: [
          { title: 'Archives', path: PATH_DASHBOARD.edition.list },
          { title: 'Nouvelle édition', path: PATH_DASHBOARD.edition.newEdition },
        ],
      },
      {
        title: 'Articles',
        path: PATH_DASHBOARD.blog.root,
        icon: ICONS.blog,
        children: [
          { title: 'Articles', path: PATH_DASHBOARD.blog.posts },
          { title: 'Créer un article', path: PATH_DASHBOARD.blog.newPost },
        ],
      },
      {
        title: 'Journalistes',
        path: PATH_DASHBOARD.user.root,
        icon: ICONS.user,
        children: [
          { title: 'Liste', path: PATH_DASHBOARD.user.list },
          { title: 'Mon compte', path: PATH_DASHBOARD.user.account },
        ],
      },
      {
        title: 'Catégories',
        path: PATH_DASHBOARD.category.root,
        icon: ICONS.category,
        children: [
          { title: 'Liste', path: PATH_DASHBOARD.category.list },
          { title: 'Ajouter', path: PATH_DASHBOARD.category.newCategory },
        ],
      },
      {
        title: 'Carrousel',
        path: PATH_DASHBOARD.ads.root,
        icon: ICONS.ad,
        children: [
          { title: 'Liste', path: PATH_DASHBOARD.ads.list },
          { title: 'Ajouter', path: PATH_DASHBOARD.ads.newAds },
        ],
      },
      {
        title: 'Paramètres',
        path: PATH_DASHBOARD.settings.root,
        icon: ICONS.settings,
        children: [
          { title: 'Général', path: PATH_DASHBOARD.settings.general },
          { title: 'À propos', path: PATH_DASHBOARD.settings.about },
          { title: 'Équipe', path: PATH_DASHBOARD.settings.team },
        ],
      },
      { title: 'Calendrier', path: PATH_DASHBOARD.calendar, icon: ICONS.calendar },
    ],
  },
];

export default navConfig;
