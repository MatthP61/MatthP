// routes
import { PATH_DASHBOARD } from '../../../routes/paths';

// components
import SvgIconStyle from '../../../components/atoms/SvgIconStyle';

// ----------------------------------------------------------------------

const getIcon = (name) => <SvgIconStyle src={`/icons/${name}.svg`} sx={{ width: 1, height: 1 }} />;

const ICONS = {
  blog: getIcon('ic_blog'),
  user: getIcon('ic_user'),
};

const navConfigJ = [
  {
    subheader: 'Gestion',
    items: [
      {
        title: 'Articles',
        path: PATH_DASHBOARD.blog.root,
        icon: ICONS.blog,
        children: [
          { title: 'Articles', path: PATH_DASHBOARD.blog.posts },
          { title: 'Créer un article', path: PATH_DASHBOARD.blog.newPost },
        ],
      },
      {
        title: 'Mon compte',
        path: PATH_DASHBOARD.user.account,
        icon: ICONS.user,
        children: [{ title: 'Mon compte', path: PATH_DASHBOARD.user.account }],
      },
    ],
  },
];

export default navConfigJ;
