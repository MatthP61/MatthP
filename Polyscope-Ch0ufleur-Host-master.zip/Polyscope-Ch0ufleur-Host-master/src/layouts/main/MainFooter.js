import { Link as RouterLink } from 'react-router-dom';
// @mui
import { styled } from '@mui/material/styles';
import { Grid, Link, Divider, Container, Typography, Stack } from '@mui/material';
// routes
import { PATH_PAGE } from '../../routes/paths';
// components
import Logo from '../../components/atoms/Logo';
import SocialsButton from '../../components/atoms/SocialsButton';
import i18n from '../../locales/i18n';

// ----------------------------------------------------------------------
const SOCIAL_LINKS = {
  facebook: 'https://www.facebook.com/Polyscope',
  twitter: 'https://twitter.com/Polyscope',
  instagram: 'https://www.instagram.com/lepolyscope/',
  linkedin: 'https://www.linkedin.com/company/le-polyscope/about/',
};
const LINKS = [
  {
    headline: i18n.t('polyscope'),
    children: [
      { name: i18n.t('aboutus.title'), href: PATH_PAGE.about },
      { name: i18n.t('contactus.title'), href: PATH_PAGE.contact },
      { name: i18n.t('sendText.titlePage'), href: PATH_PAGE.sendBlog },
    ],
  },
  {
    headline: i18n.t('footer.legal'),
    children: [{ name: i18n.t('footer.term'), href: PATH_PAGE.termsConditions }],
  },
  {
    headline: i18n.t('footer.contact'),
    children: [{ name: 'article@polyscope.qc.ca', href: '#' }],
  },
];

const RootStyle = styled('div')(({ theme }) => ({
  position: 'relative',
  backgroundColor: theme.palette.background.default,
}));

// ----------------------------------------------------------------------

export default function MainFooter() {
  return (
    <RootStyle>
      <Divider />
      <Container sx={{ pt: 10 }}>
        <Grid
          container
          justifyContent={{ xs: 'center', md: 'space-between' }}
          sx={{ textAlign: { xs: 'center', md: 'left' } }}
        >
          <Grid item xs={12} sx={{ mb: 3 }}>
            <Logo sx={{ mx: { xs: 'auto', md: 'inherit' } }} />
          </Grid>
          <Grid item xs={8} md={3}>
            <Typography variant="body2" sx={{ pr: { md: 5 } }}>
              {i18n.t('footer.descrpition')}
            </Typography>

            <Stack
              direction="row"
              justifyContent={{ xs: 'center', md: 'flex-start' }}
              sx={{ mt: 5, mb: { xs: 5, md: 0 } }}
            >
              <SocialsButton sx={{ mx: 0.5 }} links={SOCIAL_LINKS} />
            </Stack>
          </Grid>

          <Grid item xs={12} md={7}>
            <Stack spacing={5} direction={{ xs: 'column', md: 'row' }} justifyContent="space-between">
              {LINKS.map((list) => (
                <Stack key={list.headline} spacing={2}>
                  <Typography component="p" variant="overline">
                    {list.headline}
                  </Typography>
                  {list.children.map((link) => (
                    <Link
                      to={link.href}
                      onClick={(e) => {
                        if (link.name === 'article@polyscope.qc.ca') {
                          window.location.href = `mailto:${link.name}`;
                          e.preventDefault();
                        }
                      }}
                      key={link.name}
                      color="inherit"
                      variant="body2"
                      component={RouterLink}
                      sx={{ display: 'block' }}
                    >
                      {link.name}
                    </Link>
                  ))}
                </Stack>
              ))}
            </Stack>
          </Grid>
        </Grid>

        <Typography
          component="p"
          variant="body2"
          sx={{
            mt: 10,
            pb: 5,
            fontSize: 13,
            textAlign: { xs: 'center', md: 'left' },
          }}
        >
          {i18n.t('footer.allrightsReserved')}
        </Typography>
      </Container>
    </RootStyle>
  );
}
