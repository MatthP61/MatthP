// Config
import { PATH_AFTER_LOGIN } from '../../config';
// components
import Iconify from '../../components/atoms/Iconify';
import i18n from '../../locales/i18n';

// ----------------------------------------------------------------------

const ICON_SIZE = {
  width: 22,
  height: 22,
};

const menuConfig = [
  {
    title: i18n.t('home.home'),
    icon: <Iconify icon={'bxs:home'} {...ICON_SIZE} />,
    path: '/',
  },
  {
    title: i18n.t('blogs'),
    icon: <Iconify icon={'brandico:blogger-rect'} {...ICON_SIZE} />,
    path: '/blogs',
  },
  {
    title: i18n.t('sendText.titlePage'),
    icon: <Iconify icon={'ic:round-email'} {...ICON_SIZE} />,
    path: '/send-blog',
  },
  {
    title: i18n.t('aboutus.title'),
    icon: <Iconify icon={'carbon:information-filled'} {...ICON_SIZE} />,
    path: '/about-us',
  },
  {
    title: i18n.t('dashboard.dashboard'),
    icon: <Iconify icon={'ic:baseline-space-dashboard'} {...ICON_SIZE} />,
    path: PATH_AFTER_LOGIN,
  },
];

export default menuConfig;
